extends Node3D
## Червоний трактор із плугом. Колеса крутяться від пройденої відстані, передні повертають,
## плуг на дорозі піднятий, на полі — опускається й лишає зорані борозни (маска на шейдері поля).
## Кермує дідусь (grandpa.gd: on_tractor). Модель: ніс −X, плуг +X → у вузлі трактор дивиться вздовж +Z.

signal parked

const LENGTH := 4.6
const S := LENGTH / 3.672                       # масштаб моделі
const SEAT := Vector3(0, 1.15, 0.31)            # де сидить водій (стегна)
const WHEEL_R_REAR := 0.53 * S
const WHEEL_R_FRONT := 0.27 * S

var model: Node3D
var wheels_rear: Array = []
var wheels_front: Array = []
var plow: Node3D
var _spin := 0.0
var steer := 0.0
var plow_down := false
var _plow_k := 0.0                              # 0 — піднятий, 1 — опущений
var speed := 0.0
var state := "parked"                           # parked / drive / plow
var shed_pos := Vector3.ZERO
var shed_yaw := 0.0
var field: Rect2                                # поле під оранку (x, z)
var driver: Node3D
var _mask: Image
var _mask_tex: ImageTexture
var _mask_dirty := false
var _mask_t := 0.0
var _field_mat: ShaderMaterial
var plowed := 0.0                               # частка зораного поля 0..1
var _smoke: CPUParticles3D
var _clods: CPUParticles3D
var _engine: AudioStreamPlayer3D
var _gen: AudioStreamGeneratorPlayback
var _phase := 0.0
var _rpm := 0.0
var area: Area3D
var _bubble: Label3D
var _bubble_left := 0.0
var _job := 0

const MASK_N := 64


func setup(shed: Vector3, yaw: float, field_rect: Rect2) -> void:
	shed_pos = shed
	shed_yaw = yaw
	field = field_rect
	position = shed
	rotation.y = yaw
	model = Models.spawn(self, "tractor", LENGTH, "realx")
	if model == null:
		return
	model.rotation.y = PI / 2.0
	_cut_parts()
	area = Util.pick_area("tractor", Vector3(2.4, 2.2, 4.8), Vector3(0, 1.1, -0.3))
	add_child(area)
	_bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 52)
	_bubble.pixel_size = 0.006
	_bubble.position = Vector3(0, 2.9, 0)
	add_child(_bubble)
	_make_fx()
	_make_engine()


func _cut_parts() -> void:
	var mis := model.find_children("*", "MeshInstance3D", true, false)
	if mis.is_empty():
		return
	var mi: MeshInstance3D = mis[0]
	# задні колеса (великі) і передні — вирізаємо циліндром, щоб не зачепити бризковики
	for sz in [1.0, -1.0]:
		var zr := Vector2(0.29, 0.77) if sz > 0.0 else Vector2(-0.77, -0.29)
		var rp := Models.cut(model, AABB(Vector3(-0.92, -0.02, zr.x), Vector3(1.11, 1.13, zr.y - zr.x)), 100.0, mi, 0.565)
		if rp:
			var h := Models.hinge(rp, mi.to_global(Vector3(-0.367, 0.545, sz * 0.53)))
			wheels_rear.append(h)
		var zf := Vector2(0.21, 0.6) if sz > 0.0 else Vector2(-0.6, -0.21)
		var fp := Models.cut(model, AABB(Vector3(-1.85, -0.02, zf.x), Vector3(0.56, 0.6, zf.y - zf.x)), 100.0, mi, 0.33)
		if fp:
			var hf := Models.hinge(fp, mi.to_global(Vector3(-1.571, 0.296, sz * 0.4)))
			wheels_front.append(hf)
	# плуг (усе позаду навісного механізму)
	var pp := Models.cut(model, AABB(Vector3(0.70, -0.02, -0.5), Vector3(1.25, 0.85, 1.0)), 100.0, mi)
	if pp:
		plow = Models.hinge(pp, mi.to_global(Vector3(0.70, 0.62, 0.0)))
	_plow_k = 0.0
	_apply_plow()


func _make_fx() -> void:
	# дим із труби
	_smoke = CPUParticles3D.new()
	_smoke.position = Vector3(0.35, 2.15, 1.63)
	_smoke.amount = 14
	_smoke.lifetime = 1.6
	_smoke.direction = Vector3(0, 1, 0)
	_smoke.spread = 12.0
	_smoke.initial_velocity_min = 0.6
	_smoke.initial_velocity_max = 1.0
	_smoke.gravity = Vector3(0, 0.3, 0)
	_smoke.scale_amount_min = 0.15
	_smoke.scale_amount_max = 0.3
	var sc := Curve.new()
	sc.add_point(Vector2(0, 0.4))
	sc.add_point(Vector2(1, 1.6))
	_smoke.scale_amount_curve = sc
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 8
	sm.rings = 4
	var smat := StandardMaterial3D.new()
	smat.albedo_color = Color(0.55, 0.55, 0.55, 0.45)
	smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = smat
	_smoke.mesh = sm
	_smoke.emitting = false
	add_child(_smoke)
	# грудочки землі з-під плуга
	_clods = CPUParticles3D.new()
	_clods.position = Vector3(0, 0.15, -2.0)
	_clods.amount = 22
	_clods.lifetime = 0.8
	_clods.direction = Vector3(0, 1, -0.3)
	_clods.spread = 40.0
	_clods.initial_velocity_min = 1.0
	_clods.initial_velocity_max = 2.2
	_clods.gravity = Vector3(0, -9.0, 0)
	_clods.scale_amount_min = 0.05
	_clods.scale_amount_max = 0.11
	var bm := BoxMesh.new()
	bm.size = Vector3.ONE
	bm.material = Util.mat(Color(0.3, 0.2, 0.12), 1.0)
	_clods.mesh = bm
	_clods.emitting = false
	add_child(_clods)


func _make_engine() -> void:
	var g := AudioStreamGenerator.new()
	g.mix_rate = 22050.0
	g.buffer_length = 0.25
	_engine = AudioStreamPlayer3D.new()
	_engine.stream = g
	_engine.bus = "SFX"
	_engine.unit_size = 6.0
	_engine.max_distance = 60.0
	_engine.volume_db = -12.0
	add_child(_engine)


func _engine_step() -> void:
	var on := state != "parked"
	if on and not _engine.playing:
		_engine.play()
		_gen = _engine.get_stream_playback()
	elif not on and _engine.playing:
		_engine.stop()
		_gen = null
	_smoke.emitting = on
	if _gen == null:
		return
	# «тр-р-р»: імпульси, частота яких росте з обертами
	var f := 9.0 + _rpm * 6.0
	var n := _gen.get_frames_available()
	for i in n:
		_phase += f / 22050.0
		if _phase >= 1.0:
			_phase -= 1.0
		var env := exp(-_phase * 7.0)
		var s := (randf() * 2.0 - 1.0) * 0.35 * env + sin(_phase * TAU * 3.0) * 0.25 * env
		_gen.push_frame(Vector2(s, s) * 0.6)


# ------------------------------------------------------------------ поле
func make_field(parent: Node3D) -> void:
	## Земля під оранку: стерня, а де пройшов плуг — темні борозни (маска 64×64).
	_mask = Image.create(MASK_N, MASK_N, false, Image.FORMAT_L8)
	_mask.fill(Color(0, 0, 0))
	_mask_tex = ImageTexture.create_from_image(_mask)
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
uniform sampler2D mask : filter_linear, repeat_disable;
uniform vec4 rect;
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
float h21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p) { vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y); }
void fragment() {
	vec2 uv = (wp.xz - rect.xy) / rect.zw;
	float m = smoothstep(0.25, 0.75, texture(mask, uv).r);
	float n = vn(wp.xz * 3.0) * 0.5 + vn(wp.xz * 13.0) * 0.5;
	float rows = smoothstep(0.2, 0.8, abs(sin(wp.x * 3.14159 / 0.32)));
	vec3 stub = mix(vec3(0.48, 0.42, 0.24), vec3(0.68, 0.58, 0.34), rows * 0.55 + n * 0.45);
	stub = mix(stub, vec3(0.38, 0.46, 0.22), vn(wp.xz * 0.5) * 0.45);
	float fur = 0.5 + 0.5 * sin(wp.x * 6.2831 / 0.5);
	vec3 soil = mix(vec3(0.17, 0.11, 0.07), vec3(0.37, 0.25, 0.15), fur * 0.65 + n * 0.35);
	ALBEDO = mix(stub, soil, m);
	ROUGHNESS = 0.97;
}
"""
	_field_mat = ShaderMaterial.new()
	_field_mat.shader = sh
	_field_mat.set_shader_parameter("mask", _mask_tex)
	_field_mat.set_shader_parameter("rect", Vector4(field.position.x, field.position.y, field.size.x, field.size.y))
	var pm := PlaneMesh.new()
	pm.size = field.size
	pm.subdivide_width = 4
	pm.subdivide_depth = 4
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	mi.material_override = _field_mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = Vector3(field.get_center().x, 0.035, field.get_center().y)
	parent.add_child(mi)
	# межа поля — невеликий валок землі по краях
	var edge := Util.mat(Color(0.36, 0.28, 0.17), 1.0)
	for e in [[Vector3(field.get_center().x, 0.05, field.position.y), Vector3(field.size.x + 0.4, 0.12, 0.35)],
			[Vector3(field.get_center().x, 0.05, field.end.y), Vector3(field.size.x + 0.4, 0.12, 0.35)],
			[Vector3(field.position.x, 0.05, field.get_center().y), Vector3(0.35, 0.12, field.size.y)],
			[Vector3(field.end.x, 0.05, field.get_center().y), Vector3(0.35, 0.12, field.size.y)]]:
		var b := Util.box(e[1], edge, e[0])
		b.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(b)


func reset_field() -> void:
	if _mask == null:
		return
	_mask.fill(Color(0, 0, 0))
	_mask_tex.update(_mask)
	plowed = 0.0


func _paint(p: Vector3) -> void:
	var u := (p.x - field.position.x) / field.size.x
	var v := (p.z - field.position.y) / field.size.y
	if u < 0.0 or u > 1.0 or v < 0.0 or v > 1.0:
		return
	var cx := u * MASK_N
	var cy := v * MASK_N
	var r := 0.95 / field.size.x * MASK_N + 0.6
	for y in range(int(cy - r - 1), int(cy + r + 2)):
		for x in range(int(cx - r - 1), int(cx + r + 2)):
			if x < 0 or y < 0 or x >= MASK_N or y >= MASK_N:
				continue
			var d := Vector2(x + 0.5 - cx, y + 0.5 - cy).length()
			if d <= r:
				var old := _mask.get_pixel(x, y).r
				if old < 1.0:
					_mask.set_pixel(x, y, Color(1, 1, 1))
					plowed += 1.0 / float(MASK_N * MASK_N)
	_mask_dirty = true


# ------------------------------------------------------------------ рух
func say(t: String, secs := 2.0) -> void:
	if _bubble == null:
		return
	_bubble.text = t
	_bubble.visible = true
	_bubble_left = secs


func seat_global() -> Vector3:
	return to_global(SEAT)


func plow_pos() -> Vector3:
	return to_global(Vector3(0, 0, -2.0))


func _apply_plow() -> void:
	if plow == null:
		return
	var k := 1.0 - _plow_k
	plow.basis = Basis(Vector3.RIGHT, k * 0.32)
	plow.position.y = 0.62 * S + k * 0.3


var _day := -1


func _process(delta: float) -> void:
	if model == null:
		return
	var dd := int(Game.state.get("day", 1))
	if dd != _day:
		if _day != -1 and state == "parked":
			reset_field()                # за ніч поле знову заростає стернею
		_day = dd
	_plow_k = move_toward(_plow_k, 1.0 if plow_down else 0.0, delta * 0.8)
	_apply_plow()
	_spin += speed * delta / WHEEL_R_REAR
	var spin_f := _spin * WHEEL_R_REAR / WHEEL_R_FRONT
	for w in wheels_rear:
		(w as Node3D).basis = Basis(Vector3.RIGHT, _spin)
	for w in wheels_front:
		(w as Node3D).basis = Basis(Vector3.UP, steer) * Basis(Vector3.RIGHT, spin_f)
	_rpm = lerpf(_rpm, 1.0 + absf(speed) * 0.6 + (0.5 if plow_down and _plow_k > 0.9 else 0.0), 1.0 - exp(-delta * 2.0))
	_engine_step()
	# легке тремтіння корпусу
	if state != "parked":
		model.position.y = sin(Time.get_ticks_msec() * 0.045) * 0.008
	var digging := plow_down and _plow_k > 0.9 and absf(speed) > 0.2
	_clods.emitting = digging
	if digging:
		_paint(plow_pos())
	_mask_t += delta
	if _mask_dirty and _mask_t > 0.15:
		_mask_t = 0.0
		_mask_dirty = false
		_mask_tex.update(_mask)
	if _bubble_left > 0.0:
		_bubble_left -= delta
		if _bubble_left <= 0.0:
			_bubble.visible = false


func _drive_to(p: Vector3, v: float, reach := 0.7) -> void:
	## Їде до точки, як справжня машина: повертає кермом, а не на місці.
	var id := _job
	var t := 0.0
	while id == _job:
		var dt := get_process_delta_time()
		t += dt
		var to := p - global_position
		to.y = 0.0
		var d := to.length()
		if d < reach or t > 60.0:
			return
		var want := atan2(to.x, to.z)
		var diff := angle_difference(rotation.y, want)
		steer = lerpf(steer, clampf(diff * 1.6, -0.55, 0.55), 1.0 - exp(-dt * 6.0))
		var vv := v * clampf(1.2 - absf(diff) * 0.5, 0.35, 1.0)
		if d < 2.0:
			vv = minf(vv, maxf(0.6, d))
		speed = move_toward(speed, vv, dt * 2.5)
		rotation.y += clampf(diff, -1.0, 1.0) * dt * speed / 1.9 * 1.6
		global_position += Vector3(sin(rotation.y), 0, cos(rotation.y)) * speed * dt
		await get_tree().process_frame


func _stop() -> void:
	while absf(speed) > 0.05:
		speed = move_toward(speed, 0.0, get_process_delta_time() * 3.0)
		global_position += Vector3(sin(rotation.y), 0, cos(rotation.y)) * speed * get_process_delta_time()
		await get_tree().process_frame
	speed = 0.0
	steer = 0.0


func start_engine() -> void:
	state = "drive"
	say("Тр-р-р-р!", 1.5)


func drive_route(points: Array, v := 3.2) -> void:
	_job += 1
	state = "drive"
	for p in points:
		await _drive_to(p, v)
	await _stop()


func plow_field() -> void:
	## Оранка: ряди вздовж z, на кінці ряду плуг піднімається, розворот — і наступний ряд.
	_job += 1
	var id := _job
	state = "plow"
	var x0 := field.position.x + 0.9
	var x1 := field.end.x - 0.6
	var z_in := field.end.y - 0.4            # південний край (ближче до дороги)
	var z_far := field.position.y + 0.4
	var step := 1.5
	var x := x0
	var dir := -1.0                           # спершу на північ (до z_far)
	await _drive_to(Vector3(x, 0, field.end.y + 2.6), 2.5)
	while x <= x1 and id == _job:
		var a := Vector3(x, 0, z_in if dir < 0.0 else z_far)
		var b := Vector3(x, 0, z_far if dir < 0.0 else z_in)
		await _drive_to(a, 1.8, 0.5)
		if id != _job:
			return
		plow_down = true
		say("Оремо!", 1.2)
		await _drive_to(b, 2.0, 0.5)
		plow_down = false
		if id != _job:
			return
		# розворот на краю поля
		var out := b + Vector3(0.0, 0, 2.4 * (1.0 if dir > 0.0 else -1.0))
		if x + step <= x1:
			await _drive_to(out + Vector3(step * 0.5, 0, 0), 1.6, 0.6)
		x += step
		dir = -dir
	plow_down = false
	_mask_tex.update(_mask)
	state = "drive"


func go_park(route: Array) -> void:
	await drive_route(route + [shed_pos + Vector3(0, 0, 2.0)], 3.0)
	# заднім ходом під навіс не їздимо — просто стаємо носом до виїзду
	var t := 0.0
	while t < 1.2:
		t += get_process_delta_time()
		rotation.y = lerp_angle(rotation.y, shed_yaw, 0.08)
		global_position = global_position.lerp(shed_pos, 0.06)
		await get_tree().process_frame
	global_position = shed_pos
	rotation.y = shed_yaw
	state = "parked"
	parked.emit()


func poke() -> void:
	say(["Тр-тр!", "Я трактор Червоненький!", "Поле орати — то моя робота!"][randi() % 3], 2.0)

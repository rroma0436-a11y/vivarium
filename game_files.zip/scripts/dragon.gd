extends Node3D
## Дракон: відпочиває на галявині за подвір'ям (крила складені, дихає, роздивляється),
## час від часу злітає й робить коло над усією округою — над селом, річкою, лісом — і повертається.
## Торкнешся, коли він на землі, — привітається й полетить.

const SIZE := 3.2
const SPEED := 11.0
const SEAT_OFF := Vector3(0, 0.7, -0.1)

var home := Vector3(-40, 0, -2)
var model: Node3D
var ap: AnimationPlayer
var pose
var state := "rest"           # rest, takeoff, fly, land
var _rest_left := 25.0
var _path: Array = []
var _u := 0.0
var _seg_len: Array = []
var _t := 0.0
var _roll := 0.0
var _a_fly := ""
var _a_glide := ""
var bubble: Label3D
var _bubble_left := 0.0
var _look_t := 0.0
var _look_to := 0.0
# ---- політ з дівчинкою: керує гравець
signal landed
var rider: Node3D                  # хто сидить на спині
var hold := false                  # не злітати самому (дівчинка залазить)
var joy := Vector2.ZERO            # джойстик: x — поворот, y — швидше/повільніше
var climb := 0.0                   # +1 вгору, -1 вниз
var speed := 12.0
var _vy := 0.0
var _sk: Skeleton3D
var _seat_bone := -1
var _wall_said := false
const MIN_Y := 9.0
const MAX_Y := 48.0
const LIMIT := 215.0


func setup(at: Vector3) -> void:
	home = at
	position = at
	rotation.y = PI * 0.5
	model = Models.spawn(self, "dragon", SIZE)
	if model == null:
		return
	ap = Models.anim_player(model)
	_a_fly = Models.find_anim(ap, ["fly"])
	_a_glide = Models.find_anim(ap, ["glide"])
	Models.set_loop(ap, [_a_fly, _a_glide])
	ap.playback_default_blend_time = 0.4
	var sks := model.find_children("*", "Skeleton3D", true, false)
	if sks.size() > 0:
		pose = preload("res://scripts/dragon_pose.gd").new()
		pose.axis_node = self
		pose.setup(sks[0])
		pose.ground = 1.0
		sks[0].add_child(pose)
		_sk = sks[0]
		_seat_bone = _sk.find_bone("body_top0")
	_play(_a_glide, 0.25)
	add_child(Util.pick_area("dragon", Vector3(3.0, 2.6, 4.0), Vector3(0, 1.3, 0)))
	bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 44)
	bubble.position = Vector3(0, 3.6, 0)
	add_child(bubble)
	_make_path()


func say(text: String, secs := 2.5) -> void:
	bubble.text = text
	bubble.visible = true
	_bubble_left = secs


func _play(n: String, speed := 1.0) -> void:
	if pose:
		pose.gliding = n == _a_glide
	if ap == null or n == "":
		return
	if ap.current_animation != n:
		ap.play(n)
	ap.speed_scale = speed


func _make_path() -> void:
	## Коло над округою (замкнена плавна крива).
	_path = [
		home + Vector3(-6, 9, -8), Vector3(-75, 26, -70), Vector3(0, 32, -95), Vector3(75, 28, -50),
		Vector3(100, 24, 35), Vector3(40, 22, 95), Vector3(-30, 26, 120), Vector3(-95, 24, 50),
		home + Vector3(-22, 12, 6),
	]


func _cr(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, t: float) -> Vector3:
	var t2 := t * t
	var t3 := t2 * t
	return 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)


func _path_point(u: float) -> Vector3:
	## u — від 0 до кількості відрізків (без замикання: від першої до останньої точки).
	var n := _path.size()
	var i := clampi(int(floor(u)), 0, n - 2)
	var t := clampf(u - i, 0.0, 1.0)
	var p0: Vector3 = _path[maxi(i - 1, 0)]
	var p1: Vector3 = _path[i]
	var p2: Vector3 = _path[i + 1]
	var p3: Vector3 = _path[mini(i + 2, n - 1)]
	return _cr(p0, p1, p2, p3, t)


func _process(delta: float) -> void:
	_t += delta
	if model == null:
		return
	if _bubble_left > 0.0:
		_bubble_left -= delta
		if _bubble_left <= 0.0:
			bubble.visible = false
	if pose:
		pose.t = _t
	match state:
		"rest":
			_rest(delta)
		"fly":
			_fly(delta)
		"ride":
			_ride(delta)
		"home":
			_autopilot(delta)
	# на землі: лапи рівно на землі
	if pose and float(pose.ground) > 0.01:
		var off := global_position.y - float(pose.foot_low)
		model.position.y = lerpf(model.position.y, model.position.y + off * float(pose.ground), 1.0 - exp(-delta * 10.0))
	else:
		model.position.y = lerpf(model.position.y, 0.0, 1.0 - exp(-delta * 3.0))
	if rider and rider.get("riding"):
		rider.seat_on(self)


func seat_local() -> Vector3:
	## Місце на спині (між крилами), у системі дракона.
	if _sk and _seat_bone >= 0:
		var p := to_local(_sk.global_transform * _sk.get_bone_global_pose(_seat_bone).origin)
		return p + SEAT_OFF
	return Vector3(0, 1.6, 0)


func _rest(delta: float) -> void:
	_play(_a_glide, 0.15)
	# роздивляється довкола
	_look_t -= delta
	if _look_t <= 0.0:
		_look_t = randf_range(2.0, 5.0)
		_look_to = randf_range(-1.0, 1.0)
	if pose:
		pose.look = lerpf(float(pose.look), _look_to, 1.0 - exp(-delta * 1.5))
	if Game.is_night() or hold or rider:
		return              # уночі спить на галявині
	_rest_left -= delta
	if _rest_left <= 0.0:
		take_off()


func poke() -> void:
	if rider:
		say("Р-р-р!", 1.2)
		return
	if state == "rest":
		say("Р-р-р! Привіт! Полечу погляну на округу!", 3.0)
		_rest_left = 1.5
	else:
		say("Р-р-р!", 1.5)


func take_off(free := false) -> void:
	## free — злітає з дівчинкою: далі керує гравець.
	if state != "rest":
		return
	state = "takeoff"
	_play(_a_fly, 1.2)
	var au = get_node_or_null("/root/Main/Audio")
	if au and Game.state["location"] == "yard":
		au.play_at("magic_bells", self, -6.0, 0.7)
	var tw := create_tween()
	tw.tween_property(pose, "ground", 0.0, 0.7)
	var start: Vector3 = _path[0]
	if free:
		var f := Vector3(sin(rotation.y), 0, cos(rotation.y))
		start = global_position + f * 14.0 + Vector3(0, 10.0, 0)
	var t := 0.0
	var from := global_position
	while t < 2.2:
		t += get_process_delta_time()
		var k := clampf(t / 2.2, 0.0, 1.0)
		var p := from.lerp(start, k * k)
		global_position = p
		await get_tree().process_frame
	_u = 0.0
	if free:
		speed = 12.0
		_vy = 0.0
		state = "ride"
	else:
		state = "fly"


func _fly(delta: float) -> void:
	var n := _path.size()
	var p := _path_point(_u)
	# крок по кривій приблизно зі сталою швидкістю
	var ahead := _path_point(minf(_u + 0.02, n - 1.0))
	var seg := maxf(p.distance_to(ahead) / 0.02, 0.01)
	_u += delta * SPEED / seg
	var np := _path_point(minf(_u, n - 1.0))
	var vel := (np - global_position) / maxf(delta, 0.0001)
	global_position = np
	if vel.length() > 0.1:
		var want := atan2(vel.x, vel.z)
		var turn := angle_difference(rotation.y, want)
		rotation.y = lerp_angle(rotation.y, want, 1.0 - exp(-delta * 3.0))
		_roll = lerpf(_roll, clampf(-turn * 2.0, -0.5, 0.5), 1.0 - exp(-delta * 2.0))
		rotation.z = _roll
		rotation.x = lerpf(rotation.x, clampf(-vel.y / SPEED, -0.3, 0.3), 1.0 - exp(-delta * 2.0))
	# угору — махає крилами, униз чи рівно — ширяє
	if vel.y > 0.6 or fmod(_t, 9.0) < 3.0:
		_play(_a_fly, 1.0)
	else:
		_play(_a_glide, 1.0)
	if _u >= n - 1.0:
		_land()


func _land() -> void:
	state = "land"
	_play(_a_glide, 1.0)
	var from := global_position
	var t := 0.0
	var dur := 3.2
	var tw_started := false
	while t < dur:
		t += get_process_delta_time()
		var k := clampf(t / dur, 0.0, 1.0)
		var e := 1.0 - pow(1.0 - k, 2.0)
		var p := from.lerp(home, e)
		p.y = lerpf(from.y, home.y, 1.0 - pow(1.0 - k, 3.0))
		var d := p - global_position
		if Vector2(d.x, d.z).length() > 0.02:
			rotation.y = lerp_angle(rotation.y, atan2(d.x, d.z), 0.08)
		rotation.z = lerpf(rotation.z, 0.0, 0.08)
		rotation.x = lerpf(rotation.x, 0.0, 0.08)
		global_position = p
		if k > 0.6 and not tw_started:
			tw_started = true
			_play(_a_fly, 1.4)          # перед посадкою кілька помахів
			create_tween().tween_property(pose, "ground", 1.0, dur * 0.4)
		await get_tree().process_frame
	rotation = Vector3(0, rotation.y, 0)
	global_position = home
	pose.ground = 1.0
	state = "rest"
	_rest_left = randf_range(40.0, 80.0)
	if rider:
		say("Р-р! Приїхали!", 2.0)
	else:
		say("Ух, гарно політав!", 2.0)
	landed.emit()


# ------------------------------------------------------------------ політ, яким керує гравець
func _ride(delta: float) -> void:
	# швидкість: джойстик уперед — швидше, назад — повільніше
	var want_speed := 12.0 + joy.y * (6.0 if joy.y > 0.0 else 5.0)
	speed = lerpf(speed, want_speed, 1.0 - exp(-delta * 1.5))
	var turn := -joy.x * 1.3
	# далі — туман і пагорби: плавно повертаємо назад
	var flat := Vector2(global_position.x, global_position.z)
	if flat.length() > LIMIT:
		var back := atan2(-global_position.x, -global_position.z)
		turn = clampf(angle_difference(rotation.y, back) * 1.5, -1.3, 1.3)
		if not _wall_said:
			_wall_said = true
			say("Далі туман — повертаємо!", 2.5)
	elif flat.length() < LIMIT - 30.0:
		_wall_said = false
	rotation.y += turn * delta
	# вгору / вниз
	_vy = lerpf(_vy, climb * 6.0, 1.0 - exp(-delta * 3.0))
	var p := global_position
	var f := Vector3(sin(rotation.y), 0, cos(rotation.y))
	p += f * speed * delta
	p.y += _vy * delta
	var low := _min_y(p)
	if p.y < low:
		p.y = lerpf(p.y, low, 1.0 - exp(-delta * 4.0))
		_vy = maxf(_vy, 0.0)
	p.y = minf(p.y, MAX_Y)
	global_position = p
	_roll = lerpf(_roll, clampf(-turn * 0.45, -0.55, 0.55), 1.0 - exp(-delta * 3.0))
	rotation.z = _roll
	rotation.x = lerpf(rotation.x, clampf(-_vy / 14.0, -0.35, 0.35), 1.0 - exp(-delta * 3.0))
	# махає крилами, коли набирає висоту чи розганяється; інакше — ширяє
	if _vy > 1.0 or speed > 14.0 or fmod(_t, 8.0) < 2.5:
		_play(_a_fly, 0.8 + speed / 20.0)
	else:
		_play(_a_glide, 1.0)


func _min_y(p: Vector3) -> float:
	## Не нижче дерев, вітряка й пагорбів.
	var low := MIN_Y
	if Vector2(p.x + 82.0, p.z + 50.0).length() < 30.0:
		low = 16.0                     # вітряк на пагорбі
	if Vector2(p.x - 0.0, p.z - 80.0).length() < 10.0:
		low = 14.0                     # церква
	if Vector2(p.x, p.z).length() > 230.0:
		low = 20.0
	return low


func go_home() -> void:
	## Додому: сам летить до галявини й сідає.
	if state == "ride" or state == "fly":
		state = "home"
		_wall_said = false


func _autopilot(delta: float) -> void:
	var to := home + Vector3(0, 12.0, 0) - global_position
	var flat := Vector2(to.x, to.z)
	var want := atan2(to.x, to.z)
	var turn := clampf(angle_difference(rotation.y, want) * 1.6, -1.3, 1.3)
	rotation.y += turn * delta
	speed = lerpf(speed, 14.0, 1.0 - exp(-delta))
	var f := Vector3(sin(rotation.y), 0, cos(rotation.y))
	var p := global_position + f * speed * delta
	p.y = lerpf(p.y, maxf(home.y + 12.0, _min_y(p)), 1.0 - exp(-delta * 0.8))
	global_position = p
	_roll = lerpf(_roll, clampf(-turn * 0.45, -0.55, 0.55), 1.0 - exp(-delta * 3.0))
	rotation.z = _roll
	rotation.x = lerpf(rotation.x, 0.0, 1.0 - exp(-delta * 3.0))
	_play(_a_glide, 1.0)
	if flat.length() < 26.0 and absf(angle_difference(rotation.y, want)) < 0.6:
		_land()

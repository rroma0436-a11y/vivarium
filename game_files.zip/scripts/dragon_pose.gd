extends SkeletonModifier3D
## Дракон (чотирилапий, крила з 10 кісток): пози поверх анімацій польоту.
## ground — 0 у повітрі, 1 на землі: складає крила вздовж спини, ставить чотири лапи на землю,
##   дихає, крутить головою, ворушить хвостом.
## У повітрі: лапи підібрані під живіт і витягнуті назад (гарний обтічний силует),
##   під час ширяння (gliding) крила розправлені рівно в боки, хвіст хвилюється.
## Кістки «наводяться» в потрібний бік у системі дракона — не залежить від того, як зібрано скелет.

var ground := 0.0
var gliding := false
var axis_node: Node3D
var t := 0.0
var look := 0.0            # куди дивиться голова (-1..1)
var foot_low := 0.0        # найнижча точка лап (світові координати) — щоб стояв рівно на землі
var _spread := 0.0
var dbg := false
const SIDE_SIGN := 1.0
var _b := {}


func setup(sk: Skeleton3D) -> void:
	for i in sk.get_bone_count():
		_b[sk.get_bone_name(i)] = i


func _aim(sk: Skeleton3D, bone: String, child: String, want: Vector3, w: float) -> void:
	var b: int = _b.get(bone, -1)
	var c: int = _b.get(child, -1)
	if b < 0 or c < 0 or w < 0.001:
		return
	var g := sk.get_bone_global_pose(b)
	var cur := sk.get_bone_global_pose(c).origin - g.origin
	if cur.length() < 0.00001:
		return
	var q := Quaternion(cur.normalized(), want.normalized())
	q = Quaternion.IDENTITY.slerp(q, clampf(w, 0.0, 1.0))
	var parent := sk.get_bone_parent(b)
	var pg := sk.get_bone_global_pose(parent) if parent >= 0 else Transform3D()
	sk.set_bone_pose_rotation(b, (pg.basis.inverse() * (Basis(q) * g.basis)).get_rotation_quaternion())


func _frame(d: Vector3, n: Vector3) -> Basis:
	var y := d.normalized()
	var z := (n - y * n.dot(y)).normalized()
	var x := y.cross(z).normalized()
	return Basis(x, y, z)


func _orient(sk: Skeleton3D, bone: String, child: String, want: Vector3, normal: Vector3, w: float) -> void:
	## Як _aim, але ще й повертає кістку навколо своєї осі: перетинка крила лягає площиною з нормаллю normal.
	## Рахуємо від пози спокою (крила розправлені рівно, перетинка горизонтальна → нормаль угору).
	var b: int = _b.get(bone, -1)
	var c: int = _b.get(child, -1)
	if b < 0 or c < 0 or w < 0.001:
		return
	var rb := sk.get_bone_global_rest(b)
	var rd := sk.get_bone_global_rest(c).origin - rb.origin
	if rd.length() < 0.00001:
		return
	var r := _frame(want, normal) * _frame(rd, Vector3.UP).inverse()
	var desired := (r * rb.basis).orthonormalized()
	var parent := sk.get_bone_parent(b)
	var pg := sk.get_bone_global_pose(parent) if parent >= 0 else Transform3D()
	var cur := sk.get_bone_global_pose(b).basis.orthonormalized()
	var q := cur.get_rotation_quaternion().slerp(desired.get_rotation_quaternion(), clampf(w, 0.0, 1.0))
	sk.set_bone_pose_rotation(b, (pg.basis.orthonormalized().inverse() * Basis(q)).get_rotation_quaternion())


func _turn(sk: Skeleton3D, bone: String, axis: Vector3, angle: float) -> void:
	var b: int = _b.get(bone, -1)
	if b < 0 or absf(angle) < 0.0005:
		return
	var parent := sk.get_bone_parent(b)
	var pg := sk.get_bone_global_pose(parent) if parent >= 0 else Transform3D()
	var g := sk.get_bone_global_pose(b)
	sk.set_bone_pose_rotation(b, (pg.basis.inverse() * (Basis(axis.normalized(), angle) * g.basis)).get_rotation_quaternion())


func _process_modification() -> void:
	var sk := get_skeleton()
	if sk == null or axis_node == null:
		return
	var dt := get_process_delta_time() if is_inside_tree() else 0.016
	var inv := sk.global_transform.basis.inverse()
	var f := (inv * axis_node.global_transform.basis.z).normalized()
	var u := (inv * axis_node.global_transform.basis.y).normalized()
	var x := (inv * axis_node.global_transform.basis.x).normalized()      # ліво
	var w := ground
	var a := 1.0 - ground
	_spread = lerpf(_spread, 1.0 if gliding and a > 0.5 else 0.0, 1.0 - exp(-dt * 3.0))
	for s in ["left", "right"]:
		var side := (x if s == "left" else -x) * SIDE_SIGN
		var fl := "leg_front_%s_" % s
		var hl := "leg_hind_%s_" % s
		var wg := "wing_%s" % s
		# ---------- у повітрі: лапи підібрані, крила при ширянні розправлені
		if a > 0.001:
			_aim(sk, fl + "top1", fl + "bot0", -u * 0.55 - f * 0.55 + side * 0.25, a * 0.9)
			_aim(sk, fl + "bot0", fl + "feet", -f * 0.85 + u * 0.35, a * 0.9)
			_aim(sk, fl + "feet", fl + "feet_end", -f * 0.9 - u * 0.2, a * 0.9)
			_aim(sk, hl + "top1", hl + "top2", -f * 0.6 - u * 0.6 + side * 0.25, a * 0.85)
			_aim(sk, hl + "top2", hl + "bot0", -f * 0.8 - u * 0.45 + side * 0.12, a * 0.9)
			_aim(sk, hl + "bot0", hl + "feet", -f * 0.95 - u * 0.15, a * 0.9)
			_aim(sk, hl + "feet", hl + "feet_end", -f * 0.95 - u * 0.25, a * 0.9)
			var sp := _spread * a
			if sp > 0.001:
				var flex := sin(t * 1.6) * 0.06
				var nn := u - f * 0.1
				_orient(sk, wg + "1", wg + "2", side + u * (0.12 + flex) - f * 0.05, nn, sp)
				_orient(sk, wg + "2", wg + "3", side + u * (0.08 + flex) - f * 0.12, nn, sp)
				_orient(sk, wg + "3", wg + "4", side + u * 0.04 - f * 0.2, nn, sp)
				_orient(sk, wg + "4", wg + "5", side - f * 0.25, nn, sp)
				_orient(sk, wg + "5", wg + "6", side - f * 0.3 - u * 0.03, nn, sp)
				_orient(sk, wg + "6", wg + "7", side * 0.8 - f * 0.55 - u * 0.1, nn, sp)
				_orient(sk, wg + "7", wg + "8", side * 0.55 - f * 0.8 - u * 0.12, nn, sp)
				_orient(sk, wg + "8", wg + "9", side * 0.35 - f * 0.95 - u * 0.1, nn, sp)
		# ---------- на землі: крила складені вздовж спини, чотири лапи на землі
		if w > 0.001:
			# крила складені вздовж боків: перетинка лежить на боці (нормаль — назовні)
			var on := side * 0.9 + u * 0.15
			_orient(sk, wg + "1", wg + "2", u * 0.8 - f * 0.25 + side * 0.3, on, w)
			_orient(sk, wg + "2", wg + "3", -f * 0.85 + u * 0.4 + side * 0.1, on, w)
			_orient(sk, wg + "3", wg + "4", -f * 0.9 + u * 0.05 + side * 0.08, on, w)
			_orient(sk, wg + "4", wg + "5", -f * 0.95 - u * 0.1 + side * 0.05, on, w)
			_orient(sk, wg + "5", wg + "6", -f - u * 0.15, on, w)
			_orient(sk, wg + "6", wg + "7", -f - u * 0.15, on, w)
			_orient(sk, wg + "7", wg + "8", -f - u * 0.15 - side * 0.03, on, w)
			_orient(sk, wg + "8", wg + "9", -f - u * 0.1 - side * 0.05, on, w)
			# складене крило компактніше — перетинка не звисає до землі
			var wb: int = _b.get(wg + "2", -1)
			if wb >= 0:
				sk.set_bone_pose_scale(wb, Vector3.ONE * lerpf(1.0, 0.62, w))
			_aim(sk, fl + "top1", fl + "bot0", -u * 0.85 + f * 0.2 + side * 0.25, w)
			_aim(sk, fl + "bot0", fl + "feet", -u + f * 0.05, w)
			_aim(sk, fl + "feet", fl + "feet_end", f * 0.9 - u * 0.25, w)
			_aim(sk, hl + "top1", hl + "top2", -u * 0.3 + f * 0.6 + side * 0.25, w)
			_aim(sk, hl + "top2", hl + "bot0", -u * 0.6 + f * 0.6 + side * 0.15, w)
			_aim(sk, hl + "bot0", hl + "feet", -u * 0.9 - f * 0.35, w)
			_aim(sk, hl + "feet", hl + "feet_end", f * 0.9 - u * 0.25, w)
	if dbg:
		dbg = false
		var ax := Basis(x, u, f)
		for s2 in ["left", "right"]:
			for k in [1, 3, 5, 7, 9]:
				var bb: int = _b.get("wing_%s%d" % [s2, k], -1)
				var o := sk.get_bone_global_pose(bb).origin - sk.get_bone_global_pose(_b["body_top0"]).origin
				var bz := sk.get_bone_global_pose(bb).basis.orthonormalized()
				print("WD %s%d pos(x,u,f)=%s  zaxis=%s" % [s2, k, str(Vector3(o.dot(x), o.dot(u), o.dot(f)).snapped(Vector3.ONE * 0.01)), str(Vector3(bz.z.dot(x), bz.z.dot(u), bz.z.dot(f)).snapped(Vector3.ONE * 0.01))])
	# хвіст: на землі лежить позаду й ворушиться, у повітрі — хвилюється, як стрічка
	var sway := sin(t * 1.3) * 0.12
	if w > 0.001:
		_aim(sk, "tail0", "tail1", -f * 0.7 - u * 0.5 + x * sway, w)
		_aim(sk, "tail2", "tail3", -f * 0.85 - u * 0.25 + x * sway * 2.0, w)
		_aim(sk, "tail4", "tail5", -f * 0.95 - u * 0.05 + x * sway * 3.0, w)
		_aim(sk, "tail6", "tail7", -f * 0.75 + x * (0.4 + sway * 2.0), w)
		_aim(sk, "tail8", "tail9", -f * 0.3 + x * (0.8 + sway * 2.0), w)
	if a > 0.001:
		for i in 9:
			_turn(sk, "tail%d" % i, x, sin(t * 2.2 - i * 0.6) * 0.045 * a)
			_turn(sk, "tail%d" % i, u, sin(t * 1.4 - i * 0.5) * 0.03 * a)
	# дихання, голова
	_turn(sk, "body1", x, sin(t * 1.7) * 0.02 * w)
	_turn(sk, "neck0", u, look * 0.35 * w)
	_turn(sk, "neck1", u, look * 0.25 * w)
	_turn(sk, "head0", x, (sin(t * 0.8) * 0.06 - 0.05) * w)
	if a > 0.001:
		_turn(sk, "head0", x, sin(t * 1.1) * 0.04 * a)
	# де найнижча точка лап
	var low := INF
	for nm in ["leg_front_left_feet", "leg_front_right_feet", "leg_hind_left_feet", "leg_hind_right_feet",
			"leg_front_left_feet_end", "leg_front_right_feet_end", "leg_hind_left_feet_end", "leg_hind_right_feet_end",
			"leg_left_feet", "leg_right_feet", "leg_left_feet_end", "leg_right_feet_end"]:
		var b: int = _b.get(nm, -1)
		if b >= 0:
			low = minf(low, (sk.global_transform * sk.get_bone_global_pose(b)).origin.y)
	if low < INF:
		foot_low = low

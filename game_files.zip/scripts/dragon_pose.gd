extends SkeletonModifier3D
## Дракон на землі (у моделі є тільки політ і ширяння): складає крила вздовж спини,
## ставить лапи на землю, дихає, крутить головою, ворушить хвостом.
## ground — 0 у повітрі, 1 на землі. Кістки «наводяться» в потрібний бік у системі дракона.

var ground := 0.0
var axis_node: Node3D
var t := 0.0
var look := 0.0            # куди дивиться голова (-1..1)
var foot_low := 0.0        # найнижча точка лап (світові координати) — щоб стояв рівно на землі
var _b := {}


func setup(sk: Skeleton3D) -> void:
	for i in sk.get_bone_count():
		_b[sk.get_bone_name(i)] = i


func _aim(sk: Skeleton3D, bone: String, child: String, want: Vector3, w: float) -> void:
	var b: int = _b.get(bone, -1)
	var c: int = _b.get(child, -1)
	if b < 0 or c < 0 or w < 0.001:
		return
	var g := sk.get_bone_global_pose(b)
	var cur := sk.get_bone_global_pose(c).origin - g.origin
	if cur.length() < 0.00001:
		return
	var q := Quaternion(cur.normalized(), want.normalized())
	q = Quaternion.IDENTITY.slerp(q, clampf(w, 0.0, 1.0))
	var parent := sk.get_bone_parent(b)
	var pg := sk.get_bone_global_pose(parent) if parent >= 0 else Transform3D()
	sk.set_bone_pose_rotation(b, (pg.basis.inverse() * (Basis(q) * g.basis)).get_rotation_quaternion())


func _turn(sk: Skeleton3D, bone: String, axis: Vector3, angle: float) -> void:
	var b: int = _b.get(bone, -1)
	if b < 0 or absf(angle) < 0.0005:
		return
	var parent := sk.get_bone_parent(b)
	var pg := sk.get_bone_global_pose(parent) if parent >= 0 else Transform3D()
	var g := sk.get_bone_global_pose(b)
	sk.set_bone_pose_rotation(b, (pg.basis.inverse() * (Basis(axis.normalized(), angle) * g.basis)).get_rotation_quaternion())


func _process_modification() -> void:
	var sk := get_skeleton()
	if sk == null or axis_node == null:
		return
	var inv := sk.global_transform.basis.inverse()
	var f := (inv * axis_node.global_transform.basis.z).normalized()
	var u := (inv * axis_node.global_transform.basis.y).normalized()
	var x := (inv * axis_node.global_transform.basis.x).normalized()      # ліво
	var w := ground
	if w > 0.001:
		for s in ["left", "right"]:
			var side := x if s == "left" else -x
			# крила складені вздовж спини
			_aim(sk, "wing_%s1" % s, "wing_%s2" % s, side * 0.45 + u * 0.55 - f * 0.55, w)
			_aim(sk, "wing_%s2" % s, "wing_%s3" % s, -f * 0.85 + u * 0.1 + side * 0.2, w)
			_aim(sk, "wing_%s3" % s, "wing_%s4" % s, -f * 0.55 - u * 0.75 + side * 0.25, w)
			_aim(sk, "wing_%s4" % s, "wing_%s5" % s, -f * 0.75 - u * 0.5 + side * 0.15, w)
			_aim(sk, "wing_%s5" % s, "wing_%s6" % s, -f * 0.85 - u * 0.4 + side * 0.1, w)
			_aim(sk, "wing_%s6" % s, "wing_%s7" % s, -f * 0.9 - u * 0.35, w)
			# лапи на землі
			_aim(sk, "leg_%s_top1" % s, "leg_%s_bot0" % s, -u * 0.8 + f * 0.35 + side * 0.15, w)
			_aim(sk, "leg_%s_bot0" % s, "leg_%s_feet" % s, -u * 0.9 - f * 0.3, w)
			_aim(sk, "leg_%s_feet" % s, "leg_%s_feet_end" % s, f * 0.9 - u * 0.25, w)
		# хвіст лежить позаду й ворушиться
		var sway := sin(t * 1.3) * 0.12
		_aim(sk, "tail0", "tail1", -f * 0.75 - u * 0.45 + x * sway, w)
		_aim(sk, "tail2", "tail3", -f * 0.9 - u * 0.15 + x * sway * 2.0, w)
		_aim(sk, "tail4", "tail5", -f * 0.9 + x * sway * 3.0, w)
		_aim(sk, "tail6", "tail7", -f * 0.6 + x * (0.5 + sway * 2.0), w)
		# дихання й голова
		_turn(sk, "body1", x, sin(t * 1.7) * 0.025 * w)
		_turn(sk, "neck0", u, look * 0.35 * w)
		_turn(sk, "neck2", u, look * 0.25 * w)
		_turn(sk, "head0", x, (sin(t * 0.8) * 0.06 - 0.1) * w)
	# де найнижча точка лап
	var low := INF
	for nm in ["leg_left_feet", "leg_right_feet", "leg_left_feet_end", "leg_right_feet_end"]:
		var b: int = _b.get(nm, -1)
		if b >= 0:
			low = minf(low, (sk.global_transform * sk.get_bone_global_pose(b)).origin.y)
	if low < INF:
		foot_low = low

extends Node3D
## Курочка або півник (моделі без готових рухів): дріботять подвір'ям, дзьобають зерно,
## трусять головою; півник іноді кукурікає.

var model: Node3D
var area: Area3D
var home := Vector3.ZERO
var radius := 2.5
var speed := 0.45
var rooster := false
var _target := Vector3.ZERO
var _pause := 1.0
var _peck := 0.0
var _t := 0.0
var _bubble: Label3D
var _bubble_left := 0.0


func setup(id: String, height: float, at: Vector3, is_rooster := false) -> void:
	rooster = is_rooster
	home = at
	position = at
	_target = at
	model = Models.spawn(self, id, height)
	area = Util.pick_area("bird", Vector3(0.4, height, 0.5), Vector3(0, height / 2.0, 0))
	add_child(area)
	add_child(Util.blob_shadow(0.18, 0.25))
	_bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 40)
	_bubble.pixel_size = 0.003
	_bubble.position = Vector3(0, height + 0.35, 0)
	add_child(_bubble)
	_t = randf() * 10.0


func say(text: String) -> void:
	_bubble.text = text
	_bubble.visible = true
	_bubble_left = 2.0


func _process(delta: float) -> void:
	_t += delta
	if model == null:
		return
	if _bubble_left > 0.0:
		_bubble_left -= delta
		if _bubble_left <= 0.0:
			_bubble.visible = false
	var to := _target - position
	to.y = 0.0
	var d := to.length()
	if d > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(to.x, to.z), 1.0 - exp(-delta * 8.0))
		position += to / d * minf(speed * delta, d)
		# дріботіння: маленькі підскоки й погойдування
		model.position.y = abs(sin(_t * 14.0)) * 0.03
		model.rotation.z = sin(_t * 14.0) * 0.06
		model.rotation.x = 0.0
		return
	model.position.y = 0.0
	model.rotation.z = 0.0
	if _peck > 0.0:
		_peck -= delta
		model.rotation.x = maxf(0.0, sin(_peck * 9.0)) * 0.55     # дзьобає зерно
		return
	model.rotation.x = lerpf(model.rotation.x, 0.0, 0.2)
	_pause -= delta
	if _pause > 0.0:
		return
	_pause = randf_range(0.8, 3.0)
	var r := randf()
	if r < 0.45:
		var a := randf() * TAU
		_target = home + Vector3(cos(a), 0, sin(a)) * randf_range(0.3, radius)
	elif r < 0.85:
		_peck = randf_range(1.0, 2.2)
	elif rooster and Game.hour() < 10.0 and randf() < 0.5:
		say("Ку-ку-рі-ку!")
	elif not rooster and randf() < 0.3:
		say("Ко-ко-ко!")


func poke() -> void:
	## Торкнулися — злякано відбігає.
	var a := randf() * TAU
	_target = position + Vector3(cos(a), 0, sin(a)) * 1.2
	_target = home + (_target - home).limit_length(radius)
	say("Ку-ку-рі-ку!" if rooster else "Ко-ко!")

extends Node3D
## Тераріум леопардового гекона Лимончика (моделі з Meshy): лампа обігріву світить і гріє,
## термометр показує температуру, гекон ховається в схованку, коли холодно, і гріється на камені, коли тепло.

const HEIGHT := 1.25
# точки всередині тераріуму (у власних координатах; підібрано під модель)
var SAND_Y := 0.74
var HIDE_P := Vector3(-0.22, 0, 0.06)
var STONE_P := Vector3(0.08, 0, 0.02)
var LAMP_P := Vector3(0.15, 1.2, -0.05)
var STONE_H := 0.1

var lamp_light: OmniLight3D
var bulb: MeshInstance3D
var gecko: Node3D
var thermo: Label3D
var area: Area3D
var _bulb_mat: StandardMaterial3D
var _t := 0.0
var _out := 0.0
var _lick := 0.0


func _ready() -> void:
	var m := Models.spawn(self, "terrarium", HEIGHT)
	if m == null:
		add_child(Util.box(Vector3(1.2, 0.7, 0.6), Util.mat(Color(0.55, 0.3, 0.2)), Vector3(0, 0.35, 0)))
		add_child(Util.box(Vector3(1.2, 0.5, 0.6), Util.mat(Color(0.8, 0.9, 1.0, 0.2)), Vector3(0, 0.95, 0)))
	_bulb_mat = Util.mat(Color(1, 0.75, 0.4), 0.2, 0.0, Color(1, 0.55, 0.2), 0.0)
	lamp_light = OmniLight3D.new()
	lamp_light.light_color = Color(1, 0.65, 0.35)
	lamp_light.omni_range = 1.4
	lamp_light.light_energy = 0.0
	lamp_light.position = LAMP_P + Vector3(0, -0.12, 0)
	add_child(lamp_light)
	gecko = Node3D.new()
	add_child(gecko)
	var g := Models.spawn(gecko, "gecko", 0.36, "z")
	if g == null:
		gecko.add_child(Util.capsule(0.03, 0.22, Util.mat(Color(0.98, 0.82, 0.32)), Vector3(0, 0.03, 0), Vector3(90, 0, 0)))
	thermo = Label3D.new()
	thermo.font = load("res://assets/fonts/DejaVuSans-Bold.ttf")
	thermo.font_size = 40
	thermo.pixel_size = 0.0022
	thermo.outline_size = 12
	thermo.outline_modulate = Color(1, 1, 1, 0.95)
	thermo.position = Vector3(-0.42, SAND_Y + 0.38, 0.36)
	thermo.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(thermo)
	area = Util.pick_area("terrarium", Vector3(1.4, 1.35, 0.8), Vector3(0, 0.67, 0))
	add_child(area)


func _process(delta: float) -> void:
	_t += delta
	var gs: Dictionary = Game.state["gecko"]
	var on: bool = gs["lamp"]
	lamp_light.light_energy = lerpf(lamp_light.light_energy, 2.2 if on else 0.0, 0.1)
	var temp: float = gs["temp"]
	thermo.text = "%d°C" % roundi(temp)
	if temp < Game.GECKO_MIN:
		thermo.modulate = Color(0.2, 0.45, 0.95)
	elif temp <= Game.GECKO_MAX:
		thermo.modulate = Color(0.15, 0.6, 0.25)
	else:
		thermo.modulate = Color(0.9, 0.25, 0.2)
	# тепло — виходить на камінь; холодно — у схованку
	var want := 1.0 if temp >= Game.GECKO_MIN - 1.0 else 0.0
	_out = move_toward(_out, want, delta * 0.35)
	var p := HIDE_P.lerp(STONE_P, _out)
	var crawl := absf(want - _out) > 0.01
	gecko.position = Vector3(p.x, SAND_Y + STONE_H * _out, p.z)
	# повзе боком-зигзагом, дихає, крутить головою, коли гріється
	var wig := sin(_t * 9.0) * 0.12 if crawl else 0.0
	gecko.rotation.y = deg_to_rad(90.0 if want > 0.5 else -90.0) * (1.0 if crawl else 0.0) + wig \
		+ (sin(_t * 0.6) * 0.25 * _out if not crawl else 0.0)
	gecko.scale = Vector3.ONE * (1.0 + sin(_t * 2.6) * 0.012)
	if _lick > 0.0:
		_lick -= delta
		gecko.rotation.x = -sin(_lick * 20.0) * 0.15


func tongue() -> void:
	## Їсть цвіркуна: швидкі «кивки».
	_lick = 0.9

extends Node3D
## Тераріум леопардового гекона Лимончика (моделі з Meshy).
## Гекон бігає по піску, залазить на камінь і колоду, гріється під лампою, ловить цвіркунів;
## коли холодно — ховається в схованку. Висоту поверхні беремо з карти terrarium_floor.json.

const HEIGHT := 1.25
const GECKO_LEN := 0.42
const INNER := Rect2(-0.42, -0.12, 0.88, 0.24)   # де можна бігати (x, z)
const HIDE_IN := Vector3(-0.33, 0.0, 0.0)        # усередині колоди-схованки
const HIDE_DOOR := Vector3(-0.14, 0.0, 0.0)      # вхід у схованку (отвір колоди дивиться вправо)
const BASK := Vector3(0.09, 0.0, -0.1)           # камінь під лампою
const LAMP_P := Vector3(0.15, 1.2, -0.05)
const SAND := 0.625

var lamp_light: OmniLight3D
var gecko: Node3D
var anim
var thermo: Label3D
var area: Area3D
var crickets: Array = []
var _floor := {}
var _t := 0.0
var _target := Vector3.ZERO
var _speed := 0.0
var _pause := 1.0
var _mode := "rest"          # rest, walk, hide, hunt
var _lick := 0.0
var _hidden := 0.0           # 1 — повністю в схованці


func _ready() -> void:
	var m := Models.spawn(self, "terrarium", HEIGHT)
	if m == null:
		add_child(Util.box(Vector3(1.2, 0.6, 0.6), Util.mat(Color(0.55, 0.3, 0.2)), Vector3(0, 0.3, 0)))
	var f := FileAccess.open("res://assets/models/terrarium_floor.json", FileAccess.READ)
	if f:
		_floor = JSON.parse_string(f.get_as_text())
	lamp_light = OmniLight3D.new()
	lamp_light.light_color = Color(1, 0.65, 0.35)
	lamp_light.omni_range = 1.4
	lamp_light.light_energy = 0.0
	lamp_light.position = LAMP_P + Vector3(0, -0.15, 0)
	add_child(lamp_light)
	gecko = Node3D.new()
	add_child(gecko)
	var g := Models.spawn(gecko, "gecko", GECKO_LEN, "z")
	if g == null:
		gecko.add_child(Util.capsule(0.03, 0.22, Util.mat(Color(0.98, 0.82, 0.32)), Vector3(0, 0.03, 0), Vector3(90, 0, 0)))
	else:
		var sks := g.find_children("*", "Skeleton3D", true, false)
		if sks.size() > 0:
			anim = preload("res://scripts/gecko_anim.gd").new()
			anim.setup(sks[0])
			sks[0].add_child(anim)
	gecko.position = Vector3(HIDE_IN.x, SAND, HIDE_IN.z)
	_target = gecko.position
	thermo = Label3D.new()
	thermo.font = load("res://assets/fonts/DejaVuSans-Bold.ttf")
	thermo.font_size = 40
	thermo.pixel_size = 0.0013
	thermo.outline_size = 12
	thermo.outline_modulate = Color(1, 1, 1, 0.95)
	thermo.position = Vector3(-0.47, 0.95, 0.345)
	add_child(thermo)
	area = Util.pick_area("terrarium", Vector3(1.4, 1.35, 0.8), Vector3(0, 0.67, 0))
	add_child(area)


func floor_y(x: float, z: float) -> float:
	## Висота поверхні (пісок, камінь, колода) у точці; беремо найвищу з 4 сусідніх клітинок.
	if _floor.is_empty():
		return SAND
	var nx: int = _floor["nx"]
	var nz: int = _floor["nz"]
	var fx := (x - float(_floor["x0"])) / (float(_floor["x1"]) - float(_floor["x0"])) * (nx - 1)
	var fz := (z - float(_floor["z0"])) / (float(_floor["z1"]) - float(_floor["z0"])) * (nz - 1)
	var ix := clampi(int(fx), 0, nx - 2)
	var iz := clampi(int(fz), 0, nz - 2)
	var h: Array = _floor["h"]
	var tx := clampf(fx - ix, 0.0, 1.0)
	var tz := clampf(fz - iz, 0.0, 1.0)
	var a: float = lerpf(h[iz * nx + ix], h[iz * nx + ix + 1], tx)
	var b: float = lerpf(h[(iz + 1) * nx + ix], h[(iz + 1) * nx + ix + 1], tx)
	return maxf(lerpf(a, b, tz), SAND - 0.02)


func _process(delta: float) -> void:
	_t += delta
	var gs: Dictionary = Game.state["gecko"]
	var on: bool = gs["lamp"]
	lamp_light.light_energy = lerpf(lamp_light.light_energy, 2.2 if on else 0.0, 0.1)
	var temp: float = gs["temp"]
	thermo.text = "%d°C" % roundi(temp)
	if temp < Game.GECKO_MIN:
		thermo.modulate = Color(0.2, 0.45, 0.95)
	elif temp <= Game.GECKO_MAX:
		thermo.modulate = Color(0.15, 0.6, 0.25)
	else:
		thermo.modulate = Color(0.9, 0.25, 0.2)
	_think(delta, temp)
	_move(delta)
	_crickets(delta)
	if anim:
		anim.breathe = _t
		if _lick > 0.0:
			_lick -= delta
			anim.nod = -sin(_lick * 18.0) * 0.35
		else:
			anim.nod = 0.0


func _think(delta: float, temp: float) -> void:
	var cold := temp < Game.GECKO_MIN - 1.0
	if cold:
		if _mode not in ["hide", "hiding"]:
			if gecko.position.distance_to(Vector3(HIDE_IN.x, gecko.position.y, HIDE_IN.z)) < 0.12:
				_mode = "hide"
				_speed = 0.0
			else:
				_mode = "to_hide"
				_go(HIDE_DOOR, 0.16)
		return
	if _mode in ["hide", "hiding", "to_hide"]:
		# зігрілося — виходить зі схованки
		_mode = "exit"
		_go(HIDE_DOOR, 0.12)
		_pause = 0.5
		return
	if _mode == "exit":
		if _speed == 0.0:
			_mode = "rest"
		return
	if not crickets.is_empty() and _mode != "hunt":
		_mode = "hunt"
	if _mode == "hunt":
		if crickets.is_empty():
			_mode = "rest"
			_pause = 1.5
			return
		var c: Node3D = crickets[0]
		_target = c.position
		_speed = 0.38
		return
	if _speed > 0.0:
		return
	_pause -= delta
	if _pause > 0.0:
		if anim:
			anim.look = sin(_t * 0.5) * 0.35
		return
	var r := randf()
	if r < 0.3 and temp < Game.GECKO_MAX:
		_go(BASK + Vector3(randf_range(-0.04, 0.04), 0, randf_range(-0.03, 0.03)), 0.14)
		_pause = randf_range(5.0, 9.0)   # гріється довше
	elif r < 0.85:
		var p := Vector3(randf_range(-0.12, INNER.end.x), 0, randf_range(INNER.position.y, INNER.end.y))
		_go(p, 0.12 if randf() < 0.7 else 0.32)
		_pause = randf_range(1.5, 4.0)
	else:
		_pause = randf_range(2.0, 4.0)


func _go(p: Vector3, speed: float) -> void:
	_target = Vector3(clampf(p.x, INNER.position.x, INNER.end.x), 0, clampf(p.z, INNER.position.y, INNER.end.y))
	_speed = speed


func _move(delta: float) -> void:
	var pos := gecko.position
	var to := Vector3(_target.x - pos.x, 0, _target.z - pos.z)
	var d := to.length()
	var moving := _speed > 0.0 and d > 0.02
	if moving:
		var want := atan2(to.x, to.z)
		gecko.rotation.y = lerp_angle(gecko.rotation.y, want, 1.0 - exp(-delta * 7.0))
		var fwd := Vector3(sin(gecko.rotation.y), 0, cos(gecko.rotation.y))
		var step := minf(_speed * delta * clampf(fwd.dot(to / d) + 0.2, 0.15, 1.0), d)
		pos += fwd * step
		pos.x = clampf(pos.x, INNER.position.x, INNER.end.x)
		pos.z = clampf(pos.z, INNER.position.y, INNER.end.y)
	elif _speed > 0.0:
		_speed = 0.0
		if _mode == "to_hide":
			_target = HIDE_IN
			_speed = 0.06
			_mode = "hiding"
		elif _mode == "hiding":
			_mode = "hide"
	# у схованці (і поки залазить/вилазить) — на піску під колодою, інакше — на поверхні
	var inside := absf(pos.x - HIDE_IN.x) < 0.2 and absf(pos.z - HIDE_IN.z) < 0.12 and _mode in ["hide", "hiding", "exit", "to_hide"]
	var y := SAND if inside else floor_y(pos.x, pos.z)
	pos.y = lerpf(pos.y, y, 1.0 - exp(-delta * 14.0))
	gecko.position = pos
	# нахил по схилу (камінь, колода)
	var fwd2 := Vector3(sin(gecko.rotation.y), 0, cos(gecko.rotation.y)) * 0.12
	var slope := floor_y(pos.x + fwd2.x, pos.z + fwd2.z) - floor_y(pos.x - fwd2.x, pos.z - fwd2.z)
	if inside:
		slope = 0.0
	gecko.rotation.x = lerpf(gecko.rotation.x, -atan2(slope, 0.24), 0.15)
	if anim:
		var speed_k := clampf(_speed / 0.3, 0.0, 1.0) if moving else 0.0
		anim.stride = lerpf(anim.stride, speed_k * 0.9 + (0.25 if moving else 0.0), 0.2)
		anim.phase += delta * (6.0 + 14.0 * speed_k) * (1.0 if moving else 0.0)


# ------------------------------------------------------------------ цвіркуни
func add_crickets(n := 3) -> void:
	var mat := Util.mat(Color(0.45, 0.3, 0.15), 0.6)
	for i in n:
		var c := Node3D.new()
		var body := Util.capsule(0.012, 0.05, mat, Vector3(0, 0.012, 0), Vector3(90, 0, 0))
		c.add_child(body)
		for k in 2:
			c.add_child(Util.box(Vector3(0.002, 0.03, 0.002), mat, Vector3(0.006 * (1 - 2 * k), 0.02, 0.018), Vector3(-40, 0, 0)))
		c.position = Vector3(randf_range(0.15, 0.45), 0, randf_range(-0.15, 0.18))
		c.position.y = floor_y(c.position.x, c.position.z)
		c.set_meta("hop", randf_range(0.2, 0.8))
		add_child(c)
		crickets.append(c)


func _crickets(delta: float) -> void:
	for c in crickets.duplicate():
		var hop: float = c.get_meta("hop") - delta
		if hop <= 0.0:
			hop = randf_range(0.6, 1.6)
			var p: Vector3 = c.position + Vector3(randf_range(-0.12, 0.12), 0, randf_range(-0.1, 0.1))
			p.x = clampf(p.x, INNER.position.x + 0.05, INNER.end.x)
			p.z = clampf(p.z, INNER.position.y, INNER.end.y)
			c.set_meta("to", p)
			c.rotation.y = atan2(p.x - c.position.x, p.z - c.position.z)
		c.set_meta("hop", hop)
		if c.has_meta("to"):
			var to: Vector3 = c.get_meta("to")
			c.position = c.position.move_toward(Vector3(to.x, c.position.y, to.z), delta * 0.5)
			c.position.y = floor_y(c.position.x, c.position.z) + maxf(0.0, sin(clampf(hop, 0.0, 0.3) / 0.3 * PI)) * 0.02
		# гекон спіймав
		var gp := gecko.position + Vector3(sin(gecko.rotation.y), 0, cos(gecko.rotation.y)) * GECKO_LEN * 0.4
		if Vector2(gp.x - c.position.x, gp.z - c.position.z).length() < 0.05:
			crickets.erase(c)
			c.queue_free()
			_lick = 0.8


func tongue() -> void:
	## Покормили: у тераріум стрибають цвіркуни, гекон за ними полює.
	if Game.state["gecko"]["temp"] >= Game.GECKO_MIN - 1.0:
		add_crickets(3)
	else:
		_lick = 0.8

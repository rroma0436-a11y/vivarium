extends Node3D
## Тераріум леопардового гекона Лимончика: скло, пісок, схованка, мисочка, лампа обігріву, термометр.

var lamp_bulb: MeshInstance3D
var lamp_light: OmniLight3D
var gecko: Node3D
var thermo: Label3D
var area: Area3D
var _bulb_mat: StandardMaterial3D
var _t := 0.0
var _out := 0.0        # 0 — у схованці, 1 — вийшов погрітися


func _ready() -> void:
	var W := 0.9
	var D := 0.45
	var H := 0.45
	var wood := Util.mat(Color(0.55, 0.36, 0.2), 0.8)
	var sand := Util.mat(Color(0.86, 0.72, 0.5), 0.95)
	var glass := Util.mat(Color(0.75, 0.9, 1.0, 0.16), 0.05, 0.0)
	glass.cull_mode = BaseMaterial3D.CULL_DISABLED
	var frame := Util.mat(Color(0.15, 0.15, 0.17), 0.4, 0.6)
	# підставка-тумба
	add_child(Util.box(Vector3(W + 0.1, 0.42, D + 0.08), wood, Vector3(0, 0.21, 0)))
	var base_y := 0.42
	add_child(Util.box(Vector3(W, 0.06, D), sand, Vector3(0, base_y + 0.03, 0)))
	# скло й рамка
	add_child(Util.box(Vector3(W, H, D), glass, Vector3(0, base_y + H / 2.0, 0)))
	for x in [-W / 2.0, W / 2.0]:
		for z in [-D / 2.0, D / 2.0]:
			add_child(Util.box(Vector3(0.015, H, 0.015), frame, Vector3(x, base_y + H / 2.0, z)))
	add_child(Util.box(Vector3(W + 0.02, 0.02, D + 0.02), frame, Vector3(0, base_y + H, 0)))
	# схованка-напівколода (холодний бік), мисочка з водою, камінь (теплий бік)
	var hide := Util.cyl(0.09, 0.09, 0.22, Util.mat(Color(0.42, 0.28, 0.17), 0.9), Vector3(-0.27, base_y + 0.06, 0.0), Vector3(90, 0, 0))
	add_child(hide)
	add_child(Util.cyl(0.07, 0.06, 0.03, Util.mat(Color(0.6, 0.62, 0.66), 0.4), Vector3(0.05, base_y + 0.075, 0.1)))
	add_child(Util.cyl(0.055, 0.055, 0.005, Util.mat(Color(0.5, 0.75, 0.95, 0.8), 0.05), Vector3(0.05, base_y + 0.09, 0.1)))
	add_child(Util.sphere(0.09, Util.mat(Color(0.62, 0.58, 0.55), 0.9), Vector3(0.28, base_y + 0.07, -0.05), Vector3(1.2, 0.45, 0.9)))
	# лампа над теплим боком
	add_child(Util.cyl(0.05, 0.09, 0.07, Util.mat(Color(0.2, 0.2, 0.22), 0.3, 0.7), Vector3(0.28, base_y + H + 0.06, -0.02)))
	_bulb_mat = Util.mat(Color(1, 0.75, 0.4), 0.2, 0.0, Color(1, 0.55, 0.2), 0.0)
	lamp_bulb = Util.sphere(0.035, _bulb_mat, Vector3(0.28, base_y + H + 0.02, -0.02))
	add_child(lamp_bulb)
	lamp_light = OmniLight3D.new()
	lamp_light.light_color = Color(1, 0.7, 0.4)
	lamp_light.omni_range = 0.7
	lamp_light.light_energy = 0.0
	lamp_light.position = Vector3(0.28, base_y + H - 0.05, -0.02)
	add_child(lamp_light)
	gecko = _make_gecko()
	gecko.position = Vector3(-0.27, base_y + 0.065, 0.02)
	add_child(gecko)
	thermo = Label3D.new()
	thermo.font = load("res://assets/fonts/DejaVuSans-Bold.ttf")
	thermo.font_size = 36
	thermo.pixel_size = 0.0016
	thermo.outline_size = 10
	thermo.outline_modulate = Color(1, 1, 1, 0.9)
	thermo.position = Vector3(-0.33, base_y + H - 0.06, D / 2.0 + 0.01)
	add_child(thermo)
	area = Util.pick_area("terrarium", Vector3(W + 0.1, 0.95, D + 0.1), Vector3(0, 0.47, 0))
	add_child(area)


func _make_gecko() -> Node3D:
	## Маленький жовтий гекон у чорну цятку (поки з простих форм).
	var g := Node3D.new()
	var skin := Util.mat(Color(0.98, 0.82, 0.32), 0.55)
	var spot := Util.mat(Color(0.18, 0.13, 0.1), 0.6)
	var belly := Util.mat(Color(1.0, 0.95, 0.85), 0.6)
	g.add_child(Util.capsule(0.022, 0.11, skin, Vector3(0, 0.02, 0), Vector3(0, 0, 90)))
	g.add_child(Util.sphere(0.024, skin, Vector3(0.07, 0.028, 0), Vector3(1.25, 0.85, 1.0)))
	for sz in [-1.0, 1.0]:
		g.add_child(Util.sphere(0.0075, Util.mat(Color(0.05, 0.05, 0.05), 0.1), Vector3(0.085, 0.036, 0.016 * sz)))
	# хвіст — товстий (гекони запасають у ньому жир), смугастий
	g.add_child(Util.capsule(0.016, 0.09, skin, Vector3(-0.085, 0.018, 0), Vector3(0, 0, 90)))
	g.add_child(Util.box(Vector3(0.008, 0.03, 0.034), belly, Vector3(-0.07, 0.02, 0)))
	g.add_child(Util.box(Vector3(0.008, 0.03, 0.03), belly, Vector3(-0.1, 0.018, 0)))
	for i in range(7):
		var p := Vector3(randf_range(-0.05, 0.08), 0.04, randf_range(-0.012, 0.012))
		g.add_child(Util.sphere(0.005, spot, p))
	for lx in [-0.035, 0.04]:
		for sz in [-1.0, 1.0]:
			g.add_child(Util.capsule(0.006, 0.035, skin, Vector3(lx, 0.006, 0.025 * sz), Vector3(70 * sz, 0, 0)))
	return g


func _process(delta: float) -> void:
	_t += delta
	var gs: Dictionary = Game.state["gecko"]
	var on: bool = gs["lamp"]
	_bulb_mat.emission_energy_multiplier = lerpf(_bulb_mat.emission_energy_multiplier, 3.0 if on else 0.0, 0.1)
	lamp_light.light_energy = lerpf(lamp_light.light_energy, 1.2 if on else 0.0, 0.1)
	var temp: float = gs["temp"]
	thermo.text = "%d°C" % roundi(temp)
	if temp < Game.GECKO_MIN:
		thermo.modulate = Color(0.2, 0.45, 0.95)
	elif temp <= Game.GECKO_MAX:
		thermo.modulate = Color(0.15, 0.6, 0.25)
	else:
		thermo.modulate = Color(0.9, 0.25, 0.2)
	# тепло — гекон виходить зі схованки на теплий камінь; холодно — ховається
	var want := 1.0 if temp >= Game.GECKO_MIN - 1.0 else 0.0
	_out = move_toward(_out, want, delta * 0.4)
	var base_y := 0.42
	gecko.position = Vector3(lerpf(-0.27, 0.22, _out), base_y + 0.065 + 0.04 * _out, 0.02)
	gecko.rotation_degrees.y = sin(_t * 0.7) * 8.0 * _out
	gecko.scale = Vector3.ONE * (1.0 + sin(_t * 3.0) * 0.015)


func tongue() -> void:
	## Їсть: швидкий «кивок» уперед.
	var tw := create_tween()
	tw.tween_property(gecko, "rotation_degrees:z", -18.0, 0.12)
	tw.tween_property(gecko, "rotation_degrees:z", 0.0, 0.18)
	tw.set_loops(3)

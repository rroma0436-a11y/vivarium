extends Control
## Інтерфейс: завдання, монетки, стан тварин, кнопки дій, діалог дідуся, підказки.

signal action(name: String)            # кнопка дії: feed, lamp, crickets, go_yard, go_room, help

var title_font: Font
var bold: Font
var quest_label: Label
var coins_label: Label
var place_label: Label
var status_label: Label
var actions_box: HBoxContainer
var dialog: Control
var dialog_name: Label
var dialog_text: Label
var dialog_portrait: TextureRect
var dialog_ok: Button
var toast_label: Label
var toast_panel: PanelContainer
var _toast_left := 0.0
var _dialog_queue: Array = []
var _on_dialog_close: Callable
var buttons := {}


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	title_font = load("res://assets/fonts/RuslanDisplay-Regular.ttf")
	var fb: Font = load("res://assets/fonts/DejaVuSans-Bold.ttf")
	if title_font is FontFile:
		(title_font as FontFile).fallbacks = [fb]
	bold = load("res://assets/fonts/DejaVuSans-Bold.ttf")
	theme = _make_theme()
	_build_top()
	_build_bottom()
	_build_dialog()
	_build_toast()
	_build_beep_menu()
	Game.changed.connect(refresh)
	refresh()


# ------------------------------------------------------------------ тема
func _box(col: Color, radius := 22, border := Color(0, 0, 0, 0), bw := 0, shadow := 6) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = col
	s.set_corner_radius_all(radius)
	s.content_margin_left = 18
	s.content_margin_right = 18
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	if bw > 0:
		s.border_color = border
		s.set_border_width_all(bw)
	if shadow > 0:
		s.shadow_color = Color(0.1, 0.05, 0.2, 0.25)
		s.shadow_size = shadow
		s.shadow_offset = Vector2(0, 3)
	return s


func _make_theme() -> Theme:
	var t := Theme.new()
	t.default_font = load("res://assets/fonts/DejaVuSans.ttf")
	t.default_font_size = 22
	t.set_stylebox("normal", "Button", _box(Color(1, 1, 1, 0.96)))
	t.set_stylebox("hover", "Button", _box(Color(1, 0.97, 0.9)))
	t.set_stylebox("pressed", "Button", _box(Color(0.93, 0.88, 1.0), 22, Color(0, 0, 0, 0), 0, 2))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_stylebox("disabled", "Button", _box(Color(0.9, 0.9, 0.92, 0.8)))
	t.set_color("font_color", "Button", Color(0.2, 0.15, 0.35))
	t.set_color("font_hover_color", "Button", Color(0.2, 0.15, 0.35))
	t.set_color("font_pressed_color", "Button", Color(0.35, 0.2, 0.6))
	t.set_font("font", "Button", bold)
	t.set_stylebox("panel", "PanelContainer", _box(Color(1, 1, 1, 0.9), 24))
	t.set_color("font_color", "Label", Color(0.2, 0.15, 0.35))
	return t


func _btn(text: String, key: String, color := Color(1, 1, 1, 0.96)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(150, 72)
	b.add_theme_font_size_override("font_size", 24)
	if color != Color(1, 1, 1, 0.96):
		b.add_theme_stylebox_override("normal", _box(color))
		b.add_theme_stylebox_override("hover", _box(color.lightened(0.08)))
		b.add_theme_stylebox_override("pressed", _box(color.darkened(0.1), 22, Color(0, 0, 0, 0), 0, 2))
		b.add_theme_color_override("font_color", Color.WHITE)
		b.add_theme_color_override("font_hover_color", Color.WHITE)
		b.add_theme_color_override("font_pressed_color", Color(1, 1, 1, 0.85))
	b.pressed.connect(func():
		var au = get_node_or_null("/root/Main/Audio")
		if au:
			au.play("click", -6.0)
		action.emit(key))
	buttons[key] = b
	return b


# ------------------------------------------------------------------ верх: місце, завдання, монетки
func _build_top() -> void:
	var top := HBoxContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 16
	top.offset_right = -16
	top.offset_top = 12
	top.add_theme_constant_override("separation", 12)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(top)
	var place := PanelContainer.new()
	place_label = Label.new()
	place_label.add_theme_font_override("font", title_font)
	place_label.add_theme_font_size_override("font_size", 26)
	place_label.add_theme_color_override("font_color", Color(0.45, 0.25, 0.6))
	place.add_child(place_label)
	top.add_child(place)
	var q := PanelContainer.new()
	q.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var qv := VBoxContainer.new()
	var qt := Label.new()
	qt.text = "Завдання"
	qt.add_theme_font_size_override("font_size", 15)
	qt.add_theme_color_override("font_color", Color(0.55, 0.45, 0.7))
	qv.add_child(qt)
	quest_label = Label.new()
	quest_label.add_theme_font_override("font", bold)
	quest_label.add_theme_font_size_override("font_size", 21)
	quest_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	qv.add_child(quest_label)
	q.add_child(qv)
	top.add_child(q)
	var c := PanelContainer.new()
	coins_label = Label.new()
	coins_label.add_theme_font_override("font", bold)
	coins_label.add_theme_font_size_override("font_size", 24)
	coins_label.add_theme_color_override("font_color", Color(0.75, 0.5, 0.05))
	c.add_child(coins_label)
	top.add_child(c)
	var snd := Button.new()
	snd.text = "♪"
	snd.custom_minimum_size = Vector2(64, 0)
	snd.add_theme_font_override("font", bold)
	snd.add_theme_font_size_override("font_size", 28)
	snd.focus_mode = Control.FOCUS_NONE
	snd.pressed.connect(func(): action.emit("sound"))
	top.add_child(snd)
	buttons["sound"] = snd
	# стан тварин — під верхньою смугою, ліворуч
	var sp := PanelContainer.new()
	sp.position = Vector2(16, 104)
	sp.add_theme_stylebox_override("panel", _box(Color(1, 1, 1, 0.78), 18, Color(0, 0, 0, 0), 0, 0))
	status_label = Label.new()
	status_label.add_theme_font_size_override("font_size", 18)
	sp.add_child(status_label)
	sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(sp)


# ------------------------------------------------------------------ низ: дії й переходи
func _build_bottom() -> void:
	var bar := HBoxContainer.new()
	bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bar.offset_left = 16
	bar.offset_right = -16
	bar.offset_top = -90
	bar.offset_bottom = -12
	bar.add_theme_constant_override("separation", 12)
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bar)
	actions_box = HBoxContainer.new()
	actions_box.add_theme_constant_override("separation", 12)
	actions_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_child(actions_box)
	actions_box.add_child(_btn("Корм", "feed", Color(0.95, 0.6, 0.25)))
	actions_box.add_child(_btn("Лампа", "lamp", Color(0.95, 0.45, 0.35)))
	actions_box.add_child(_btn("Цвіркуни", "crickets", Color(0.45, 0.7, 0.35)))
	bar.add_child(_btn("Beep, допоможи", "help", Color(0.3, 0.72, 0.7)))
	bar.add_child(_btn("На подвір'я", "go_yard", Color(0.55, 0.45, 0.85)))
	bar.add_child(_btn("У хату", "go_room", Color(0.55, 0.45, 0.85)))


# ------------------------------------------------------------------ діалог
func _build_dialog() -> void:
	dialog = Control.new()
	dialog.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dialog.visible = false
	add_child(dialog)
	var dim := ColorRect.new()
	dim.color = Color(0.1, 0.05, 0.2, 0.35)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dialog.add_child(dim)
	var panel := PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	panel.anchor_left = 0.08
	panel.anchor_right = 0.92
	panel.anchor_top = 1.0
	panel.anchor_bottom = 1.0
	panel.offset_top = -300
	panel.offset_bottom = -24
	panel.add_theme_stylebox_override("panel", _box(Color(1, 0.98, 0.93, 0.98), 30, Color(0.85, 0.7, 0.45), 4, 10))
	dialog.add_child(panel)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 22)
	panel.add_child(h)
	dialog_portrait = TextureRect.new()
	dialog_portrait.texture = load("res://assets/ui/grandpa.png")
	dialog_portrait.custom_minimum_size = Vector2(200, 200)
	dialog_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	dialog_portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	h.add_child(dialog_portrait)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 8)
	h.add_child(v)
	dialog_name = Label.new()
	dialog_name.add_theme_font_override("font", title_font)
	dialog_name.add_theme_font_size_override("font_size", 28)
	dialog_name.add_theme_color_override("font_color", Color(0.5, 0.3, 0.15))
	v.add_child(dialog_name)
	dialog_text = Label.new()
	dialog_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dialog_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	dialog_text.add_theme_font_size_override("font_size", 23)
	v.add_child(dialog_text)
	dialog_ok = Button.new()
	dialog_ok.text = "Добре!"
	dialog_ok.custom_minimum_size = Vector2(220, 64)
	dialog_ok.size_flags_horizontal = Control.SIZE_SHRINK_END
	dialog_ok.add_theme_stylebox_override("normal", _box(Color(0.45, 0.72, 0.4)))
	dialog_ok.add_theme_stylebox_override("hover", _box(Color(0.5, 0.78, 0.45)))
	dialog_ok.add_theme_stylebox_override("pressed", _box(Color(0.38, 0.62, 0.34)))
	dialog_ok.add_theme_color_override("font_color", Color.WHITE)
	dialog_ok.add_theme_color_override("font_hover_color", Color.WHITE)
	dialog_ok.pressed.connect(_close_dialog)
	v.add_child(dialog_ok)


func show_dialog(who: String, text: String, portrait: Texture2D = null, then := Callable()) -> void:
	if dialog.visible:
		_dialog_queue.append([who, text, portrait, then])
		return
	dialog_name.text = who
	dialog_text.text = text
	dialog_portrait.texture = portrait if portrait != null else load("res://assets/ui/grandpa.png")
	_on_dialog_close = then
	dialog.visible = true
	dialog.modulate.a = 0.0
	create_tween().tween_property(dialog, "modulate:a", 1.0, 0.25)


func _close_dialog() -> void:
	dialog.visible = false
	if _on_dialog_close.is_valid():
		var cb := _on_dialog_close
		_on_dialog_close = Callable()
		cb.call()
	if not _dialog_queue.is_empty():
		var d: Array = _dialog_queue.pop_front()
		show_dialog(d[0], d[1], d[2], d[3])


func dialog_open() -> bool:
	return dialog.visible or (beep_menu != null and beep_menu.visible)


# ------------------------------------------------------------------ меню Beep
var beep_menu: Control
var _menu_box: GridContainer
var _menu_items := {}

const BEEP_ITEMS := [
	["hint", "Підказка", Color(0.3, 0.72, 0.7)],
	["scan", "Сканер ферми", Color(0.4, 0.55, 0.85)],
	["ball", "М'ячик для Біма", Color(0.9, 0.45, 0.35)],
	["drone_feed", "Дрон: нагодуй курей", Color(0.85, 0.65, 0.25)],
	["drone_water", "Дрон: полий город", Color(0.3, 0.6, 0.9)],
	["water", "Тарасику, принеси води", Color(0.35, 0.65, 0.75)],
	["herd", "Біме, жени курей додому", Color(0.6, 0.5, 0.35)],
	["light", "Ліхтарик", Color(0.45, 0.4, 0.7)],
	["grandpa_in", "Дідусю, ходи в хату", Color(0.75, 0.45, 0.3)],
	["grandpa_out", "Дідусю, виходь на подвір'я", Color(0.75, 0.45, 0.3)],
]


func _build_beep_menu() -> void:
	beep_menu = Control.new()
	beep_menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	beep_menu.visible = false
	add_child(beep_menu)
	var dim := ColorRect.new()
	dim.color = Color(0.1, 0.05, 0.2, 0.3)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.gui_input.connect(func(e: InputEvent):
		if (e is InputEventMouseButton and e.pressed) or (e is InputEventScreenTouch and e.pressed):
			beep_menu.visible = false)
	beep_menu.add_child(dim)
	var panel := PanelContainer.new()
	panel.anchor_left = 0.1
	panel.anchor_right = 0.9
	panel.anchor_top = 0.16
	panel.anchor_bottom = 0.86
	panel.add_theme_stylebox_override("panel", _box(Color(0.97, 0.99, 1.0, 0.97), 30, Color(0.3, 0.72, 0.7), 4, 10))
	beep_menu.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	panel.add_child(v)
	var t := Label.new()
	t.text = "Beep, допоможи!"
	t.add_theme_font_override("font", title_font)
	t.add_theme_font_size_override("font_size", 30)
	t.add_theme_color_override("font_color", Color(0.2, 0.5, 0.5))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	_menu_box = GridContainer.new()
	_menu_box.columns = 2
	_menu_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_menu_box.add_theme_constant_override("h_separation", 14)
	_menu_box.add_theme_constant_override("v_separation", 14)
	v.add_child(_menu_box)
	for it in BEEP_ITEMS:
		var b := Button.new()
		b.text = it[1]
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.size_flags_vertical = Control.SIZE_EXPAND_FILL
		b.custom_minimum_size = Vector2(0, 64)
		b.add_theme_font_size_override("font_size", 22)
		var col: Color = it[2]
		b.add_theme_stylebox_override("normal", _box(col))
		b.add_theme_stylebox_override("hover", _box(col.lightened(0.08)))
		b.add_theme_stylebox_override("pressed", _box(col.darkened(0.1), 22, Color(0, 0, 0, 0), 0, 2))
		b.add_theme_color_override("font_color", Color.WHITE)
		b.add_theme_color_override("font_hover_color", Color.WHITE)
		b.add_theme_color_override("font_pressed_color", Color(1, 1, 1, 0.85))
		var key: String = it[0]
		b.pressed.connect(func():
			beep_menu.visible = false
			var au = get_node_or_null("/root/Main/Audio")
			if au:
				au.play("click", -6.0)
			action.emit(key))
		_menu_box.add_child(b)
		_menu_items[key] = b
	var close := Button.new()
	close.text = "Закрити"
	close.custom_minimum_size = Vector2(220, 56)
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func(): beep_menu.visible = false)
	v.add_child(close)


func show_beep_menu(in_yard: bool, night: bool, lamp_on: bool, grandpa_home := false) -> void:
	for k in _menu_items:
		var b: Button = _menu_items[k]
		b.visible = k in ["hint", "scan"] or in_yard
	_menu_items["grandpa_in"].visible = not grandpa_home
	_menu_items["grandpa_out"].visible = grandpa_home
	_menu_items["light"].text = "Ліхтарик: " + ("вимкнути" if lamp_on else "увімкнути")
	_menu_items["herd"].visible = in_yard and Game.hour() >= 17.0
	beep_menu.visible = true
	beep_menu.modulate.a = 0.0
	create_tween().tween_property(beep_menu, "modulate:a", 1.0, 0.2)


# ------------------------------------------------------------------ підказка
func _build_toast() -> void:
	toast_panel = PanelContainer.new()
	toast_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	toast_panel.offset_top = 112
	toast_panel.add_theme_stylebox_override("panel", _box(Color(0.25, 0.18, 0.4, 0.92), 22))
	toast_label = Label.new()
	toast_label.add_theme_color_override("font_color", Color.WHITE)
	toast_label.add_theme_font_size_override("font_size", 21)
	toast_panel.add_child(toast_label)
	toast_panel.visible = false
	toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(toast_panel)


func toast(text: String, secs := 2.5) -> void:
	toast_label.text = text
	toast_panel.visible = true
	toast_panel.reset_size()
	toast_panel.position.x = (size.x - toast_panel.size.x) / 2.0
	_toast_left = secs


func _process(delta: float) -> void:
	if _toast_left > 0.0:
		_toast_left -= delta
		if _toast_left <= 0.0:
			toast_panel.visible = false


# ------------------------------------------------------------------ оновлення
func refresh() -> void:
	var s: Dictionary = Game.state
	var loc: String = s["location"]
	place_label.text = ("Подвір'я" if loc == "yard" else "Хата") + "  " + Game.clock_text() + ("  ☾" if Game.is_night() else "  ☀")
	coins_label.text = "● %d" % s["coins"]
	var q := Game.current_quest()
	var qt := Game.quest_progress_text()
	if not q.is_empty() and q["where"] != "" and q["where"] != loc:
		qt += "   →  " + ("Подвір'я" if q["where"] == "yard" else "Хата")
	quest_label.text = qt
	var p: Dictionary = s["puppy"]
	var g: Dictionary = s["gecko"]
	if loc == "yard":
		status_label.text = "Бім:  ситість %d%%   радість %d%%\n%s" % [100 - int(p["hunger"]), int(p["joy"]), Game.puppy_mood()]
	else:
		status_label.text = "Лимончик:  %.1f °C  (треба 28–32)\n%s" % [g["temp"], Game.gecko_mood()]
	buttons["feed"].visible = loc == "yard"
	buttons["lamp"].visible = loc == "room"
	buttons["crickets"].visible = loc == "room"
	buttons["lamp"].text = "Лампа: увімк." if g["lamp"] else "Лампа: вимк."
	buttons["go_yard"].visible = loc != "yard"
	buttons["go_room"].visible = loc != "room"

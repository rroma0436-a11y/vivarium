extends Walker
## Цуценя Бім (модель з Meshy, 9 рухів): гуляє двором, нюхає землю, біжить за Beep,
## їсть із миски, радіє, коли гладять, виляє хвостом, увечері йде до будки.

const HEIGHT := 0.52

var busy := false
var idle_left := 2.0
var bowl_pos := Vector3.ZERO
var home_pos := Vector3.ZERO
var follow: Node3D                 # за ким іноді бігає (Beep)
var _pet_alt := false
var _act_left := 0.0
var _act_then: Callable
var door_dir := Vector3(0.3, 0, 0.95).normalized()   # куди дивляться дверцята будки
var water_pos := Vector3.ZERO
var in_house := false
var ball: Node3D                   # м'ячик у зубах
var main


func _ready() -> void:
	var ok := setup_model("puppy", HEIGHT, {
		"idle": ["dog_idle"], "sniff": ["idle1"], "walk": ["walk"], "run": ["run"],
		"eat": ["chigouliang"], "pet": ["beifumo"], "pet2": ["dog_petting"],
		"wag": ["yaoweiba"], "over": ["dog_over"],
	}, ["idle", "walk", "run", "wag", "eat"])
	if ok:
		anims["idle"] = Models.find_anim(ap, ["dog_idle"])
		# «dog_idle1» теж містить «dog_idle» — шукаємо точну назву
		for n in ap.get_animation_list():
			if String(n).to_lower().ends_with("dog_idle"):
				anims["idle"] = n
		Models.set_loop(ap, [anims["idle"]])
		_straighten()
	else:
		_placeholder()
	walk_speed = 0.75
	run_speed = 2.1
	setup_common("puppy", Vector3(0.45, 0.55, 0.7), 0.9, 0.32)
	play("idle")


func _straighten() -> void:
	## Модель з Meshy стоїть у файлі під кутом, а голова повернута до глядача.
	## Розвертаємо тіло вздовж руху й довертаємо шию, щоб Бім дивився туди, куди біжить.
	var sks := model.find_children("*", "Skeleton3D", true, false)
	if sks.is_empty():
		return
	var sk: Skeleton3D = sks[0]
	var hips := sk.find_bone("hips")
	var chest := sk.find_bone("chest")
	var neck := sk.find_bone("neck_01")
	var neck2 := sk.find_bone("neck2")
	var head := sk.find_bone("head")
	if hips < 0 or chest < 0 or neck < 0 or head < 0:
		return
	var b := sk.get_bone_global_rest(chest).origin - sk.get_bone_global_rest(hips).origin
	var a_body := atan2(b.x, b.z)
	var h := sk.get_bone_global_rest(head).origin - sk.get_bone_global_rest(neck2 if neck2 >= 0 else neck).origin
	var a_head := atan2(h.x, h.z)
	model.rotation.y = -a_body
	var fix := preload("res://scripts/head_fix.gd").new()
	fix.bone = neck
	fix.yaw = wrapf(a_body - a_head, -PI, PI)
	sk.add_child(fix)


func _placeholder() -> void:
	var body := Util.capsule(0.12, 0.45, Util.mat(Color(0.9, 0.85, 0.75)), Vector3(0, 0.25, 0), Vector3(90, 0, 0))
	add_child(body)
	add_child(Util.sphere(0.12, Util.mat(Color(0.8, 0.55, 0.25)), Vector3(0, 0.4, 0.22)))


func _process(delta: float) -> void:
	_physics_step(delta)
	if moving and doing != "doghouse":
		in_house = false
	if in_house and idle_left > 50.0 and not Game.is_night():
		idle_left = 0.5
	if _act_left > 0.0:
		_act_left -= delta
		if _act_left <= 0.0:
			var cb := _act_then
			_act_then = Callable()
			busy = false
			if cb.is_valid():
				cb.call()
	if moving:
		play("run" if running else "walk", 1.0)
		return
	if busy or doing != "":
		return
	idle_left -= delta
	if idle_left > 0.0:
		return
	_choose_next()


func _choose_next() -> void:
	idle_left = randf_range(2.5, 6.0)
	if Game.state["puppy"]["bowl"] > 0.0:
		go_eat()          # у мисці є корм — Бім про нього не забуде
		return
	if Game.is_night():
		if not in_house:
			go_doghouse()
		return
	if in_house:
		leave_doghouse()
		return
	if float(Game.state.get("water_bowl", 0.0)) > 20.0 and Game.state["puppy"]["hunger"] < 70.0 and randf() < 0.12:
		go_drink()
		return
	var r := randf()
	if follow and follow.global_position.distance_to(global_position) > 4.5 and r < 0.5:
		var p := follow.global_position
		walk_to(Vector3(p.x, 0, p.z) + Vector3(randf_range(-0.8, 0.8), 0, 0.9), true)
	elif r < 0.45:
		walk_to(position + Vector3(randf_range(-3.5, 3.5), 0, randf_range(-3.0, 3.0)))
	elif r < 0.7:
		act("sniff")
	elif r < 0.85:
		act("wag", 2.0)
	else:
		play("idle")


func act(kind: String, cycles := 1.0, then := Callable()) -> void:
	## Зіграти рух повністю (або кілька разів, якщо він по колу), потім then.
	stop()
	busy = true
	play(kind)
	_act_left = anim_length(kind) * cycles
	_act_then = then


func pet(from: Vector3) -> void:
	if doing != "":
		cancel_job()
		_drop_ball()
	face(from)
	_pet_alt = not _pet_alt
	say("Гав! ❤" if randf() < 0.5 else "Ще-ще!", 2.0)
	Game.puppy_petted()
	act("pet2" if _pet_alt else "pet", 1.0, func():
		if Game.state["puppy"]["bowl"] > 0.0:
			go_eat()
		else:
			act("wag", 2.0))


func go_eat() -> void:
	if doing != "":
		cancel_job()
		_drop_ball()
	busy = false
	walk_to(bowl_pos + (position - bowl_pos).normalized() * 0.42, true, func():
		face(bowl_pos)
		act("eat", 2.0, func():
			Game.puppy_ate()
			say("Ням! Дякую!", 2.0)
			act("wag", 3.0)))


func greet(p: Vector3) -> void:
	## Радісно біжить до точки (наприклад, до дідуся) і виляє хвостом.
	walk_to(p, true, func():
		act("wag", 3.0))



# ------------------------------------------------------------------ будка
func go_doghouse() -> void:
	## Забігає в будку й лягає, виглядаючи з дверцят.
	var id := begin_job("doghouse")
	await go(home_pos + door_dir * 1.1, true)
	if id != job:
		return
	await go(home_pos + door_dir * 0.3, false, false)
	if id != job:
		return
	in_house = true
	face(home_pos + door_dir * 3.0)
	_face_to = atan2(door_dir.x, door_dir.z)
	rotation.y = _face_to
	play("idle", 0.4)
	say("Гав… (позіхає)", 2.0)
	end_job(id)
	idle_left = 1e9 if Game.is_night() else 3.0


func leave_doghouse() -> void:
	in_house = false
	idle_left = 1.0
	walk_to(home_pos + door_dir * 1.4, false, Callable(), false)


func check_morning() -> void:
	if in_house and not Game.is_night():
		idle_left = 0.0


# ------------------------------------------------------------------ вода
func go_drink() -> void:
	var id := begin_job("drink")
	await go(water_pos + (position - water_pos).normalized() * 0.4, false)
	if id != job:
		return
	face(water_pos)
	play("eat")
	say("Хлеп-хлеп!", 1.6)
	await wait(anim_length("eat") * 1.5)
	if id != job:
		return
	act("wag", 1.5)
	end_job(id)


# ------------------------------------------------------------------ загнати курей у курник
func herd_hens(birds: Array, door: Vector3) -> void:
	## Оббігає кожну курку з дальнього боку й гавкає — вона біжить до курника.
	var id := begin_job("herd")
	if in_house:
		in_house = false
	say("Гав! Додому, курочки!", 2.0)
	for b in birds:
		if b.mode == "inside" or b.mode == "to_coop":
			continue
		var bp: Vector3 = b.global_position
		var away := (bp - door)
		away.y = 0.0
		var behind := bp + away.normalized() * 0.9 if away.length() > 0.05 else bp + Vector3(-0.9, 0, 0)
		await go(behind, true)
		if id != job:
			return
		face(bp)
		act("wag", 0.6)
		_bark()
		b.go_coop(door)
		await wait(0.5)
		if id != job:
			return
		busy = false
	# чекає, поки всі зайдуть
	var t := 0.0
	while t < 8.0:
		var all_in := true
		for b in birds:
			if b.mode != "inside":
				all_in = false
		if all_in:
			break
		await wait(0.5)
		t += 0.5
	if id != job:
		return
	say("Гав! Усі вдома!", 2.0)
	Game.emit_event("hens_home")
	end_job(id)
	if Game.is_night():
		go_doghouse()


func _bark() -> void:
	var au = get_node_or_null("/root/Main/Audio")
	if au:
		au.play_at("puppy_bark", self, -4.0, 1.1)


# ------------------------------------------------------------------ м'ячик
func fetch(b: Node3D, back_to: Node3D) -> void:
	## Біжить за м'ячиком, бере в зуби, приносить до Beep.
	var id := begin_job("fetch")
	if in_house:
		in_house = false
	var bp := b.global_position
	await go(Vector3(bp.x, 0, bp.z), true)
	if id != job:
		return
	# бере в зуби
	ball = b
	b.reparent(self)
	b.position = Vector3(0, 0.33, 0.33)
	var p := back_to.global_position
	await go(Vector3(p.x, 0, p.z) + Vector3(0.3, 0, 0.6), true)
	if id != job:
		_drop_ball()
		return
	face(p)
	_drop_ball()
	_bark()
	say("Гав! Ще!", 1.6)
	Game.emit_event("ball_fetched")
	act("wag", 2.0)
	end_job(id)


func _drop_ball() -> void:
	if ball and is_instance_valid(ball):
		var gp := ball.global_position
		ball.reparent(get_parent())
		ball.global_position = Vector3(gp.x + 0.2, 0.07, gp.z + 0.2)
	ball = null


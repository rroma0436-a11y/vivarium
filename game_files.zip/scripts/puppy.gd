extends Node3D
## Цуценя Бім: кадри зі справжнього відео; гуляє двором, їсть із мисочки, радіє, коли гладять.

signal arrived

const PIXEL := 0.00122          # розмір пікселя кадру в метрах (стоячий песик ≈ 0.34 м)
const WALK_SPEED := 0.42
const RUN_SPEED := 1.0

var sprite: Sprite3D
var bubble: Label3D
var shadow: MeshInstance3D
var area: Area3D
var bounds := Rect2(-1.4, -3.6, 2.8, 2.2)    # де можна ходити: x, z (z — вглиб, від’ємне)
var target := Vector3.ZERO
var moving := false
var run := false
var busy := false                 # грає дію — не перебивати блуканням
var idle_left := 3.0
var bubble_left := 0.0
var bowl_pos := Vector3(0.9, 0, -2.2)
var _act_left := 0.0               # для кліпів-циклів (нюхає, гавкає): скільки ще грати
var _act_name := ""
var _then: Callable


func _ready() -> void:
	sprite = preload("res://scripts/frame_sprite.gd").new()
	sprite.pixel_size = PIXEL
	sprite.centered = true
	sprite.shaded = false
	sprite.double_sided = true
	add_child(sprite)
	sprite.setup("res://assets/puppy/clips.json")
	sprite.clip_finished.connect(_on_clip_end)
	shadow = Util.blob_shadow(0.26)
	add_child(shadow)
	area = Util.pick_area("puppy", Vector3(0.55, 0.42, 0.3), Vector3(0, 0.21, 0))
	add_child(area)
	bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 40)
	bubble.position = Vector3(0, 0.55, 0)
	add_child(bubble)
	sprite.play("stand_idle")


func _process(delta: float) -> void:
	# кадр стоїть на землі: низ кадру = лапи
	if sprite.texture != null:
		sprite.position.y = sprite.texture.get_height() * PIXEL * 0.5
	if bubble_left > 0.0:
		bubble_left -= delta
		if bubble_left <= 0.0:
			bubble.visible = false
	if moving:
		var to := target - position
		to.y = 0.0
		var d := to.length()
		var v := (RUN_SPEED if run else WALK_SPEED) * delta
		if d <= v:
			position = target
			moving = false
			sprite.play("stand_idle")
			arrived.emit()
			if _then.is_valid():
				var cb := _then
				_then = Callable()
				cb.call()
		else:
			position += to / d * v
			if absf(to.x) > 0.02:
				sprite.flip_h = to.x < 0.0
		return
	if busy:
		if _act_left > 0.0:
			_act_left -= delta
			if _act_left <= 0.0:
				_on_clip_end(_act_name)
		return
	idle_left -= delta
	if idle_left <= 0.0:
		_idle_choice()


func _idle_choice() -> void:
	idle_left = randf_range(4.0, 9.0)
	var g: Dictionary = Game.state["puppy"]
	if g["bowl"] > 0.0 and g["hunger"] > 20.0:
		go_eat()
		return
	var r := randf()
	if r < 0.45:
		walk_to(Vector3(randf_range(bounds.position.x, bounds.end.x), 0, randf_range(bounds.position.y, bounds.end.y)))
	elif r < 0.6:
		act("sniff")
	elif r < 0.72:
		act("look")
	elif r < 0.82 and g["hunger"] > 70.0:
		act("bark")
		say("Гав! Я їсти хочу!")
	else:
		act("wag")


func walk_to(p: Vector3, then := Callable(), running := false) -> void:
	p.x = clampf(p.x, bounds.position.x, bounds.end.x)
	p.z = clampf(p.z, bounds.position.y, bounds.end.y)
	target = p
	moving = true
	run = running
	busy = false
	_then = then
	sprite.play("run" if running else "walk", false)


func act(name: String, then := Callable()) -> void:
	if not sprite.has_clip(name):
		return
	moving = false
	busy = true
	_then = then
	_act_name = name
	_act_left = 0.0
	if sprite.clips[name]["loop"]:
		_act_left = sprite.clip_length(name) * (2.0 if name == "sniff" else 1.0)
	sprite.play(name)


func _on_clip_end(name: String) -> void:
	if moving or name != _act_name:
		return
	_act_left = 0.0
	busy = false
	idle_left = randf_range(2.5, 6.0)
	sprite.play("stand_idle")
	if _then.is_valid():
		var cb := _then
		_then = Callable()
		cb.call()


func say(text: String, secs := 2.6) -> void:
	bubble.text = text
	bubble.visible = true
	bubble_left = secs


func pet() -> void:
	## Погладили: радіє (хвостик, лапа чи гавкіт).
	var opts := ["wag", "paw", "bark", "wag"]
	var a: String = opts[randi() % opts.size()]
	act(a)
	say(["Гав-гав!", "Мені приємно!", "Ще! Ще!", "Ти мій друг!"][randi() % 4])
	Game.puppy_petted()


func go_eat() -> void:
	## Іде до мисочки, «їсть» (нюхає й хрумає) і радіє.
	var spot := bowl_pos + Vector3(-0.32, 0, 0.02)
	walk_to(spot, func():
		sprite.flip_h = false
		act("sniff", func():
			act("sniff", func():
				Game.puppy_ate()
				say("Ням-ням! Смачно!")
				act("wag"))), true)

extends Walker
## Цуценя Бім (модель з Meshy, 9 рухів): гуляє двором, нюхає землю, біжить за Beep,
## їсть із миски, радіє, коли гладять, виляє хвостом, увечері йде до будки.

const HEIGHT := 0.52

var busy := false
var idle_left := 2.0
var bowl_pos := Vector3.ZERO
var home_pos := Vector3.ZERO
var follow: Node3D                 # за ким іноді бігає (Beep)
var _pet_alt := false
var _act_left := 0.0
var _act_then: Callable


func _ready() -> void:
	var ok := setup_model("puppy", HEIGHT, {
		"idle": ["dog_idle"], "sniff": ["idle1"], "walk": ["walk"], "run": ["run"],
		"eat": ["chigouliang"], "pet": ["beifumo"], "pet2": ["dog_petting"],
		"wag": ["yaoweiba"], "over": ["dog_over"],
	}, ["idle", "walk", "run", "wag", "eat"])
	if ok:
		anims["idle"] = Models.find_anim(ap, ["dog_idle"])
		# «dog_idle1» теж містить «dog_idle» — шукаємо точну назву
		for n in ap.get_animation_list():
			if String(n).to_lower().ends_with("dog_idle"):
				anims["idle"] = n
		Models.set_loop(ap, [anims["idle"]])
		_straighten()
	else:
		_placeholder()
	walk_speed = 0.75
	run_speed = 2.1
	setup_common("puppy", Vector3(0.45, 0.55, 0.7), 0.9, 0.32)
	play("idle")


func _straighten() -> void:
	## Модель з Meshy стоїть у файлі під кутом, а голова повернута до глядача.
	## Розвертаємо тіло вздовж руху й довертаємо шию, щоб Бім дивився туди, куди біжить.
	var sks := model.find_children("*", "Skeleton3D", true, false)
	if sks.is_empty():
		return
	var sk: Skeleton3D = sks[0]
	var hips := sk.find_bone("hips")
	var chest := sk.find_bone("chest")
	var neck := sk.find_bone("neck_01")
	var neck2 := sk.find_bone("neck2")
	var head := sk.find_bone("head")
	if hips < 0 or chest < 0 or neck < 0 or head < 0:
		return
	var b := sk.get_bone_global_rest(chest).origin - sk.get_bone_global_rest(hips).origin
	var a_body := atan2(b.x, b.z)
	var h := sk.get_bone_global_rest(head).origin - sk.get_bone_global_rest(neck2 if neck2 >= 0 else neck).origin
	var a_head := atan2(h.x, h.z)
	model.rotation.y = -a_body
	var fix := preload("res://scripts/head_fix.gd").new()
	fix.bone = neck
	fix.yaw = wrapf(a_body - a_head, -PI, PI)
	sk.add_child(fix)


func _placeholder() -> void:
	var body := Util.capsule(0.12, 0.45, Util.mat(Color(0.9, 0.85, 0.75)), Vector3(0, 0.25, 0), Vector3(90, 0, 0))
	add_child(body)
	add_child(Util.sphere(0.12, Util.mat(Color(0.8, 0.55, 0.25)), Vector3(0, 0.4, 0.22)))


func _process(delta: float) -> void:
	_physics_step(delta)
	if _act_left > 0.0:
		_act_left -= delta
		if _act_left <= 0.0:
			var cb := _act_then
			_act_then = Callable()
			busy = false
			if cb.is_valid():
				cb.call()
	if moving:
		play("run" if running else "walk", 1.0)
		return
	if busy:
		return
	idle_left -= delta
	if idle_left > 0.0:
		return
	_choose_next()


func _choose_next() -> void:
	idle_left = randf_range(2.5, 6.0)
	if Game.state["puppy"]["bowl"] > 0.0:
		go_eat()          # у мисці є корм — Бім про нього не забуде
		return
	if Game.is_night():
		if position.distance_to(home_pos + Vector3(0.6, 0, 1.0)) > 0.4:
			walk_to(home_pos + Vector3(0.6, 0, 1.0))
		else:
			face(home_pos + Vector3(2, 0, 4))
			play("idle", 0.6)
			idle_left = 6.0
		return
	var r := randf()
	if follow and follow.global_position.distance_to(global_position) > 4.5 and r < 0.5:
		var p := follow.global_position
		walk_to(Vector3(p.x, 0, p.z) + Vector3(randf_range(-0.8, 0.8), 0, 0.9), true)
	elif r < 0.45:
		walk_to(position + Vector3(randf_range(-3.5, 3.5), 0, randf_range(-3.0, 3.0)))
	elif r < 0.7:
		act("sniff")
	elif r < 0.85:
		act("wag", 2.0)
	else:
		play("idle")


func act(kind: String, cycles := 1.0, then := Callable()) -> void:
	## Зіграти рух повністю (або кілька разів, якщо він по колу), потім then.
	stop()
	busy = true
	play(kind)
	_act_left = anim_length(kind) * cycles
	_act_then = then


func pet(from: Vector3) -> void:
	face(from)
	_pet_alt = not _pet_alt
	say("Гав! ❤" if randf() < 0.5 else "Ще-ще!", 2.0)
	Game.puppy_petted()
	act("pet2" if _pet_alt else "pet", 1.0, func():
		if Game.state["puppy"]["bowl"] > 0.0:
			go_eat()
		else:
			act("wag", 2.0))


func go_eat() -> void:
	busy = false
	walk_to(bowl_pos + (position - bowl_pos).normalized() * 0.42, true, func():
		face(bowl_pos)
		act("eat", 2.0, func():
			Game.puppy_ate()
			say("Ням! Дякую!", 2.0)
			act("wag", 3.0)))


func greet(p: Vector3) -> void:
	## Радісно біжить до точки (наприклад, до дідуся) і виляє хвостом.
	walk_to(p, true, func():
		act("wag", 3.0))

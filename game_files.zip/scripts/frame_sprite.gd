extends Sprite3D
## Кліпи з відео (кадри WebP з прозорістю). Кадри читаються наперед у фоні (ResourceLoader у потоці)
## і тримаються в невеликому кеші — у пам'яті не лежать усі кліпи одразу.

signal clip_finished(name: String)

const AHEAD := 10
const CACHE := 60

var clips: Dictionary = {}
var clip := ""
var t := 0.0
var speed := 1.0
var _cache := {}            # шлях -> Texture2D
var _order: Array = []      # порядок використання (для витіснення)
var _asked := {}            # шлях -> true (уже попросили завантажити)
var _ended := false


func setup(json_path: String) -> void:
	var f := FileAccess.open(json_path, FileAccess.READ)
	clips = JSON.parse_string(f.get_as_text())
	# заздалегідь — перші кадри основних кліпів
	for k in ["stand_idle", "walk"]:
		if clips.has(k):
			for p in clips[k]["frames"].slice(0, 6):
				_ask(p)


func has_clip(name: String) -> bool:
	return clips.has(name)


func clip_length(name: String) -> float:
	var c: Dictionary = clips[name]
	return c["frames"].size() / float(c["fps"])


func play(name: String, restart := true) -> void:
	if not clips.has(name):
		return
	if name == clip and not restart:
		return
	clip = name
	t = 0.0
	_ended = false
	var fr: Array = clips[name]["frames"]
	for i in range(min(AHEAD, fr.size())):
		_ask(fr[i])


func _ask(path: String) -> void:
	if _cache.has(path) or _asked.has(path):
		return
	if ResourceLoader.load_threaded_request(path) == OK:
		_asked[path] = true


func _get_tex(path: String) -> Texture2D:
	if _cache.has(path):
		return _cache[path]
	if _asked.has(path):
		var st := ResourceLoader.load_threaded_get_status(path)
		if st == ResourceLoader.THREAD_LOAD_LOADED:
			var tex: Texture2D = ResourceLoader.load_threaded_get(path)
			_asked.erase(path)
			_put(path, tex)
			return tex
		if st == ResourceLoader.THREAD_LOAD_FAILED or st == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			_asked.erase(path)
		return null
	_ask(path)
	return null


func _put(path: String, tex: Texture2D) -> void:
	_cache[path] = tex
	_order.erase(path)
	_order.append(path)
	while _order.size() > CACHE:
		_cache.erase(_order.pop_front())


func _process(delta: float) -> void:
	if clip == "":
		return
	var c: Dictionary = clips[clip]
	var fr: Array = c["frames"]
	var n := fr.size()
	t += delta * speed
	var i := int(t * float(c["fps"]))
	if c["loop"]:
		i = i % n
	elif i >= n:
		i = n - 1
		if not _ended:
			_ended = true
			clip_finished.emit(clip)
	# наступні кадри — наперед
	for k in range(1, AHEAD):
		var j := i + k
		if c["loop"]:
			j = j % n
		elif j >= n:
			break
		_ask(fr[j])
	var tex := _get_tex(fr[i])
	if tex == null:
		# кадр ще читається — показуємо найближчий готовий попередній
		for back in range(1, 8):
			var j2 := i - back
			if j2 < 0:
				if not c["loop"]:
					break
				j2 += n
			if _cache.has(fr[j2]):
				tex = _cache[fr[j2]]
				break
	if tex != null:
		texture = tex

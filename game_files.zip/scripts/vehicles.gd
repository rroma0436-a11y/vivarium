extends RefCounted
class_name Vehicles
## Спільне для трактора й воза: куди можна їхати (не в річку, не на пагорб вітряка,
## не крізь хати й тин подвір'я) і як дістатися назад (через місток, якщо треба).

const LIMIT := 200.0
const YARD := Rect2(-21.5, -15.5, 31.0, 21.0)       # подвір'я з тином (туди транспорт не заїжджає)
const RIVER_Z := 102.0
const RIVER_HALF := 4.0 + 0.6                         # пів ширини річки з берегами
const BRIDGE_HALF := 1.45                              # пів ширини містка (x від −1.45 до 1.45)
const MILL := Vector3(-82, 0, -50)
const MILL_R := 25.0
const POND := Vector3(-62, 0, 30)
const POND_R := 13.5


static func keep_out(p: Vector3, r: float, from := Vector3.INF) -> Vector3:
	## Виштовхує точку p (центр транспорту радіусом r) з місць, куди їхати не можна.
	p = Obstacles.push_out(p, r, 0.4, Obstacles.all)
	# ставок і пагорб вітряка — кола
	for c in [[POND, POND_R], [MILL, MILL_R]]:
		var d := Vector2(p.x - c[0].x, p.z - c[0].z)
		var rr: float = float(c[1]) + r
		if d.length() < rr:
			d = d.normalized() * rr if d.length() > 0.001 else Vector2(0, rr)
			p.x = c[0].x + d.x
			p.z = c[0].z + d.y
	# подвір'я з тином
	var y := YARD.grow(r)
	if y.has_point(Vector2(p.x, p.z)):
		var dl := p.x - y.position.x
		var dr := y.end.x - p.x
		var dt := p.z - y.position.y
		var db := y.end.y - p.z
		var m := minf(minf(dl, dr), minf(dt, db))
		if m == dl:
			p.x = y.position.x
		elif m == dr:
			p.x = y.end.x
		elif m == dt:
			p.z = y.position.y
		else:
			p.z = y.end.y
	# річка: тільки містком
	if absf(p.z - RIVER_Z) < RIVER_HALF + r * 0.5 and absf(p.x) > BRIDGE_HALF:
		var side := signf(p.z - RIVER_Z) if from == Vector3.INF else signf(from.z - RIVER_Z)
		if side == 0.0:
			side = -1.0
		p.z = RIVER_Z + side * (RIVER_HALF + r * 0.5)
	p.x = clampf(p.x, -LIMIT, LIMIT)
	p.z = clampf(p.z, -LIMIT, LIMIT)
	p.y = 0.0
	return p


static func route(from: Vector3, to: Vector3) -> Array:
	## Точки дороги від from до to: якщо треба через річку — спершу до містка й по ньому.
	var pts: Array = []
	var a := signf(from.z - RIVER_Z)
	var b := signf(to.z - RIVER_Z)
	if a != b and a != 0.0 and b != 0.0:
		pts.append(Vector3(0, 0, RIVER_Z + a * 9.0))
		pts.append(Vector3(0, 0, RIVER_Z - a * 9.0))
	# з далекого півдня (за селом) — дорогою через село
	if from.z > 40.0 and to.z < 20.0:
		pts.append(Vector3(0.6, 0, 30.0))
		pts.append(Vector3(0.6, 0, 18.0))
	pts.append(to)
	return pts


static func steer_target(pos: Vector3, target: Vector3, r: float) -> Vector3:
	## Проміжна точка в обхід хат, дерев і подвір'я.
	var t := Obstacles.steer(pos, target, r, 0.4, Obstacles.all)
	# подвір'я — обходимо кутом
	var y := YARD.grow(r + 1.5)
	var mid := (pos + t) * 0.5
	if y.has_point(Vector2(mid.x, mid.z)) and not y.has_point(Vector2(pos.x, pos.z)):
		var corners: Array = [Vector2(y.position.x, y.position.y), Vector2(y.end.x, y.position.y), Vector2(y.position.x, y.end.y), Vector2(y.end.x, y.end.y)]
		var best: Vector2 = corners[0]
		var bs := INF
		for c in corners:
			var s: float = c.distance_to(Vector2(pos.x, pos.z)) + c.distance_to(Vector2(target.x, target.z))
			if s < bs:
				bs = s
				best = c
		t = Vector3(best.x, 0, best.y)
	return t

extends Walker
## Мешканець ферми з готовими рухами (модель із Meshy): гуляє між точками,
## коли торкнешся — зупиняється, повертається до тебе й щось каже (або танцює).

var kind := ""
var lines: Array = []
var places: Array = []
var busy := false
var idle_left := 3.0
var _act_left := 0.0
var _line := 0


func setup(id: String, height: float, map: Dictionary, loops: Array, talk_lines: Array, where: Array, pick_kind: String) -> void:
	kind = pick_kind
	lines = talk_lines
	places = where
	if not setup_model(id, height, map, loops):
		add_child(Util.capsule(0.2, height * 0.8, Util.mat(Color(0.8, 0.8, 0.85)), Vector3(0, height * 0.45, 0)))
	setup_common(kind, Vector3(0.6, height, 0.6), height + 0.45, 0.35)
	play("idle")


func _process(delta: float) -> void:
	_physics_step(delta)
	if _act_left > 0.0:
		_act_left -= delta
		if _act_left <= 0.0:
			busy = false
	if moving:
		play("run" if running else "walk")
		return
	if busy:
		return
	play("idle")
	if doing != "":
		return
	idle_left -= delta
	if idle_left > 0.0 or places.is_empty():
		return
	idle_left = randf_range(5.0, 11.0)
	if Game.is_night():
		return
	if choose_job():
		return
	var p: Vector3 = places[randi() % places.size()]
	walk_to(p + Vector3(randf_range(-0.8, 0.8), 0, randf_range(-0.8, 0.8)), randf() < 0.15)


func choose_job() -> bool:
	## Нащадки (Тарасик, Гвинтик) обирають тут свої справи. true — справу почато.
	return false


func talk(from: Vector3) -> void:
	if doing != "":
		say(lines[_line % lines.size()] if lines.size() > 0 else "", 2.5)
		_line += 1
		return
	stop()
	face(from)
	busy = true
	if lines.size() > 0:
		say(lines[_line % lines.size()], 3.5)
		_line += 1
	var k := "dance" if anims.get("dance", "") != "" and randf() < 0.4 else "talk"
	if anims.get(k, "") == "":
		k = "idle"
	play(k)
	_act_left = clampf(anim_length(k), 2.5, 6.0)

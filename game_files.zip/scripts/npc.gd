extends Walker
## Мешканець ферми з готовими рухами (модель із Meshy): гуляє між точками,
## коли торкнешся — зупиняється, повертається до тебе й щось каже (або танцює).

var kind := ""
var lines: Array = []
var places: Array = []
var busy := false
var idle_left := 3.0
var _act_left := 0.0
var _line := 0
var main                           # головна сцена (світ, Бім, звук…)
var lives_outside := false         # увечері йде додому за ворота, зранку повертається
var at_home := false
const YARD_BOUNDS := Rect2(-20.5, -14.5, 29.0, 19.0)
const OUT_BOUNDS := Rect2(-20.5, -14.5, 29.0, 33.0)


func setup(id: String, height: float, map: Dictionary, loops: Array, talk_lines: Array, where: Array, pick_kind: String) -> void:
	kind = pick_kind
	lines = talk_lines
	places = where
	if not setup_model(id, height, map, loops):
		add_child(Util.capsule(0.2, height * 0.8, Util.mat(Color(0.8, 0.8, 0.85)), Vector3(0, height * 0.45, 0)))
	setup_common(kind, Vector3(0.6, height, 0.6), height + 0.45, 0.35)
	play("idle")


func _process(delta: float) -> void:
	_physics_step(delta)
	if _act_left > 0.0:
		_act_left -= delta
		if _act_left <= 0.0:
			busy = false
	if moving:
		play("run" if running else "walk")
		return
	if busy:
		return
	play("idle")
	if doing != "":
		return
	idle_left -= delta
	if idle_left > 0.0 or places.is_empty():
		return
	idle_left = randf_range(5.0, 11.0)
	var h := Game.hour()
	if lives_outside and main:
		if not at_home and (h >= 19.3 or h < 6.0):
			go_home()
			return
		if at_home:
			if h >= 7.3 and h < 19.0:
				come_back()
			return
	if Game.is_night():
		return
	if choose_job():
		return
	var p: Vector3 = places[randi() % places.size()]
	walk_to(p + Vector3(randf_range(-0.8, 0.8), 0, randf_range(-0.8, 0.8)), randf() < 0.15)


func go_home() -> void:
	## Через ворота — додому (хата за дорогою); там зникає до ранку.
	var id := begin_job("home")
	var w = main.world
	say("Мені додому! Па-па!", 2.5)
	await go(w.spots["inside_gate"] + Vector3(randf_range(-0.3, 0.3), 0, 0))
	if id != job:
		return
	await w.pass_gate(self, true)
	if id != job:
		return
	bounds = OUT_BOUNDS
	await go(w.spots["kid_home"], false, false)
	if id != job:
		return
	at_home = true
	visible = false
	end_job(id)


func come_back() -> void:
	var id := begin_job("back")
	var w = main.world
	visible = true
	at_home = false
	position = w.spots["kid_home"]
	await go(w.spots["outside_gate"] + Vector3(randf_range(-0.3, 0.3), 0, 0), false, false)
	if id != job:
		return
	await w.pass_gate(self, false)
	if id != job:
		return
	bounds = YARD_BOUNDS
	say("Доброго ранку!", 2.0)
	end_job(id)


func choose_job() -> bool:
	## Нащадки (Тарасик, Гвинтик) обирають тут свої справи. true — справу почато.
	return false


func talk(from: Vector3) -> void:
	if doing != "":
		say(lines[_line % lines.size()] if lines.size() > 0 else "", 2.5)
		_line += 1
		return
	stop()
	face(from)
	busy = true
	if lines.size() > 0:
		say(lines[_line % lines.size()], 3.5)
		_line += 1
	var k := "dance" if anims.get("dance", "") != "" and randf() < 0.4 else "talk"
	if anims.get(k, "") == "":
		k = "idle"
	play(k)
	_act_left = clampf(anim_length(k), 2.5, 6.0)


func make_idle_from(src_key: String, at_frac := 0.25, span := 0.16) -> void:
	## Окремої анімації «стоїть» немає — вирізаємо коротенький шматок ходьби (крок, де ноги разом)
	## і гойдаємо його туди-сюди: персонаж ледь переминається на місці.
	if ap == null or anims.get(src_key, "") == "":
		return
	var src: Animation = ap.get_animation(anims[src_key])
	var t0 := src.length * at_frac
	var t1 := minf(t0 + span, src.length)
	var a := Animation.new()
	a.length = t1 - t0
	a.loop_mode = Animation.LOOP_PINGPONG
	for tr in src.get_track_count():
		var ty := src.track_get_type(tr)
		var nt := a.add_track(ty)
		a.track_set_path(nt, src.track_get_path(tr))
		# значення на початку й у кінці вікна + ключі всередині
		for t in [t0, t1]:
			var v = null
			match ty:
				Animation.TYPE_POSITION_3D:
					v = src.position_track_interpolate(tr, t)
				Animation.TYPE_ROTATION_3D:
					v = src.rotation_track_interpolate(tr, t)
				Animation.TYPE_SCALE_3D:
					v = src.scale_track_interpolate(tr, t)
				_:
					v = null
			if v != null:
				a.track_insert_key(nt, t - t0, v)
		for k in src.track_get_key_count(tr):
			var kt := src.track_get_key_time(tr, k)
			if kt > t0 and kt < t1:
				a.track_insert_key(nt, kt - t0, src.track_get_key_value(tr, k))
	var lib := ap.get_animation_library("")
	if lib:
		var nm := name + "_idle"
		lib.add_animation(nm, a)
		anims["idle"] = nm

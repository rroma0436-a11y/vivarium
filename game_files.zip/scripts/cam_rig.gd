extends Node3D
## Камера, що літає за Beep: тягни пальцем — обертай навколо, щипок двома пальцями — наближай.
## Коротке торкання без руху — це «тап» (сигнал tapped).

signal tapped(screen_pos: Vector2)

var cam: Camera3D
var target := Vector3.ZERO          # куди дивимось (плавно доганяє focus)
var focus := Vector3.ZERO           # куди хочемо дивитись
var yaw := 0.0
var pitch := -22.0
var dist := 7.0
var dist_min := 3.0
var dist_max := 12.0
var yaw_limit := 400.0              # у кімнаті обмежуємо поворот
var yaw_center := 0.0
var blockers: Array = []          # AABB, крізь які камера не пролітає (хата)
var pitch_min := -60.0
var pitch_max := -8.0
var _touches := {}
var _press_pos := Vector2.ZERO
var _press_time := 0.0
var _moved := 0.0
var _pinch0 := 0.0
var _dist0 := 0.0


func _ready() -> void:
	cam = Camera3D.new()
	cam.fov = 50.0
	cam.near = 0.1
	cam.far = 400.0
	add_child(cam)


func setup(pos: Vector3, y: float, p: float, d: float, dmin: float, dmax: float, ylimit := 400.0, pmin := -60.0, pmax := -8.0) -> void:
	pitch_min = pmin
	pitch_max = pmax
	focus = pos
	target = pos
	yaw = y
	yaw_center = y
	pitch = p
	dist = d
	dist_min = dmin
	dist_max = dmax
	yaw_limit = ylimit
	_apply()


func _process(delta: float) -> void:
	target = target.lerp(focus, 1.0 - exp(-delta * 3.0))
	_apply()


func _apply() -> void:
	yaw = clampf(yaw, yaw_center - yaw_limit, yaw_center + yaw_limit)
	pitch = clampf(pitch, pitch_min, pitch_max)
	dist = clampf(dist, dist_min, dist_max)
	var b := Basis.from_euler(Vector3(deg_to_rad(pitch), deg_to_rad(yaw), 0))
	var dir := b * Vector3(0, 0, 1)
	var d := dist
	for box in blockers:
		var hit = (box as AABB).intersects_ray(target, dir)
		if hit != null and not (box as AABB).has_point(target):
			d = minf(d, maxf(target.distance_to(hit) - 0.4, 1.2))
	cam.global_position = target + dir * d
	cam.look_at(target, Vector3.UP)


func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventScreenTouch:
		if e.pressed:
			_touches[e.index] = e.position
			if _touches.size() == 1:
				_press_pos = e.position
				_press_time = Time.get_ticks_msec() / 1000.0
				_moved = 0.0
			elif _touches.size() == 2:
				var v: Array = _touches.values()
				_pinch0 = (v[0] as Vector2).distance_to(v[1])
				_dist0 = dist
				_moved = 999.0
		else:
			_touches.erase(e.index)
			if _touches.is_empty() and _moved < 14.0 and Time.get_ticks_msec() / 1000.0 - _press_time < 0.45:
				tapped.emit(e.position)
	elif e is InputEventScreenDrag:
		_touches[e.index] = e.position
		if _touches.size() == 1:
			_moved += e.relative.length()
			if _moved >= 14.0:
				yaw -= e.relative.x * 0.25
				pitch -= e.relative.y * 0.18
		elif _touches.size() == 2 and _pinch0 > 0.0:
			var v: Array = _touches.values()
			var d := (v[0] as Vector2).distance_to(v[1])
			dist = _dist0 * _pinch0 / maxf(d, 1.0)
	elif e is InputEventMouseButton and e.pressed:
		if e.button_index == MOUSE_BUTTON_WHEEL_UP:
			dist *= 0.9
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			dist *= 1.1

extends "res://scripts/npc.gd"
## Червона Шапочка — дівчинка, що дружить із драконом. Живе на Галявині дракона:
## гуляє, підстрибує, вечорами сидить біля нього. Торкнешся дракона, коли вона поруч, —
## вилазить йому на спину, і можна літати.

var dragon
var riding := false
var _hip_local := Vector3.ZERO
var _met := false
const MEADOW := Rect2(-52.0, -13.0, 24.0, 22.0)


func setup_girl(drg) -> void:
	dragon = drg
	setup("girl", 1.0, {"idle": ["talk"], "walk": ["walking"], "run": ["running"], "skip": ["skip"],
			"talk": ["talk"], "jump": ["jump"], "sit": ["sit_cross"], "stand": ["sit_to_stand"]},
		["walk", "run", "skip", "sit"],
		["Привіт! Я — Червона Шапочка. А це мій друг-дракон!", "Дракон тільки здається грізним — він добрий і лоскотливий!",
		 "У небі ховаються золоті насінинки. Знайдемо їх?", "Торкнись дракона — полетимо разом!",
		 "Згори видно і село, і річку, і вітряк!"],
		[], "girl")
	bounds = MEADOW
	walk_speed = 0.9
	run_speed = 2.2
	_make_idle()
	setup_pose()
	_measure_hips()


func _measure_hips() -> void:
	## Де стегна, коли сидить (щоб посадити рівно на спину дракона).
	play("sit")
	await get_tree().process_frame
	await get_tree().process_frame
	_hip_local = _hips_local()
	play("idle")


func _make_idle() -> void:
	## Окремої анімації «стоїть» у моделі немає — беремо спокійний початок розмови й гойдаємо туди-сюди.
	if ap == null or anims.get("talk", "") == "":
		return
	var lib := ap.get_animation_library("")
	var src: Animation = ap.get_animation(anims["talk"])
	var a: Animation = src.duplicate(true)
	a.length = minf(1.1, src.length)
	a.loop_mode = Animation.LOOP_PINGPONG
	if lib:
		lib.add_animation("girl_idle", a)
		anims["idle"] = "girl_idle"


func _process(delta: float) -> void:
	if riding:
		if _bubble_left > 0.0:
			_bubble_left -= delta
			if _bubble_left <= 0.0:
				bubble.visible = false
		return
	_dragon_obstacles()
	_physics_step(delta)
	if moving:
		play("run" if running else "walk", 1.0)
		return
	if doing != "" or busy:
		if busy:
			_act_left -= delta
			if _act_left <= 0.0:
				busy = false
		return
	if Game.is_night():
		# уночі сидить біля дракона
		if dragon and dragon.state == "rest" and current != "sit":
			var spot: Vector3 = dragon.global_position + dragon.global_transform.basis.x * 2.3 + dragon.global_transform.basis.z * 0.8
			if position.distance_to(spot) > 0.4:
				walk_to(spot)
				return
			face(dragon.global_position + dragon.global_transform.basis.z * 2.0)
			play("sit")
		return
	if current == "sit":
		busy = true
		play("stand")
		_act_left = clampf(anim_length("stand"), 1.0, 4.0)
		return
	play("idle")
	idle_left -= delta
	if idle_left > 0.0:
		return
	idle_left = randf_range(4.0, 9.0)
	var r := randf()
	if r < 0.15:
		busy = true
		play("jump")
		_act_left = minf(anim_length("jump"), 4.0)
		return
	var home: Vector3 = dragon.home if dragon else Vector3(-40, 0, -2)
	var p := home + Vector3(randf_range(-9, 9), 0, randf_range(-8, 8))
	if p.distance_to(home) < 3.5:
		p = home + (p - home).normalized() * 4.0
	walk_to(p, randf() < 0.2)


func _dragon_obstacles() -> void:
	## Дракон, що відпочиває на галявині, — перешкода: дівчинка обходить його, а не йде крізь.
	extra_obs.clear()
	if dragon == null or dragon.state != "rest" or doing == "mount":
		return
	var c: Vector3 = dragon.global_position
	var f: Vector3 = dragon.global_transform.basis.z
	f.y = 0.0
	f = f.normalized()
	for k in [[1.8, 1.2], [0.0, 1.45], [-1.8, 1.15], [-3.4, 0.75]]:
		var p: Vector3 = c + f * float(k[0])
		extra_obs.append([Vector2(p.x, p.z), float(k[1]), 1.0])


func talk(from: Vector3) -> void:
	if riding:
		say("Ух-х! Тримаюся міцно!", 2.0)
		return
	super.talk(from)


func can_ride() -> bool:
	return not riding and doing == "" and dragon != null and visible


func mount() -> void:
	## Підходить до дракона збоку, підстрибує й сідає йому на спину.
	var id := begin_job("mount")
	busy = false
	var side: Vector3 = dragon.global_transform.basis.x
	var spot: Vector3 = dragon.global_position + side * 2.0
	if (global_position - dragon.global_position).dot(side) < 0.0:
		spot = dragon.global_position - side * 2.0
	await go(spot, true, false)
	if id != job:
		return
	face(dragon.global_position)
	await wait(0.35)
	play("jump", 1.3)
	await wait(0.45)
	var from := global_position
	var t := 0.0
	reparent(dragon, true)
	while t < 1.0:
		t = minf(1.0, t + get_process_delta_time() / 0.7)
		var to: Vector3 = dragon.to_global(dragon.seat_local() - _hip_local)
		var p := from.lerp(to, t)
		p.y += sin(t * PI) * 0.8
		global_position = p
		rotation.y = lerp_angle(rotation.y, 0.0, t)
		await get_tree().process_frame
	riding = true
	moving = false
	rotation = Vector3.ZERO
	play("sit")
	if pose:
		pose.ride = 1.0
	end_job(id)


func _hips_local() -> Vector3:
	var sks := model.find_children("*", "Skeleton3D", true, false)
	if sks.is_empty():
		return Vector3(0, 0.25, 0)
	var sk: Skeleton3D = sks[0]
	var b: int = pose.find(sk, "Hips")
	if b < 0:
		return Vector3(0, 0.25, 0)
	return to_local(sk.global_transform * sk.get_bone_global_pose(b).origin)


func seat_on(drg: Node3D) -> void:
	## Щокадру: стегна дівчинки — точно на спині дракона.
	position = drg.seat_local() - _hip_local
	rotation = Vector3.ZERO


func dismount(world_root: Node3D) -> void:
	var id := begin_job("dismount")
	var side: Vector3 = dragon.global_transform.basis.x
	var to: Vector3 = dragon.global_position + side * 2.2
	to.y = 0.0
	riding = false
	if pose:
		pose.ride = 0.0
	reparent(world_root, true)
	play("jump", 1.3)
	var from := global_position
	var t := 0.0
	while t < 1.0:
		t = minf(1.0, t + get_process_delta_time() / 0.7)
		var p := from.lerp(to, t)
		p.y = lerpf(from.y, 0.0, t) + sin(t * PI) * 0.6
		global_position = p
		await get_tree().process_frame
	position.y = 0.0
	rotation = Vector3(0, rotation.y, 0)
	say("Як же гарно було! Ще полетимо?", 3.0)
	await wait(1.0)
	end_job(id)
	idle_left = 3.0

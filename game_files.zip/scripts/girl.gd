extends "res://scripts/npc.gd"
## Ніка — живе в селі, у хаті на заході площі. Зранку гуляє біля хати й фонтану,
## перед обідом ходить на базар, по обіді — у гості до дідуся Петра (через ворота ферми),
## увечері повертається додому й до ранку її не видно (спить).

var riding := false                    # (сумісність: на літаку не літає)
var _met := false
var _visit_day := -1
var _market_day := -1
var plane: Node3D

const OUT := Rect2(-62.0, -70.0, 110.0, 160.0)
const FAR := Rect2(-62.0, -135.0, 110.0, 225.0)      # з дорогою до грибного лісу
const HOME_YARD := Vector3(-20.2, 0, 47.5)      # подвір'ячко перед хатою в селі
const HOME_GATE := Vector3(-17.6, 0, 47.0)      # хвіртка в тину
const ROAD_IN := Vector3(-5.0, 0, 46.0)          # з хвіртки — на дорогу
const MARKET := [Vector3(-6.6, 0, 52.4), Vector3(6.6, 0, 52.4), Vector3(-8.0, 0, 66.8), Vector3(3.9, 0, 50.6), Vector3(9.4, 0, 64.4), Vector3(-9.2, 0, 59.0)]
const SQUARE := [Vector3(-4.5, 0, 55.5), Vector3(4.5, 0, 55.0), Vector3(-5.0, 0, 64.5), Vector3(4.0, 0, 65.0)]


func setup_girl(_unused = null) -> void:
	setup("girl", 1.0, {"idle": ["talk"], "walk": ["walking"], "run": ["running"], "skip": ["skip"],
			"talk": ["talk"], "jump": ["jump"], "sit": ["sit_cross"], "stand": ["sit_to_stand"]},
		["walk", "run", "skip", "sit"],
		["Привіт! Я — Ніка. Живу в селі, у білій хатці біля площі!",
		 "Зранку я ходжу на базар — там пахне хлібом і медом!",
		 "А по обіді біжу в гості до дідуся Петра.",
		 "За фермою є аеродром, а в ангарі — жовтий літак! Beep уміє ним керувати.",
		 "У небі світяться золоті насінинки. Збери їх на літаку!"],
		[], "girl")
	bounds = OUT
	extra_obs = Obstacles.outer
	walk_speed = 0.95
	run_speed = 2.2
	_make_idle()
	setup_pose()


func _make_idle() -> void:
	## Окремої анімації «стоїть» у моделі немає — беремо спокійний початок розмови й гойдаємо туди-сюди.
	if ap == null or anims.get("talk", "") == "":
		return
	var lib := ap.get_animation_library("")
	var src: Animation = ap.get_animation(anims["talk"])
	var a: Animation = src.duplicate(true)
	a.length = minf(1.1, src.length)
	a.loop_mode = Animation.LOOP_PINGPONG
	if lib:
		lib.add_animation("girl_idle", a)
		anims["idle"] = "girl_idle"


func in_yard() -> bool:
	return position.z < 5.0 and position.x > -21.0 and position.x < 9.0


var on_plane: Node3D = null
const PLANE_SEAT := Vector3(0, 1.32, 0.12)


func board_plane(p: Node3D) -> void:
	## Підбігає до літака й залазить у кабіну.
	cancel_job()
	busy = false
	var side: Vector3 = p.to_global(Vector3(-2.6, 0, 0.4))
	var id := begin_job("plane")
	await go(side, true)
	var from := global_position
	var k := 0.0
	play("sit")
	while k < 1.0:
		k = minf(1.0, k + get_process_delta_time() / 0.9)
		var to: Vector3 = p.to_global(PLANE_SEAT)
		var q := from.lerp(to, k)
		q.y += sin(k * PI) * 0.6
		global_position = q
		rotation.y = lerp_angle(rotation.y, p.rotation.y, k)
		await get_tree().process_frame
	on_plane = p
	p.pilot = self
	p.pilot_seat = PLANE_SEAT
	end_job(id)


func leave_plane(p: Node3D) -> void:
	on_plane = null
	p.pilot = null
	p.pilot_seat = Vector3.ZERO
	var from := global_position
	var to: Vector3 = p.to_global(Vector3(-2.6, 0, 0.4))
	to.y = 0.0
	var k := 0.0
	while k < 1.0:
		k = minf(1.0, k + get_process_delta_time() / 0.8)
		var q := from.lerp(to, k)
		q.y = lerpf(from.y, 0.0, k) + sin(k * PI) * 0.5
		global_position = q
		await get_tree().process_frame
	global_position = to
	rotation = Vector3(0, rotation.y, 0)
	current = ""
	play("idle")
	idle_left = 4.0


func _process(delta: float) -> void:
	if on_plane:
		if current != "sit":
			play("sit")
		return
	if not visible:
		# спить удома — зранку виходить
		var hh := Game.hour()
		if hh >= 7.3 and hh < 20.0:
			visible = true
			position = HOME_YARD
			at_home = false
			say("Доброго ранку!", 2.0)
		return
	_physics_step(delta)
	if pose:
		pose.life = lerpf(pose.life, 0.0 if moving or busy else 1.0, 1.0 - exp(-delta * 3.0))
	if moving:
		play("run" if running else "walk", 1.0)
		return
	if doing != "" or busy:
		if busy:
			_act_left -= delta
			if _act_left <= 0.0:
				busy = false
		return
	if current == "sit":
		busy = true
		play("stand")
		_act_left = clampf(anim_length("stand"), 1.0, 4.0)
		return
	play("idle")
	idle_left -= delta
	if idle_left > 0.0:
		return
	idle_left = randf_range(4.0, 9.0)
	_choose()


func _choose() -> void:
	var h := Game.hour()
	var d := int(Game.state["day"])
	if h >= 20.0 or h < 7.0:
		go_home_village()
		return
	if in_yard():
		if h >= 15.0 or randf() < 0.12:
			back_to_village()
			return
		_wander_yard()
		return
	if h >= 12.0 and h < 15.0 and _visit_day != d:
		_visit_day = d
		visit_grandpa()
		return
	if h >= 10.0 and h < 12.5 or _market_day != d and h >= 9.0:
		_market_day = d
		var p: Vector3 = MARKET[randi() % MARKET.size()]
		walk_to(p + Vector3(randf_range(-0.6, 0.6), 0, randf_range(-0.6, 0.6)))
		if randf() < 0.4:
			say(["Мені хлібину, будь ласка!", "Який запашний мед!", "Скільки коштують яблучка?"][randi() % 3], 2.5)
		return
	var r := randf()
	if r < 0.15:
		busy = true
		play("jump")
		_act_left = minf(anim_length("jump"), 4.0)
	elif r < 0.55:
		var q: Vector3 = SQUARE[randi() % SQUARE.size()]
		walk_to(q + Vector3(randf_range(-0.8, 0.8), 0, randf_range(-0.8, 0.8)), randf() < 0.2)
	else:
		walk_to(HOME_YARD + Vector3(randf_range(-1.5, 1.0), 0, randf_range(-2.0, 2.0)))


func _wander_yard() -> void:
	var gp: Node3D = main.grandpa if main else null
	if gp and gp.visible and gp.global_position.z < 4.0 and randf() < 0.6:
		var p: Vector3 = gp.global_position
		var dir := (global_position - p)
		dir.y = 0.0
		if dir.length() < 0.1:
			dir = Vector3(1, 0, 0)
		walk_to(p + dir.normalized() * 1.4)
		if randf() < 0.5:
			say(["Дідусю, а розкажи казку!", "Я принесла пиріжків!", "Дідусю, а що ти робиш?"][randi() % 3], 2.5)
		return
	walk_to(Vector3(randf_range(-10.0, 4.0), 0, randf_range(-4.0, 2.5)))


func visit_grandpa() -> void:
	## Із села — дорогою до ферми, через ворота — на подвір'я.
	var id := begin_job("visit")
	say("Піду до дідуся Петра!", 2.5)
	bounds = OUT
	if position.distance_to(HOME_YARD) < 6.0:
		await go(HOME_GATE)
		if id != job:
			return
	await go(ROAD_IN)
	if id != job:
		return
	await go(Vector3(0.6, 0, 20.0))
	if id != job:
		return
	await go(main.world.spots["outside_gate"] + Vector3(0.4, 0, 0))
	if id != job:
		return
	await main.world.pass_gate(self, false)
	bounds = OUT
	if id != job:
		return
	await go(Vector3(-2.0, 0, 0.5))
	if id != job:
		return
	say("Добридень, дідусю!", 2.5)
	end_job(id)
	idle_left = 2.0


func back_to_village() -> void:
	var id := begin_job("back")
	say("Па-па! Піду додому.", 2.0)
	await go(main.world.spots["inside_gate"] + Vector3(-0.3, 0, 0))
	if id != job:
		return
	await main.world.pass_gate(self, true)
	bounds = OUT
	if id != job:
		return
	await go(Vector3(0.6, 0, 20.0))
	if id != job:
		return
	await go(ROAD_IN)
	if id != job:
		return
	await go(HOME_GATE)
	if id != job:
		return
	end_job(id)
	idle_left = 1.0


func forest_job() -> void:
	## Іде дорогою в грибний ліс із кошиком, збирає гриби й ягоди й повертається додому в село.
	var forest = main.forest if main else null
	if forest == null:
		return
	var id := begin_job("forest")
	say("Піду в ліс по гриби та ягоди!", 2.5)
	bounds = OUT
	if in_yard():
		await go(main.world.spots["inside_gate"] + Vector3(-0.3, 0, 0))
		if id != job:
			return
		await main.world.pass_gate(self, true)
	elif position.distance_to(HOME_YARD) < 6.0:
		await go(HOME_GATE)
		if id != job:
			return
		await go(ROAD_IN)
		if id != job:
			return
		await go(Vector3(0.6, 0, 20.0), true)
		if id != job:
			return
	bounds = FAR
	var basket := take_basket()
	await go(main.world.spots["outside_gate"] + Vector3(0.4, 0, 1.2), true)
	if id != job:
		return
	for wp in FOREST_WAY:
		await go(wp, true)
		if id != job:
			return
	var got := 0
	for it in forest.nearest_goods(FOREST_WAY[FOREST_WAY.size() - 1], 4):
		await go(forest.goods_pos(it) + Vector3(0.5, 0, 0.5))
		if id != job:
			return
		face(forest.goods_pos(it))
		await wait(1.0)
		if id != job:
			return
		var col: Color = forest.kind_color(it)
		var n: int = forest.take(it)
		got += n
		if n > 0:
			Util.basket_add(basket, col, 0.05)
	say("Повний кошик — %d! Бабуся зрадіє." % got if got > 0 else "Сьогодні тут уже все зібрали…", 3.0)
	if got > 0:
		Game.emit_event("forest")
	await wait(1.2)
	if id != job:
		return
	for k in range(FOREST_WAY.size() - 1, -1, -1):
		await go(FOREST_WAY[k], true)
		if id != job:
			return
	await go(Vector3(0.6, 0, 20.0), true)
	if id != job:
		return
	await go(ROAD_IN, true)
	if id != job:
		return
	bounds = OUT
	await go(HOME_GATE)
	if id != job:
		return
	drop_basket()
	end_job(id)
	idle_left = 1.0


func go_home_village() -> void:
	## Увечері — додому: заходить у хвіртку, підходить до хати й зникає до ранку.
	if in_yard():
		await back_to_village()
	var id := begin_job("home")
	if position.distance_to(HOME_YARD) > 5.0:
		await go(HOME_GATE)
		if id != job:
			return
	await go(HOME_YARD + Vector3(-1.2, 0, 0))
	if id != job:
		return
	say("На добраніч!", 1.5)
	await wait(1.2)
	if id != job:
		return
	at_home = true
	visible = false
	end_job(id)


func talk(from: Vector3) -> void:
	super.talk(from)


func can_ride() -> bool:
	return false

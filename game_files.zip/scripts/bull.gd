extends Node3D
## Бик Бодя: пасеться на вигоні біля корівника — повільно ходить, нахиляє голову й щипає траву,
## мукає. Торкнешся — підстрибує. Увечері йде в корівник, зранку виходить.

const PASTURE := Rect2(1.5, -22.0, 12.5, 5.0)
var pasture := PASTURE
var voices := ["Му-у-у!", "Мууу! Привіт!", "Му! Трава смачна!"]
var kind := "bull"
var night_from := 20.0
var speed_k := 1.0
var _inside_p := Vector3.ZERO           # де стоїть у сараї (невидимий)
var door := Vector3(7.0, 0, -21.5)
var model: Node3D
var ap: AnimationPlayer
var bpose
var area: Area3D
var _bubble: Label3D
var _bubble_left := 0.0
var _target := Vector3.ZERO
var _pause := 2.0
var _graze := 0.0
var _busy := 0.0
var mode := "free"          # free, to_shed, inside
var _a := {}
const SPEED := 0.55


func setup(at: Vector3, shed_door: Vector3, id := "bull", h := 1.55, past := PASTURE) -> void:
	door = shed_door
	kind = id
	pasture = past
	position = at
	_target = at
	model = Models.spawn(self, id, h)
	if model == null:
		return
	ap = Models.anim_player(model)
	if ap:
		for k in ["idle", "walk", "run", "jump"]:
			_a[k] = Models.find_anim(ap, [k])
		Models.set_loop(ap, [_a["idle"], _a["walk"], _a["run"]])
		ap.playback_default_blend_time = 0.3
		ap.play(_a["idle"])
		ap.seek(randf() * 3.0, true)
	var sks := model.find_children("*", "Skeleton3D", true, false)
	if sks.size() > 0:
		bpose = preload("res://scripts/bird_pose.gd").new()
		bpose.axis_node = self
		bpose.setup(sks[0])
		sks[0].add_child(bpose)
	area = Util.pick_area("bull", Vector3(1.2, h, h * 1.5), Vector3(0, h * 0.5, 0))
	add_child(area)
	add_child(Util.blob_shadow(0.6, 1.1))
	_bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 44)
	_bubble.pixel_size = 0.004
	_bubble.position = Vector3(0, h + 0.5, 0)
	add_child(_bubble)


func say(t: String, secs := 2.0) -> void:
	_bubble.text = t
	_bubble.visible = true
	_bubble_left = secs


func _play(k: String, sp := 1.0) -> void:
	if ap == null or _a.get(k, "") == "":
		return
	if ap.current_animation != _a[k]:
		ap.play(_a[k])
	ap.speed_scale = sp


func poke() -> void:
	## Торкнулися — мукає й підстрибує на місці.
	if mode == "inside" or mode == "hitched":
		return
	say(voices[randi() % voices.size()], 2.0)
	if _a.get("jump", "") != "":
		_busy = minf(ap.get_animation(_a["jump"]).length, 2.0)
		_target = position
		ap.play(_a["jump"])
		ap.speed_scale = 1.0


func _process(delta: float) -> void:
	if model == null:
		return
	if _bubble_left > 0.0:
		_bubble_left -= delta
		if _bubble_left <= 0.0:
			_bubble.visible = false
	if mode == "hitched":
		return                             # запряжений: рухом керує віз (cart.gd)
	var h := Game.hour()
	var night := h >= night_from or h < 6.3
	if mode == "inside":
		if night:
			kept_in = false
		if not night and not kept_in:
			mode = "free"
			visible = true
			position = door
			_target = door + Vector3(randf_range(-2, 2), 0, 2.5)
			say("Му-у! Доброго ранку!", 2.5)
		return
	if night and (mode == "free" or mode == "to_pasture"):
		send_home()
	if _busy > 0.0:
		_busy -= delta
		return
	var to := _target - position
	to.y = 0.0
	var d := to.length()
	if d > 0.08:
		rotation.y = lerp_angle(rotation.y, atan2(to.x, to.z), 1.0 - exp(-delta * 2.5))
		var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
		var sp := SPEED * speed_k * clampf(fwd.dot(to / d) + 0.3, 0.2, 1.0)
		position += fwd * minf(sp * delta, d)
		if speed_k > 1.5 and _a.get("run", "") != "":
			_play("run", 0.9)
		else:
			_play("walk", 0.9 * clampf(speed_k, 1.0, 1.6))
		if bpose:
			bpose.peck = lerpf(bpose.peck, 0.0, 0.1)
		return
	if mode == "to_shed":
		if _path.size() > 0:
			_target = _path.pop_front()
			return
		mode = "inside"
		visible = false
		speed_k = 1.0
		return
	if mode == "to_pasture":
		mode = "free"
		speed_k = 1.0
	_play("idle")
	if _graze > 0.0:
		_graze -= delta
		if bpose:
			# голова до трави, жує
			bpose.peck = lerpf(bpose.peck, 0.85 + sin(_graze * 5.0) * 0.08, 1.0 - exp(-delta * 2.0))
		return
	if bpose:
		bpose.peck = lerpf(bpose.peck, 0.0, 1.0 - exp(-delta * 2.0))
	_pause -= delta
	if _pause > 0.0:
		return
	_pause = randf_range(2.0, 6.0)
	var r := randf()
	if r < 0.45:
		_graze = randf_range(4.0, 9.0)
	elif r < 0.85:
		_target = Vector3(randf_range(pasture.position.x, pasture.end.x), 0, randf_range(pasture.position.y, pasture.end.y))
	elif r < 0.95:
		say("Му-у-у!", 2.0)



var kept_in := false                    # Тарасик загнав у сарай — до ранку не виходить
var _path: Array = []


func send_home(fast := false) -> void:
	## Іти в сарай (корівник/стайню): спершу до дверей ззовні, потім усередину.
	if mode == "inside":
		return
	mode = "to_shed"
	_graze = 0.0
	_busy = 0.0
	speed_k = 2.0 if fast else 1.0
	_path = [door + door_in]
	_target = door


var door_in := Vector3.ZERO             # куди «заходить» за двері (напрям усередину)


# ------------------------------------------------------------------ запряжений у віз (cart.gd)
func hitch_begin() -> void:
	## Кінь стає в оглобли: власні справи (пастися, у стайню) припиняються.
	if mode == "inside":
		visible = true
		position = door
	mode = "hitched"
	_busy = 0.0
	_graze = 0.0
	_path = []
	speed_k = 1.0
	kept_in = false
	if bpose:
		bpose.peck = 0.0


func hitch_release() -> void:
	## Відпряжений: знову сам собою (увечері піде в стайню).
	mode = "free"
	_target = position
	_pause = 2.0
	say("Дякую, дідусю! І-го-го!", 2.5)


func hitch_move(heading: float, sp: float, dt: float) -> void:
	## Крок під керуванням: повернутися носом до heading й пройти sp·dt метрів уперед.
	rotation.y = heading
	position += Vector3(sin(heading), 0, cos(heading)) * sp * dt
	if sp > 0.15:
		if sp > 2.4 and _a.get("run", "") != "":
			_play("run", clampf(sp / 3.2, 0.7, 1.3))
		else:
			_play("walk", clampf(sp / 1.35, 0.5, 1.8))
	else:
		_play("idle")


func send_out(fast := false) -> void:
	## Вийти на пасовисько.
	kept_in = false
	if mode == "inside":
		visible = true
		position = door
	mode = "to_pasture"
	speed_k = 2.0 if fast else 1.0
	_target = Vector3(randf_range(pasture.position.x, pasture.end.x), 0, randf_range(pasture.position.y, pasture.end.y))

extends Node3D
## Бик Бодя: пасеться на вигоні біля корівника — повільно ходить, нахиляє голову й щипає траву,
## мукає. Торкнешся — підстрибує. Увечері йде в корівник, зранку виходить.

const PASTURE := Rect2(1.5, -22.0, 12.5, 5.0)
var door := Vector3(7.0, 0, -21.5)
var model: Node3D
var ap: AnimationPlayer
var bpose
var area: Area3D
var _bubble: Label3D
var _bubble_left := 0.0
var _target := Vector3.ZERO
var _pause := 2.0
var _graze := 0.0
var _busy := 0.0
var mode := "free"          # free, to_shed, inside
var _a := {}
const SPEED := 0.55


func setup(at: Vector3, shed_door: Vector3) -> void:
	door = shed_door
	position = at
	_target = at
	model = Models.spawn(self, "bull", 1.55)
	if model == null:
		return
	ap = Models.anim_player(model)
	if ap:
		for k in ["idle", "walk", "run", "jump"]:
			_a[k] = Models.find_anim(ap, [k])
		Models.set_loop(ap, [_a["idle"], _a["walk"], _a["run"]])
		ap.playback_default_blend_time = 0.3
		ap.play(_a["idle"])
		ap.seek(randf() * 3.0, true)
	var sks := model.find_children("*", "Skeleton3D", true, false)
	if sks.size() > 0:
		bpose = preload("res://scripts/bird_pose.gd").new()
		bpose.axis_node = self
		bpose.setup(sks[0])
		sks[0].add_child(bpose)
	area = Util.pick_area("bull", Vector3(1.2, 1.6, 2.4), Vector3(0, 0.8, 0))
	add_child(area)
	add_child(Util.blob_shadow(0.6, 1.1))
	_bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 44)
	_bubble.pixel_size = 0.004
	_bubble.position = Vector3(0, 2.1, 0)
	add_child(_bubble)


func say(t: String, secs := 2.0) -> void:
	_bubble.text = t
	_bubble.visible = true
	_bubble_left = secs


func _play(k: String, sp := 1.0) -> void:
	if ap == null or _a.get(k, "") == "":
		return
	if ap.current_animation != _a[k]:
		ap.play(_a[k])
	ap.speed_scale = sp


func poke() -> void:
	## Торкнулися — мукає й підстрибує на місці.
	if mode == "inside":
		return
	say(["Му-у-у!", "Мууу! Привіт!", "Му! Трава смачна!"][randi() % 3], 2.0)
	if _a.get("jump", "") != "":
		_busy = minf(ap.get_animation(_a["jump"]).length, 2.0)
		_target = position
		ap.play(_a["jump"])
		ap.speed_scale = 1.0


func _process(delta: float) -> void:
	if model == null:
		return
	if _bubble_left > 0.0:
		_bubble_left -= delta
		if _bubble_left <= 0.0:
			_bubble.visible = false
	var h := Game.hour()
	var night := h >= 20.0 or h < 6.3
	if mode == "inside":
		if not night:
			mode = "free"
			visible = true
			position = door
			_target = door + Vector3(randf_range(-2, 2), 0, 2.5)
			say("Му-у! Доброго ранку!", 2.5)
		return
	if night and mode == "free":
		mode = "to_shed"
		_target = door
		_graze = 0.0
	if _busy > 0.0:
		_busy -= delta
		return
	var to := _target - position
	to.y = 0.0
	var d := to.length()
	if d > 0.08:
		rotation.y = lerp_angle(rotation.y, atan2(to.x, to.z), 1.0 - exp(-delta * 2.5))
		var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
		var sp := SPEED * clampf(fwd.dot(to / d) + 0.3, 0.2, 1.0)
		position += fwd * minf(sp * delta, d)
		_play("walk", 0.9)
		if bpose:
			bpose.peck = lerpf(bpose.peck, 0.0, 0.1)
		return
	if mode == "to_shed":
		mode = "inside"
		visible = false
		return
	_play("idle")
	if _graze > 0.0:
		_graze -= delta
		if bpose:
			# голова до трави, жує
			bpose.peck = lerpf(bpose.peck, 0.85 + sin(_graze * 5.0) * 0.08, 1.0 - exp(-delta * 2.0))
		return
	if bpose:
		bpose.peck = lerpf(bpose.peck, 0.0, 1.0 - exp(-delta * 2.0))
	_pause -= delta
	if _pause > 0.0:
		return
	_pause = randf_range(2.0, 6.0)
	var r := randf()
	if r < 0.45:
		_graze = randf_range(4.0, 9.0)
	elif r < 0.85:
		_target = Vector3(randf_range(PASTURE.position.x, PASTURE.end.x), 0, randf_range(PASTURE.position.y, PASTURE.end.y))
	elif r < 0.95:
		say("Му-у-у!", 2.0)

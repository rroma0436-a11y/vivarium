extends Node
## Головна сцена: живий фон (відео) позаду 3D, нерухома камера на кожну локацію,
## герої на невидимій «землі», торкання — промінь із камери.

const LOCATIONS := {
	"yard": {"video": "res://assets/bg/yard.ogv", "cam_pos": Vector3(0, 0.62, 0), "cam_rot": Vector3(-5, 0, 0), "fov": 40.0},
	"room": {"image": "res://assets/bg/room.jpg", "cam_pos": Vector3(0, 1.05, 0), "cam_rot": Vector3(-9, 0, 0), "fov": 42.0},
}

var cam: Camera3D
var bg_layer: CanvasLayer
var bg_video: VideoStreamPlayer
var bg_image: TextureRect
var hud
var puppy
var beep
var terrarium
var bowl: Node3D
var bowl_food: MeshInstance3D
var yard_nodes: Array = []
var room_nodes: Array = []
var _shot := ""
var _demo := ""
var _frames := 0


func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shot="):
			_shot = a.substr(7)
		elif a.begins_with("--demo="):
			_demo = a.substr(7)
	_build_world()
	hud = preload("res://scripts/hud.gd").new()
	var ui := CanvasLayer.new()
	ui.layer = 1
	add_child(ui)
	ui.add_child(hud)
	hud.action.connect(_on_action)
	Game.quest_started.connect(_on_quest_started)
	Game.quest_done.connect(_on_quest_done)
	go_to(Game.state["location"], true)
	await get_tree().process_frame
	Game.start_quest()
	if _demo != "":
		_run_demo()


# ------------------------------------------------------------------ світ
func _build_world() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_CANVAS
	env.background_canvas_max_layer = -1
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 0.97, 0.92)
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	bg_layer = CanvasLayer.new()
	bg_layer.layer = -1
	add_child(bg_layer)
	bg_video = VideoStreamPlayer.new()
	bg_video.expand = true
	bg_video.loop = true
	bg_video.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg_layer.add_child(bg_video)
	bg_image = TextureRect.new()
	bg_image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg_image.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg_layer.add_child(bg_image)
	cam = Camera3D.new()
	add_child(cam)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_energy = 1.1
	sun.light_color = Color(1, 0.96, 0.88)
	add_child(sun)
	# подвір'я: цуценя, мисочка, Beep
	puppy = preload("res://scripts/puppy.gd").new()
	puppy.position = Vector3(-0.2, 0, -2.6)
	add_child(puppy)
	bowl = Node3D.new()
	bowl.position = Vector3(0.9, 0, -2.2)
	bowl.add_child(Util.cyl(0.11, 0.08, 0.06, Util.mat(Color(0.85, 0.3, 0.3), 0.35), Vector3(0, 0.03, 0)))
	bowl_food = Util.sphere(0.085, Util.mat(Color(0.55, 0.33, 0.18), 0.9), Vector3(0, 0.058, 0), Vector3(1, 0.3, 1))
	bowl.add_child(bowl_food)
	bowl.add_child(Util.blob_shadow(0.15, 0.3))
	bowl.add_child(Util.pick_area("bowl", Vector3(0.3, 0.2, 0.3), Vector3(0, 0.08, 0)))
	add_child(bowl)
	puppy.bowl_pos = bowl.position
	yard_nodes = [puppy, bowl]
	# кімната: тераріум
	terrarium = preload("res://scripts/terrarium.gd").new()
	terrarium.position = Vector3(-0.95, 0, -2.7)
	terrarium.rotation_degrees.y = 12.0
	add_child(terrarium)
	room_nodes = [terrarium]
	beep = preload("res://scripts/beep.gd").new()
	add_child(beep)


func go_to(loc: String, instant := false) -> void:
	Game.state["location"] = loc
	var L: Dictionary = LOCATIONS[loc]
	cam.position = L["cam_pos"]
	cam.rotation_degrees = L["cam_rot"]
	cam.fov = L["fov"]
	if L.has("video"):
		bg_video.stream = load(L["video"])
		bg_video.visible = true
		bg_image.visible = false
		bg_video.play()
	else:
		bg_video.stop()
		bg_video.visible = false
		bg_image.texture = load(L["image"])
		bg_image.visible = true
	for n in yard_nodes:
		n.visible = loc == "yard"
		n.process_mode = Node.PROCESS_MODE_INHERIT if loc == "yard" else Node.PROCESS_MODE_DISABLED
	for n in room_nodes:
		n.visible = loc == "room"
	beep.position = Vector3(-0.75, 0, -2.0) if loc == "yard" else Vector3(0.25, 0.25, -2.3)
	beep.moving = false
	if hud:
		hud.refresh()


# ------------------------------------------------------------------ дотики
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and event.pressed:
		tap(event.position)


func tap(pos: Vector2) -> void:
	if hud.dialog_open():
		return
	var from := cam.project_ray_origin(pos)
	var dir := cam.project_ray_normal(pos)
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 30.0)
	q.collide_with_areas = true
	q.collide_with_bodies = false
	var hit := cam.get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty() and hit["collider"].is_visible_in_tree():
		_tap_object(String(hit["collider"].get_meta("kind")))
		return
	# земля: Beep летить туди, у дворі цуценя біжить слідом
	if dir.y < -0.01:
		var t := -from.y / dir.y
		var p := from + dir * t
		if Game.state["location"] == "yard":
			puppy.walk_to(p, Callable(), true)
		beep.fly_to(Vector3(p.x, 0, p.z + 0.25))


func _tap_object(kind: String) -> void:
	match kind:
		"beep":
			beep.happy()
			beep.say(_beep_hint(), 3.5)
			Game.emit_event("tap_beep")
		"puppy":
			puppy.pet()
		"bowl":
			_on_action("feed")
		"terrarium":
			hud.toast("%s · %.1f °C" % [Game.gecko_mood(), Game.state["gecko"]["temp"]], 3.0)


func _beep_hint() -> String:
	var q := Game.current_quest()
	if q.is_empty():
		return "Біп! Усе зроблено!"
	if q["where"] != "" and q["where"] != Game.state["location"]:
		return "Біп-буп! Нам треба в %s." % ("подвір'я" if q["where"] == "yard" else "кімнату")
	match q["id"]:
		"meet_beep":
			return "Біп-буп! Привіт! Я Beep."
		"feed_puppy":
			return "Натисни «Корм» — я насиплю!"
		"pet_puppy":
			return "Торкнись Біма, щоб погладити."
		"warm_gecko":
			return "Увімкни лампу й стеж за термометром."
		"feed_gecko":
			return "Коли тепло — натисни «Цвіркуни»."
	return "Біп!"


# ------------------------------------------------------------------ дії з кнопок
func _on_action(name: String) -> void:
	match name:
		"feed":
			if Game.state["puppy"]["bowl"] > 0.0:
				hud.toast("Мисочка вже повна")
				return
			beep.say("Насипаю корм!", 2.0)
			beep.fly_to(bowl.position + Vector3(0, 0, 0.15), func():
				Game.fill_bowl()
				beep.happy()
				puppy.say("Гав! Їжа!")
				puppy.go_eat())
		"lamp":
			var on: bool = Game.toggle_lamp()
			beep.say("Лампу ввімкнено. Стеж за термометром!" if on else "Лампу вимкнено.", 2.5)
		"crickets":
			var msg: String = Game.feed_gecko()
			if msg.begins_with("Ням"):
				terrarium.tongue()
			beep.say(msg, 3.5)
		"help":
			beep.say(_beep_hint(), 3.5)
			beep.happy()
		"go_yard":
			go_to("yard")
		"go_room":
			go_to("room")


func _process(_delta: float) -> void:
	bowl_food.visible = Game.state["puppy"]["bowl"] > 0.0
	_frames += 1
	if _shot != "" and _frames == 45:
		get_viewport().get_texture().get_image().save_png(_shot)
		print("SHOT ", _shot)
		if _demo == "":
			get_tree().quit()


# ------------------------------------------------------------------ квести
func _on_quest_started(q: Dictionary) -> void:
	hud.show_dialog(q["giver"], q["text"])


func _on_quest_done(q: Dictionary) -> void:
	if q.get("done", "") != "":
		hud.toast("+%d ●   %s" % [q["reward"], q["done"]], 3.5)
	await get_tree().create_timer(1.6).timeout
	Game.start_quest()


# ------------------------------------------------------------------ перевірка (лише для розробки)
func _run_demo() -> void:
	var steps: PackedStringArray = _demo.split(",")
	for s in steps:
		await get_tree().create_timer(0.6).timeout
		if hud.dialog_open():
			hud._close_dialog()
			await get_tree().create_timer(0.3).timeout
		print("DEMO ", s)
		if s.begins_with("wait"):
			await get_tree().create_timer(float(s.substr(4))).timeout
		elif s.begins_with("shot:"):
			get_viewport().get_texture().get_image().save_png(s.substr(5))
			print("SHOT ", s.substr(5))
		elif s == "tap_beep":
			tap(cam.unproject_position(beep.global_position + Vector3(0, 0.5, 0)))
		elif s == "tap_puppy":
			tap(cam.unproject_position(puppy.global_position + Vector3(0, 0.2, 0)))
		elif s == "fast":
			Game.state["gecko"]["temp"] = 27.98
			Game.state["gecko"]["lamp"] = true
			Game._tick(1.0)
		else:
			_on_action(s)
	print("DEMO END quest=", Game.state["quest"], " coins=", Game.state["coins"])
	get_tree().quit()

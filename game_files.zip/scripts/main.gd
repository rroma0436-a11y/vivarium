extends Node
## Головна сцена 3D-версії: світ, камера за Beep, персонажі, торкання, квести дідуся.

var world
var audio
var _bark_t := 6.0
var _hen_t := 4.0
var rig
var hud
var puppy
var grandpa
var beep
var terrarium
var kid
var gvintyk
var drone
var birds: Array = []
var geese: Array = []
var dragon
var girl
var seeds
var riding := false                    # дівчинка на драконі, керує гравець
var gold_flower: Node3D
var _geese_day := -1
var ball: Node3D
var _herd_day := -1
var _out_day := -1
var bowl: Node3D
var kibble: Node3D
var _shot := ""
var _demo := ""
var _frames := 0
var _greeted := false
var _track: Node3D
var _last_tap := Vector2.ZERO


func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shot="):
			_shot = a.substr(7)
		elif a.begins_with("--demo="):
			_demo = a.substr(7)
		elif a.begins_with("--time="):
			Game.state["time"] = float(a.substr(7))
	world = preload("res://scripts/world.gd").new()
	add_child(world)
	audio = preload("res://scripts/audio.gd").new()
	audio.name = "Audio"
	add_child(audio)
	rig = preload("res://scripts/cam_rig.gd").new()
	add_child(rig)
	rig.tapped.connect(tap)
	_spawn_characters()
	hud = preload("res://scripts/hud.gd").new()
	var ui := CanvasLayer.new()
	ui.layer = 1
	add_child(ui)
	ui.add_child(hud)
	hud.action.connect(_on_action)
	hud.place_provider = func(): return world.outer.place_name(dragon.global_position if riding else beep.global_position)
	hud.flight.home_pressed.connect(func():
		if dragon and dragon.rider:
			girl.say("Дракончику, додому!", 2.0)
			dragon.go_home())
	hud.build_minimap(world.outer, world.YARD)
	hud.marker_provider = _map_markers
	hud.seed_provider = func() -> Array:
		var a: Array = []
		if seeds:
			for i in seeds.nodes.size():
				if seeds.nodes[i].visible:
					a.append(seeds.SPOTS[i])
		return a
	hud.map_tapped.connect(func(p: Vector3):
		if Game.state["location"] == "yard":
			audio.play("click", -6.0)
			beep.fly_to(p))
	Game.quest_started.connect(_on_quest_started)
	Game.quest_done.connect(_on_quest_done)
	go_to(Game.state["location"], true)
	await get_tree().process_frame
	Game.start_quest()
	if _demo != "":
		_run_demo()


func _spawn_characters() -> void:
	var sp: Dictionary = world.spots
	# миска з кормом (корм — купка гранул, яка зменшується, поки Бім їсть)
	bowl = Node3D.new()
	bowl.position = sp["bowl"]
	world.yard_root.add_child(bowl)
	var bm := Models.spawn(bowl, "bowl", 0.13)
	if bm == null:
		bowl.add_child(Util.cyl(0.14, 0.11, 0.1, Util.mat(Color(0.85, 0.2, 0.2), 0.35), Vector3(0, 0.05, 0)))
	kibble = Node3D.new()
	bowl.add_child(kibble)
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var cols := [Color(0.62, 0.38, 0.18), Color(0.78, 0.52, 0.25), Color(0.9, 0.7, 0.35)]
	for i in 34:
		var a := rng.randf() * TAU
		var r := sqrt(rng.randf()) * 0.1
		var y := 0.075 + (0.1 - r) * 0.35 + rng.randf() * 0.015
		var k := Util.sphere(0.017, Util.mat(cols[i % 3], 0.8), Vector3(cos(a) * r, y, sin(a) * r), Vector3(1.3, 0.8, 1))
		k.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		kibble.add_child(k)
	bowl.add_child(Util.pick_area("bowl", Vector3(0.5, 0.3, 0.5), Vector3(0, 0.1, 0)))
	puppy = preload("res://scripts/puppy.gd").new()
	puppy.position = sp["doghouse"] + Vector3(1.2, 0, 1.6)
	world.yard_root.add_child(puppy)
	puppy.bowl_pos = sp["bowl"]
	puppy.home_pos = sp["doghouse"]
	grandpa = preload("res://scripts/grandpa.gd").new()
	grandpa.spots = sp
	grandpa.world = world
	grandpa.position = sp["porch"] + Vector3(1.2, 0, 0.4)
	world.yard_root.add_child(grandpa)
	grandpa.setup_seats()
	beep = preload("res://scripts/beep.gd").new()
	add_child(beep)
	puppy.follow = beep
	# курочки й півник біля курника
	for i in 5:
		var b := preload("res://scripts/bird.gd").new()
		world.yard_root.add_child(b)
		var at: Vector3 = sp.get("coop", Vector3(6.6, 0, -1.6)) + Vector3(randf_range(-1.5, 0.2), 0, randf_range(-1.2, 1.2))
		if i == 0:
			b.setup("rooster", 0.6, at, true)
		else:
			b.setup("hen", 0.48, at)
	# сусідський хлопчик Тарасик і маленький робот Гвинтик
	if Models.exists("kid"):
		kid = preload("res://scripts/kid.gd").new()
		kid.main = self
		world.yard_root.add_child(kid)
		kid.position = Vector3(-2.5, 0, 2.0)
		kid.setup("kid", 1.15, {"idle": ["idle_022", "idle_02"], "walk": ["walk"], "run": ["run"], "talk": ["listening"]},
			["idle", "walk", "run"],
			["Привіт! Я Тарасик, живу через дорогу.", "А Бім уміє приносити м'ячик?", "Я ношу воду з криниці — я сильний!", "Дідусь каже, що гарбузи вже майже великі!", "Хочеш, покажу, де жаби в ставку?"],
			[Vector3(-2.5, 0, 2.5), Vector3(-2.0, 0, 3.0), Vector3(1.5, 0, 0.5), Vector3(-6.0, 0, -1.0), Vector3(-10.0, 0, -4.0), Vector3(-12.0, 0, -7.5)], "npc")
		kid.setup_pose()
		kid.make_bucket()
		_lives_outside(kid)
	if Models.exists("robot_kid"):
		gvintyk = preload("res://scripts/gvintyk.gd").new()
		gvintyk.main = self
		world.yard_root.add_child(gvintyk)
		gvintyk.position = Vector3(5.6, 0, -2.6)
		gvintyk.setup("robot_kid", 0.9, {"idle": ["idle"], "walk": ["walk"], "run": ["run"], "dance": ["dance"]},
			["idle", "walk", "run", "dance"],
			["Біп! Я Гвинтик — молодший помічник.", "Зарядився на 100%!", "Можна я потанцюю? Біп-біп!", "Я ношу дрова й збираю яйця!"],
			[Vector3(5.6, 0, -2.6), Vector3(4.0, 0, 0.5), Vector3(6.5, 0, -6.0), Vector3(2.5, 0, -3.5), Vector3(-13.0, 0, -2.0), Vector3(-15.0, 0, -7.5)], "npc")
		gvintyk.setup_pose()
		gvintyk.make_props()
		_lives_outside(gvintyk)
	if Models.exists("drone"):
		drone = preload("res://scripts/drone.gd").new()
		world.yard_root.add_child(drone)
		drone.setup(Vector3(-5.6, 0, 2.4), sp)
	for b in world.yard_root.get_children():
		if "rooster" in b:
			birds.append(b)
	# гуси гуляють у лівій частині двору, на ніч ідуть у сарай
	if Models.exists("goose"):
		for i in 3:
			var g := preload("res://scripts/bird.gd").new()
			g.goose = true
			world.yard_root.add_child(g)
			g.setup("goose", 0.62 if i > 0 else 0.7, Vector3(-12.0 + i * 0.9, 0, 1.0 + i * 0.6))
			g.base_radius = 3.5
			g.radius = 3.5
			g.speed *= 0.8
			g.coop_hole = world.spots["barn"] + Vector3(0, 0, -0.75)
			geese.append(g)
	# індик гуляє з гусьми, на ніч теж іде в сарай
	if Models.exists("turkey"):
		var tk := preload("res://scripts/bird.gd").new()
		tk.goose = true
		tk.voice = "Бал-бал-бал!"
		world.yard_root.add_child(tk)
		tk.setup("turkey", 0.85, Vector3(-10.0, 0, -4.5))
		tk.base_radius = 3.0
		tk.radius = 3.0
		tk.speed *= 0.7
		tk.coop_hole = world.spots["barn"] + Vector3(0.6, 0, -0.75)
		geese.append(tk)
	_spawn_shopkeepers()
	if Models.exists("dragon"):
		dragon = preload("res://scripts/dragon.gd").new()
		world.yard_root.add_child(dragon)
		dragon.setup(world.outer.DRAGON_HOME)
		dragon.landed.connect(_on_dragon_landed)
		if Models.exists("girl"):
			girl = preload("res://scripts/girl.gd").new()
			girl.main = self
			world.yard_root.add_child(girl)
			girl.position = world.outer.DRAGON_HOME + Vector3(3.5, 0, 3.0)
			girl.setup_girl(dragon)
		seeds = preload("res://scripts/seeds.gd").new()
		world.yard_root.add_child(seeds)
		seeds.build()
		seeds.dragon = dragon
		seeds.collected.connect(_on_seed)
		if Game.state["seeds"].size() >= seeds.SPOTS.size():
			_make_gold_flower(false)
	puppy.water_pos = sp["water_bowl"]
	puppy.main = self
	terrarium = preload("res://scripts/terrarium.gd").new()
	terrarium.position = sp["terrarium"]
	terrarium.rotation.y = deg_to_rad(18)
	world.room_root.add_child(terrarium)
	terrarium.position = sp["terrarium"] - world.ROOM


func go_to(loc: String, instant := false, keep_beep := false) -> void:
	Game.state["location"] = loc
	beep.outdoors = loc == "yard"
	if loc != "yard":
		beep.lift = 0.0
		beep._lift_want = 0.0
		beep._cruise = false
	cam_follow = null
	_cam_up = 0.8
	if hud:
		hud.show_overview_button(false)
	var sp: Dictionary = world.spots
	rig.blockers = [AABB(world.HOUSE_POS + Vector3(-3.0, 0, -2.4), Vector3(6.0, 4.6, 4.8))] if loc == "yard" else []
	if loc == "yard":
		if not keep_beep:
			beep.position = sp["porch"] + Vector3(2.4, 0, 2.2) if instant or beep.position.z < -500 else sp["porch"] + Vector3(0.4, 0, 1.2)
		rig.setup(sp["door"] + Vector3(0, 0.9, 1.0) if keep_beep else beep.position + Vector3(0, 0.9, 0), 0.0, -20.0, 6.8, 3.0, 26.0)
	else:
		beep.position = world.ROOM + Vector3(-0.3, 0, -1.6)
		rig.setup(world.ROOM + Vector3(0, 1.25, 0.2), 20.0, -14.0, 2.2, 0.3, 2.4, 400.0, -45.0, 8.0)
	if not keep_beep:
		beep.moving = false
	if hud:
		hud.refresh()


func _ambient_voices(delta: float) -> void:
	## Бім іноді гавкає, кури кудкудакають, зранку кукурікає півень, уночі ухкає сова.
	if Game.state["location"] != "yard":
		return
	_bark_t -= delta
	if _bark_t <= 0.0:
		_bark_t = randf_range(10.0, 25.0)
		if not Game.is_night():
			audio.play_at("puppy_bark" if randf() < 0.6 else "small_dog", puppy, -6.0)
	_hen_t -= delta
	if _hen_t <= 0.0:
		_hen_t = randf_range(7.0, 16.0)
		for b in world.yard_root.get_children():
			if "rooster" in b:
				if Game.is_night():
					if randf() < 0.3:
						audio.play_at("owl", world.yard_root, -10.0)
				elif b.rooster and Game.hour() < 9.5 and randf() < 0.5:
					audio.play_at("rooster", b, -4.0)
				else:
					audio.play_at("hens" if randf() < 0.7 else "chicks", b, -10.0)
				break


func _process(_delta: float) -> void:
	var loc: String = Game.state["location"]
	if riding and dragon and dragon.rider and dragon.state != "rest":
		_ride_cam(_delta)
	elif _track:
		rig.focus = _track.global_position + Vector3(0, 0.3, 0)
	elif loc == "yard":
		if cam_follow and (not is_instance_valid(cam_follow) or not cam_follow.is_visible_in_tree()):
			overview()
		if cam_follow:
			rig.focus = cam_follow.global_position + Vector3(0, _cam_up, 0)
		else:
			rig.focus = beep.global_position + Vector3(0, _cam_up + beep.lift, 0)
	kibble.visible = Game.state["puppy"]["bowl"] > 0.0
	if hud and loc == "yard":
		hud.update_map_dot(dragon.global_position if riding else beep.global_position)
	if _frames % 60 == 5 and seeds and hud:
		var flags: Array = []
		for n in seeds.nodes:
			flags.append(n.visible)
		hud.set_seed_dots(seeds.SPOTS, flags)
	_frames += 1
	if _frames % 30 == 0 and hud:
		hud.refresh()
	if _frames % 60 == 0:
		_farm_tick()
	_ambient_voices(_delta)
	if _shot != "" and _frames == 60:
		get_viewport().get_texture().get_image().save_png(_shot)
		print("SHOT ", _shot)
		if _demo == "":
			get_tree().quit()


# ------------------------------------------------------------------ торкання
func tap(pos: Vector2) -> void:
	_last_tap = pos
	if hud.dialog_open() or riding:
		return
	var cam: Camera3D = rig.cam
	var from := cam.project_ray_origin(pos)
	var dir := cam.project_ray_normal(pos)
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 80.0)
	q.collide_with_areas = true
	q.collide_with_bodies = false
	var hit := cam.get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty() and hit["collider"].is_visible_in_tree() and hit["collider"].input_ray_pickable:
		var kind := String(hit["collider"].get_meta("kind"))
		if Game.state["location"] == "yard":
			focus_on(hit["collider"].get_parent(), kind)
		_tap_object(kind)
		return
	if dir.y < -0.01:
		var t := -from.y / dir.y
		var p := from + dir * t
		if Game.state["location"] == "yard":
			p.x = clampf(p.x, -world.outer.LIMIT, world.outer.LIMIT)
			p.z = clampf(p.z, -world.outer.LIMIT, world.outer.LIMIT)
			overview()
			beep.fly_to(p)
			if randf() < 0.35:
				puppy.walk_to(p + Vector3(randf_range(-1, 1), 0, 1.0), true)
		else:
			var r: Vector3 = world.ROOM
			p.x = clampf(p.x, r.x - 3.0, r.x + 3.0)
			p.z = clampf(p.z, r.z - 1.8, r.z + 2.0)
			beep.fly_to(p)
			rig.focus = world.ROOM + Vector3(0, 1.25, 0.2)
			rig.dist = 2.2


func _tap_object(kind: String) -> void:
	match kind:
		"beep":
			audio.play_at("robot_beep", beep, 0.0)
			beep.outdoors = Game.state["location"] == "yard"
			beep.hop()
			if beep.outdoors:
				rig.glide_to(9.0, -24.0)
			beep.say(_beep_hint(), 3.5)
			Game.emit_event("tap_beep")
		"puppy":
			if Game.hour() >= 18.5 and _hens_outside() and puppy.doing != "herd":
				herd_hens()
				return
			beep.fly_to(puppy.global_position + Vector3(0.6, 0, 0.8))
			puppy.pet(rig.cam.global_position)
			audio.play_at("puppy_bark", puppy, -2.0, 1.1)
		"grandpa":
			grandpa.wave_at(rig.cam.global_position)
			var q := Game.current_quest()
			var txt: String = "Відпочинь, онучку. Завтра буде новий день!"
			if not q.is_empty() and q.get("giver", "Дідусь Петро") == "Дідусь Петро":
				txt = q["text"]
			elif not q.is_empty():
				txt = "%s просить тебе: %s" % [q["giver"], q["short"]]
			_grandpa_dialog(txt)
		"bowl":
			_on_action("feed")
		"house":
			enter_house()
		"room_exit":
			leave_house()
		"dragon":
			if dragon:
				if girl and girl.can_ride():
					start_ride()
				else:
					dragon.poke()
		"gold_flower":
			audio.play("magic_bells", -6.0)
			hud.toast("Чарівний соняшник із золотих насінинок", 3.0)
		"girl":
			if girl:
				girl.talk(rig.cam.global_position)
				audio.play_at("question", girl, -4.0, 1.25)
				Game.emit_event("girl_met")
		"bird":
			_poke_nearest_bird()
			audio.play("hens", -6.0)
		"npc":
			var best: Node3D = null
			var bd := INF
			for n in world.yard_root.get_children():
				if n.has_method("talk"):
					var d: float = rig.cam.unproject_position(n.global_position + Vector3(0, 0.6, 0)).distance_to(_last_tap)
					if d < bd:
						bd = d
						best = n
			var qid: String = Game.current_quest().get("id", "")
			if best and best == kid and (qid == "kid_water" or float(Game.state["water_bowl"]) < 25.0 or float(Game.state["trough"]) < 25.0) and kid.doing == "":
				kid.say("Зараз принесу води!", 2.0)
				kid.water_job()
			elif best and best == gvintyk and qid == "eggs" and gvintyk.doing == "":
				gvintyk.eggs_job()
			elif best:
				best.talk(rig.cam.global_position)
				audio.play_at("robot_beep" if "robot" in str(best.model) else "question", best, -4.0)
		"drone":
			for n in world.yard_root.get_children():
				if n.has_method("poke") and n.has_method("setup") and "drops" in n:
					n.poke()
			audio.play("robot_beep", -6.0, 1.4)
		"well":
			audio.play("metal_drop", -8.0)
			beep.say("Вода в криниці холодна й смачна!", 2.5)
		"terrarium":
			# наближаємось до тераріуму; ще раз торкнутися — показати температуру
			var c: Vector3 = terrarium.global_position + Vector3(0, 0.78, 0)
			if rig.focus.distance_to(c) > 0.1:
				rig.focus = c
				rig.dist = 1.15
				rig.pitch = -14.0
				rig.yaw = rad_to_deg(terrarium.rotation.y)
			hud.toast("%s · %.1f °C" % [Game.gecko_mood(), Game.state["gecko"]["temp"]], 3.0)


func _poke_nearest_bird() -> void:
	var best: Node3D = null
	var bd := INF
	var cam_pos: Vector3 = rig.cam.global_position
	for b in world.yard_root.get_children():
		if "rooster" in b:
			var d: float = (b as Node3D).global_position.distance_to(cam_pos)
			if d < bd:
				bd = d
				best = b
	if best:
		best.poke()


func _grandpa_dialog(text: String) -> void:
	grandpa.start_talk(rig.cam.global_position)
	audio.play("page", -8.0)
	hud.show_dialog("Дідусь Петро", text, null, func(): grandpa.end_talk())


func _beep_hint() -> String:
	var q := Game.current_quest()
	if q.is_empty():
		return "Біп! Усе зроблено!"
	if q["where"] != "" and q["where"] != Game.state["location"]:
		return "Біп-буп! Нам треба в %s." % ("подвір'я" if q["where"] == "yard" else "хату — торкнись її")
	match q["id"]:
		"meet_beep":
			return "Біп-буп! Привіт! Я Beep."
		"feed_puppy":
			return "Натисни «Корм» — я насиплю!"
		"pet_puppy":
			return "Торкнись Біма, щоб погладити."
		"warm_gecko":
			return "Увімкни лампу й стеж за термометром."
		"feed_gecko":
			return "Коли тепло — натисни «Цвіркуни»."
	return "Біп!"


# ------------------------------------------------------------------ дії з кнопок
func _on_action(name: String) -> void:
	match name:
		"feed":
			if Game.state["puppy"]["bowl"] > 0.0:
				hud.toast("Мисочка вже повна")
				return
			beep.say("Насипаю корм!", 2.0)
			beep.fly_to(bowl.global_position + Vector3(0.3, 0, 0.5), func():
				Game.fill_bowl()
				audio.play_at("plate", bowl, -4.0)
				beep.happy()
				puppy.say("Гав! Їжа!", 2.0)
				puppy.go_eat())
		"lamp":
			var on: bool = Game.toggle_lamp()
			audio.play("click", 0.0, 0.8)
			beep.say("Лампу ввімкнено. Стеж за термометром!" if on else "Лампу вимкнено.", 2.5)
		"crickets":
			beep.fly_to(terrarium.global_position + Vector3(1.0, 0, 0.1))
			var msg: String = Game.feed_gecko()
			if msg.begins_with("Ням"):
				terrarium.tongue()
				audio.play("pop", -4.0)
			beep.say(msg, 3.5)
		"help":
			hud.show_beep_menu(Game.state["location"] == "yard", Game.is_night(), beep.lamp.visible, grandpa.at_home)
		"hint":
			beep.say(_beep_hint(), 3.5)
			beep.happy()
			audio.play_at("robot_beep", beep, -2.0)
		"drone_feed":
			if drone == null:
				return
			if drone.busy():
				hud.toast("Дрон зараз зайнятий")
				return
			beep.say("Біп! Дроне, нагодуй курей!", 2.5)
			drone.feed_hens()
		"drone_water":
			if drone == null:
				return
			if drone.busy():
				hud.toast("Дрон зараз зайнятий")
				return
			beep.say("Біп! Дроне, полий город!", 2.5)
			drone.water_field()
		"ball":
			throw_ball()
		"light":
			var on: bool = beep.toggle_lamp()
			audio.play("click", -2.0, 1.3)
			beep.say("Ліхтарик увімкнено!" if on else "Ліхтарик вимкнено.", 2.0)
		"scan":
			beep.happy()
			audio.play_at("magic_bells", beep, -6.0)
			hud.show_dialog("Beep · сканер", _scan_text(), load("res://assets/ui/beep.png") if ResourceLoader.exists("res://assets/ui/beep.png") else null)
		"herd":
			if _hens_outside():
				herd_hens()
			else:
				hud.toast("Усі кури вже в курнику")
		"water":
			if kid:
				kid.water_job()
		"overview":
			overview()
		"to_dragon":
			if dragon == null:
				hud.toast("Немає моделі дракона — завантаж на GitHub файл models_3.zip", 5.0)
				return
			if dragon:
				beep.say("Летимо до дракона!", 2.5)
				var at: Vector3 = dragon.home + Vector3(6.0, 0, 4.0)
				beep.fly_to(at, func():
					if girl and not girl.riding:
						girl.face(beep.global_position)
						girl.say("Привіт! Торкнись дракона — полетимо!", 3.5)
					focus_on(dragon, "dragon"))
				overview()
				if dragon.state != "rest" and not riding:
					dragon.go_home()
				dragon._rest_left = maxf(float(dragon._rest_left), 90.0)      # дочекається, поки прилетимо
		"home":
			beep.say("Летимо додому!", 2.0)
			beep.fly_to(world.spots["door"] + Vector3(1.5, 0, 2.0))
			overview()
		"go_yard":
			leave_house()
		"go_room":
			enter_house()
		"grandpa_in":
			grandpa.command_in()
		"grandpa_out":
			grandpa.command_out()
		"sound":
			audio.set_muted(not audio.is_muted())
			hud.buttons["sound"].text = "♪" if not audio.is_muted() else "✕"


# ------------------------------------------------------------------ камера: зосередитись на тому, кого торкнулись, або загальний огляд
var cam_follow: Node3D                 # за ким стежить камера (null — загальний огляд за Beep)
var _cam_up := 0.8
const FOCUS := {
	# вид: [відстань, нахил, висота точки, на яку дивимось]
	"beep": [3.2, -14.0, 0.9], "puppy": [2.4, -14.0, 0.35], "grandpa": [3.4, -10.0, 1.1], "npc": [3.0, -10.0, 0.75],
	"bird": [2.0, -16.0, 0.3], "bowl": [2.6, -30.0, 0.3], "well": [5.5, -16.0, 1.3], "house": [11.0, -14.0, 2.2],
	"drone": [4.5, -14.0, 0.0], "dragon": [9.5, -12.0, 1.4], "barn": [12.0, -16.0, 2.5], "workshop": [9.0, -14.0, 1.4],
	"girl": [2.8, -10.0, 0.65], "gold_flower": [5.0, -12.0, 1.8],
}


var tea_boy
var market_bot


func _spawn_shopkeepers() -> void:
	## Хлопець-школяр працює в чайній, робот EngineBot — на ринку (на площі в селі).
	var o = world.outer
	if Models.exists("student"):
		tea_boy = preload("res://scripts/npc.gd").new()
		tea_boy.name = "TeaBoy"
		tea_boy.main = self
		world.yard_root.add_child(tea_boy)
		var tp: Vector3 = o.TEA_POS
		var to_c: Vector3 = (o.VILLAGE - tp).normalized()
		var side := Vector3(-to_c.z, 0, to_c.x)
		var spots := [tp + to_c * 0.2, tp + to_c * 0.2 + side * 0.9, tp + to_c * 0.2 - side * 0.9, tp + to_c * 2.6]
		tea_boy.position = spots[0]
		tea_boy.setup("student", 1.6, {"idle": ["walking"], "walk": ["walking"], "run": ["running"], "dance": ["all_night"]},
			["walk", "run", "dance"],
			["Вітаю в чайній! Чай із чебрецем чи з м'ятою?", "Є свіжий узвар і пиріжки з вишнями!", "Я тут працюю після школи.",
			 "Сідай на лавку біля фонтану — принесу чаю!", "Кажуть, над селом літає дракон!"], spots, "npc")
		tea_boy.bounds = Rect2(tp.x - 4.0, tp.z - 4.0, 8.0, 8.0)
		tea_boy.avoid = false
		tea_boy.make_idle_from("walk")
		tea_boy.play("idle")
		tea_boy.face(o.VILLAGE)
		tea_boy.set_meta("view_from", to_c)
	if Models.exists("enginebot"):
		market_bot = preload("res://scripts/npc.gd").new()
		market_bot.name = "MarketBot"
		market_bot.main = self
		world.yard_root.add_child(market_bot)
		var mp: Vector3 = o.MARKET_POS
		var to_c2: Vector3 = (o.VILLAGE - mp).normalized()
		var side2 := Vector3(-to_c2.z, 0, to_c2.x)
		var front := mp + to_c2 * 5.6
		var spots2 := [front, front + side2 * 3.0, front - side2 * 3.0, front + to_c2 * 1.5]
		market_bot.position = front
		market_bot.setup("enginebot", 1.9, {"idle": ["walking"], "walk": ["walking"], "run": ["running"]},
			["walk", "run"],
			["Біп-буп! Ринок відкрито!", "Мед, глечики, гарбузи — усе свіже!", "Я EngineBot. Рахую решту без помилок.",
			 "Зілля для курочок, щоб краще неслися? Жартую! Біп!", "Заходь, подивися на прилавки!"], spots2, "npc")
		market_bot.bounds = Rect2(front.x - 5.0, front.z - 5.0, 10.0, 10.0)
		market_bot.avoid = false
		market_bot.make_idle_from("walk")
		market_bot.play("idle")
		market_bot.face(o.VILLAGE)
		market_bot.set_meta("view_from", to_c2)


func _map_markers() -> Array:
	## Для великої мапи: хто де.
	var m: Array = []
	if dragon:
		m.append(["Дракон" + (" (летить)" if dragon.state != "rest" else ""), dragon.global_position, Color(0.55, 0.2, 0.75)])
	if girl and not girl.riding:
		m.append(["Червона Шапочка", girl.global_position, Color(0.9, 0.15, 0.15)])
	if grandpa:
		if grandpa.at_home:
			m.append(["Дідусь (у хаті)", world.HOUSE_POS, Color(0.45, 0.35, 0.25)])
		else:
			m.append(["Дідусь", grandpa.global_position, Color(0.45, 0.35, 0.25)])
	m.append(["Бім", puppy.global_position, Color(0.9, 0.55, 0.15)])
	for n in [kid, gvintyk]:
		if n and n.visible:
			m.append(["Тарасик" if n == kid else "Гвинтик", n.global_position, Color(0.2, 0.55, 0.85) if n == kid else Color(0.4, 0.5, 0.55)])
	if drone:
		m.append(["Дрон", drone.global_position, Color(0.3, 0.6, 0.3)])
	if tea_boy:
		m.append(["Хлопець у чайній", tea_boy.global_position, Color(0.25, 0.35, 0.7)])
	if market_bot:
		m.append(["EngineBot на ринку", market_bot.global_position, Color(0.5, 0.5, 0.6)])
	m.append(["Beep (ти)", beep.global_position if Game.state["location"] == "yard" else world.HOUSE_POS, Color(0.1, 0.7, 0.75)])
	for e in m:
		var pn: String = world.outer.place_name(e[1])
		if String(e[0]).ends_with("(у хаті)"):
			pn = "у хаті"
		e.append(pn)
	return m


# ------------------------------------------------------------------ політ на драконі
func start_ride() -> void:
	if riding or girl == null or dragon == null:
		return
	if dragon.state == "fly":
		girl.say("Дракончику, лети сюди!", 2.5)
		dragon.go_home()
		return
	if dragon.state != "rest":
		return
	riding = true
	dragon.hold = true
	dragon.say("Р-р! Сідай!", 2.0)
	girl.say("Летимо!", 2.0)
	focus_on(dragon, "dragon")
	await girl.mount()
	if not girl.riding:
		riding = false
		dragon.hold = false
		return
	dragon.rider = girl
	dragon.hold = false
	hud.show_flight(true)
	hud.toast("Джойстик — повороти й швидкість, ▲▼ — висота", 4.0)
	rig.glide_to(11.0, -12.0)
	dragon.take_off(true)


var _dbg_cam := Vector3.ZERO          # лише для перевірки: близько до дракона


func _ride_cam(delta: float) -> void:
	## Камера позаду дракона, трохи згори.
	dragon.joy = hud.flight.joy
	dragon.climb = hud.flight.climb
	rig.focus = dragon.global_position + Vector3(0, 2.0, 0)
	rig.target = rig.focus
	var want := rad_to_deg(dragon.rotation.y) + 180.0 + _dbg_cam.y
	if _dbg_cam.x > 0.0:
		rig.dist = _dbg_cam.x
		rig.pitch = _dbg_cam.z
		rig.yaw = want
		rig.focus = dragon.to_global(dragon.seat_local())
		rig.target = rig.focus
		return
	rig.yaw += wrapf(want - rig.yaw, -180.0, 180.0) * (1.0 - exp(-delta * 2.5))
	rig.yaw = wrapf(rig.yaw, rig.yaw_center - 180.0, rig.yaw_center + 180.0)
	if rig._want_dist < 0.0:
		rig.dist = lerpf(rig.dist, 11.0, 1.0 - exp(-delta * 1.0))


func _on_dragon_landed() -> void:
	if dragon.rider == null:
		return
	dragon.rider = null
	dragon.hold = true
	hud.show_flight(false)
	Game.emit_event("dragon_flight")
	focus_on(dragon, "dragon")
	await girl.dismount(world.yard_root)
	riding = false
	dragon.hold = false
	dragon._rest_left = randf_range(40.0, 80.0)


func _on_seed(left: int) -> void:
	audio.play("magic_bells", -2.0, 1.2)
	audio.play("coins", -8.0)
	if left > 0:
		hud.toast("Золота насінинка!  Залишилось: %d" % left, 2.5)
		girl.say(["Є!", "Ура, ще одна!", "Ловимо!", "Яка блискуча!"][randi() % 4], 1.5)
	else:
		hud.toast("Усі золоті насінинки зібрано!", 4.0)
		girl.say("Усі! Летімо додому до дідуся!", 3.0)
		_make_gold_flower(true)


func _make_gold_flower(grow: bool) -> void:
	## Чарівний соняшник біля хати — нагорода за всі насінинки.
	if gold_flower:
		return
	gold_flower = Node3D.new()
	gold_flower.position = GOLD_FLOWER_POS
	world.yard_root.add_child(gold_flower)
	var stem := Util.mat(Color(0.35, 0.6, 0.2), 0.7)
	gold_flower.add_child(Util.cyl(0.05, 0.07, 2.4, stem, Vector3(0, 1.2, 0)))
	for k in 4:
		var leaf := Util.sphere(0.25, stem, Vector3(0.22 if k % 2 == 0 else -0.22, 0.6 + k * 0.4, 0), Vector3(1.3, 0.12, 0.6))
		leaf.rotation.z = 0.5 if k % 2 == 0 else -0.5
		gold_flower.add_child(leaf)
	var head := Node3D.new()
	head.position = Vector3(0, 2.45, 0.08)
	head.rotation.x = deg_to_rad(-18)
	gold_flower.add_child(head)
	var petal := Util.mat(Color(1.0, 0.8, 0.15), 0.35, 0.3, Color(1.0, 0.7, 0.1), 1.2)
	for k in 20:
		var a := TAU * k / 20.0
		var pt := Util.sphere(0.2, petal, Vector3(cos(a) * 0.42, sin(a) * 0.42, 0), Vector3(0.45, 1.0, 0.12))
		pt.rotation.z = a - PI / 2.0
		head.add_child(pt)
	head.add_child(Util.cyl(0.32, 0.32, 0.12, Util.mat(Color(0.4, 0.25, 0.08), 0.8, 0.0, Color(0.5, 0.3, 0.05), 0.4), Vector3(0, 0, 0.03), Vector3(PI / 2, 0, 0)))
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.82, 0.4)
	l.light_energy = 1.4
	l.omni_range = 6.0
	l.position = Vector3(0, 2.5, 0.6)
	gold_flower.add_child(l)
	gold_flower.add_child(Util.pick_area("gold_flower", Vector3(1.2, 3.0, 1.2), Vector3(0, 1.5, 0)))
	if grow:
		gold_flower.scale = Vector3(0.05, 0.05, 0.05)
		create_tween().tween_property(gold_flower, "scale", Vector3.ONE, 6.0).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT).set_delay(2.0)


func focus_on(n: Node3D, kind: String) -> void:
	## Торкнулися персонажа чи предмета — камера підлітає й стежить за ним.
	if n == null or not FOCUS.has(kind):
		return
	if kind == "beep":
		cam_follow = null
	else:
		cam_follow = n
	var f: Array = FOCUS[kind]
	_cam_up = float(f[2])
	rig.glide_to(float(f[0]), float(f[1]))
	if n.has_meta("view_from"):
		# продавці стоять за прилавком — дивимося з боку покупця
		var vf: Vector3 = n.get_meta("view_from")
		rig.yaw = rad_to_deg(atan2(vf.x, vf.z))
	if hud:
		hud.show_overview_button(cam_follow != null)


func overview() -> void:
	## Загальний огляд: камера відлітає вгору й показує все довкола Beep.
	cam_follow = null
	_cam_up = 0.8
	rig.glide_to(15.0, -34.0)
	if hud:
		hud.show_overview_button(false)


# ------------------------------------------------------------------ Beep заходить у хату й виходить через двері
var _door_busy := false


func enter_house() -> void:
	if _door_busy or Game.state["location"] == "room":
		return
	_door_busy = true
	var sp: Dictionary = world.spots
	var door: Vector3 = sp["door"]
	await _beep_fly_and_wait(door + Vector3(0, 0, 0.3))
	world.set_door("house", true)
	await get_tree().create_timer(0.5).timeout
	await _beep_fly_and_wait(door + Vector3(0, 0, -0.9))
	world.set_door("house", false, 0.3)
	go_to("room")
	# у кімнаті: залітає з-за дверей
	var rd: Vector3 = sp["room_door"]
	beep.position = rd + Vector3(0, 0, 1.0)
	world.set_door("room", true, 0.35)
	await get_tree().create_timer(0.35).timeout
	await _beep_fly_and_wait(rd + Vector3(1.3, 0, -2.2))
	world.set_door("room", false)
	_door_busy = false


func leave_house() -> void:
	if _door_busy or Game.state["location"] != "room":
		return
	_door_busy = true
	var sp: Dictionary = world.spots
	var rd: Vector3 = sp["room_door"]
	await _beep_fly_and_wait(rd + Vector3(0, 0, -0.2))
	world.set_door("room", true)
	await get_tree().create_timer(0.5).timeout
	await _beep_fly_and_wait(rd + Vector3(0, 0, 1.0))
	world.set_door("room", false, 0.3)
	go_to("yard", false, true)
	var door: Vector3 = sp["door"]
	beep.position = door + Vector3(0, 0, -0.9)
	world.set_door("house", true, 0.35)
	await get_tree().create_timer(0.35).timeout
	await _beep_fly_and_wait(door + Vector3(0.4, 0, 1.4))
	world.set_door("house", false)
	_door_busy = false


func _beep_fly_and_wait(p: Vector3) -> void:
	var done := [false]
	beep.fly_to_raw(p, func(): done[0] = true)
	var t := 0.0
	while not done[0] and t < 6.0:
		t += get_process_delta_time()
		await get_tree().process_frame


# ------------------------------------------------------------------ життя на фермі
func _lives_outside(n) -> void:
	n.lives_outside = true
	var h := Game.hour()
	if h >= 19.3 or h < 7.3:
		n.at_home = true
		n.visible = false
		n.bounds = n.OUT_BOUNDS
		n.position = world.spots["kid_home"]

func _hens_outside() -> bool:
	for b in birds:
		if b.mode != "inside":
			return true
	return false


func herd_hens() -> void:
	if puppy.doing == "herd":
		return
	beep.say("Біме, жени курочок додому!", 2.5)
	audio.play_at("puppy_bark", puppy, -2.0)
	puppy.herd_hens(birds, world.spots["coop_door"])


func throw_ball() -> void:
	## Beep кидає м'ячик, Бім біжить і приносить.
	if Game.state["location"] != "yard":
		return
	if puppy.doing == "fetch":
		hud.toast("Бім уже біжить за м'ячиком!")
		return
	if ball == null:
		ball = Node3D.new()
		ball.add_child(Util.sphere(0.07, Util.mat(Color(0.9, 0.2, 0.2), 0.4), Vector3.ZERO))
		ball.add_child(Util.sphere(0.071, Util.mat(Color(1, 0.95, 0.4), 0.4), Vector3.ZERO, Vector3(1, 0.25, 1)))
		world.yard_root.add_child(ball)
	if ball.get_parent() != world.yard_root:
		ball.reparent(world.yard_root)
	var from: Vector3 = beep.global_position + Vector3(0, 1.0, 0)
	var a := randf() * TAU
	var to := Vector3(clampf(from.x + cos(a) * randf_range(3.0, 5.5), -20.0, 8.0), 0.07, clampf(from.z + sin(a) * randf_range(3.0, 5.5), -14.0, 4.2))
	to = Obstacles.push_out(to, 0.25)
	ball.global_position = from
	beep.say("Апорт!", 1.5)
	beep.happy()
	audio.play_at("pop", beep, -4.0)
	puppy.say("Гав!", 1.0)
	var tw := create_tween()
	tw.tween_method(func(t: float):
		var p: Vector3 = from.lerp(to, t)
		p.y = lerpf(from.y, 0.07, t) + sin(t * PI) * 1.6
		ball.global_position = p, 0.0, 1.0, 0.9)
	await tw.finished
	puppy.fetch(ball, beep)


func _scan_text() -> String:
	var s := Game.state
	var p: Dictionary = s["puppy"]
	var lines: Array = []
	lines.append("Бім: ситість %d%%, радість %d%%%s" % [100 - int(p["hunger"]), int(p["joy"]), "" if float(s["water_bowl"]) > 1.0 else ", мисочка з водою порожня"])
	lines.append("Кури: %s, %s" % ["нагодовані" if float(s["hens_fed"]) > 30.0 else "голодні", "корито з водою" if float(s["trough"]) > 1.0 else "корито порожнє"])
	var f: Dictionary = s["field"]
	lines.append("Город: вологість %d%%, соняшники виросли на %d%%" % [int(f["water"]), int(float(f["growth"]) * 100.0)])
	lines.append("Яєць у кошику: %d" % int(s.get("eggs", 0)))
	lines.append("Лимончик: %.1f °C — %s" % [float(s["gecko"]["temp"]), Game.gecko_mood()])
	return "\n".join(lines)


func _farm_tick() -> void:
	## Раз на секунду: увечері Бім заганяє курей (якщо гравець не встиг), зранку кури виходять.
	var h := Game.hour()
	var d := int(Game.state["day"])
	var waiting_for_player: bool = Game.current_quest().get("id", "") == "hens_home"
	if (h >= (21.5 if waiting_for_player else 20.3) or h < 5.0) and _hens_outside() and _herd_day != d and puppy.doing != "herd":
		_herd_day = d
		herd_hens()
	if h >= 6.5 and h < 11.0 and _out_day != d:
		_out_day = d
		for b in birds:
			b.come_out(world.spots["coop_door"])
		for g in geese:
			g.come_out(world.spots["barn"])
	# гуси самі йдуть ночувати в сарай
	if (h >= 20.0 or h < 5.0) and _geese_day != d:
		_geese_day = d
		for g in geese:
			if g.mode != "inside":
				g.go_coop(world.spots["barn"])
	if waiting_for_player and h >= 18.5 and h < 18.6:
		hud.toast("Вечоріє! Торкнись Біма — він зажене курей", 3.0)


# ------------------------------------------------------------------ квести
const PORTRAITS := {"Дідусь Петро": "grandpa", "Тарасик": "kid", "Гвинтик": "gvintyk", "Beep": "beep", "Червона Шапочка": "girl"}
const GOLD_FLOWER_POS := Vector3(2.6, 0, -5.4)


func _portrait(giver: String) -> Texture2D:
	var f := "res://assets/ui/%s.png" % PORTRAITS.get(giver, "grandpa")
	return load(f) if ResourceLoader.exists(f) else null


func _on_quest_started(q: Dictionary) -> void:
	var giver: String = q.get("giver", "Дідусь Петро")
	if q["goal"] == "seed" and seeds and seeds.left() == 0:
		Game.complete_quest.call_deferred()
	if giver != "Дідусь Петро":
		audio.play("page", -8.0)
		hud.show_dialog(giver, q["text"], _portrait(giver))
		return
	if not _greeted and Game.state["location"] == "yard":
		_greeted = true
		grandpa.wave_at(rig.cam.global_position)
		await get_tree().create_timer(1.2).timeout
	_grandpa_dialog(q["text"])


func _on_quest_done(q: Dictionary) -> void:
	audio.play("win", -2.0)
	audio.play("coins", -6.0)
	if q.get("done", "") != "":
		hud.toast("+%d ●   %s" % [q["reward"], q["done"]], 3.5)
	await get_tree().create_timer(1.6).timeout
	Game.start_quest()


# ------------------------------------------------------------------ перевірка (лише для розробки)
func _run_demo() -> void:
	var steps: PackedStringArray = _demo.split(",")
	for s in steps:
		await get_tree().create_timer(0.6).timeout
		if hud.dialog_open() and not s.begins_with("shot"):
			hud._close_dialog()
			await get_tree().create_timer(0.3).timeout
		print("DEMO ", s)
		if s.begins_with("wait"):
			await get_tree().create_timer(float(s.substr(4))).timeout
		elif s.begins_with("shot:"):
			get_viewport().get_texture().get_image().save_png(s.substr(5))
			print("SHOT ", s.substr(5))
		elif s.begins_with("time:"):
			Game.state["time"] = float(s.substr(5))
		elif s.begins_with("lookat:"):
			var xz := s.substr(7).split(";")
			_track = Node3D.new()
			add_child(_track)
			_track.position = Vector3(float(xz[0]), float(xz[2]) if xz.size() > 2 else 0.5, float(xz[1]))
		elif s.begins_with("yaw:"):
			rig.yaw = float(s.substr(4))
		elif s.begins_with("dist:"):
			rig.dist = float(s.substr(5))
		elif s.begins_with("pitch:"):
			rig.pitch = float(s.substr(6))
		elif s.begins_with("call:"):
			# call:хто:метод[:аргумент] — для перевірки справ персонажів
			var c := s.substr(5).split(":")
			var who = get(c[0])
			if who:
				var args: Array = []
				if c.size() > 2:
					args.append(c[2])
				who.callv(c[1], args)
		elif s.begins_with("ortho:"):
			# ortho:x;z;розмір — вигляд згори (для розстановки перешкод)
			var c := s.substr(6).split(";")
			rig.set_process(false)
			set_process(false)
			hud.visible = false
			rig.cam.projection = Camera3D.PROJECTION_ORTHOGONAL
			rig.cam.size = float(c[2])
			rig.cam.global_transform = Transform3D(Basis.from_euler(Vector3(-PI / 2, 0, 0)), Vector3(float(c[0]), 40, float(c[1])))
			rig.cam.far = 100.0
		elif s == "persp":
			rig.cam.projection = Camera3D.PROJECTION_PERSPECTIVE
			rig.cam.far = 400.0
			rig.set_process(true)
			set_process(true)
			hud.visible = true
		elif s.begins_with("orthof:"):
			# orthof:x;y;z;розмір;кут — вигляд збоку без перспективи (камера дивиться в точку з боку кута)
			var c := s.substr(7).split(";")
			rig.set_process(false)
			set_process(false)
			hud.visible = false
			var yw := deg_to_rad(float(c[4]))
			var at := Vector3(float(c[0]), float(c[1]), float(c[2]))
			rig.cam.projection = Camera3D.PROJECTION_ORTHOGONAL
			rig.cam.size = float(c[3])
			rig.cam.global_transform = Transform3D(Basis(Vector3.UP, yw), at + Basis(Vector3.UP, yw) * Vector3(0, 0, float(c[5]) if c.size() > 5 else 20.0))
			rig.cam.far = 60.0
		elif s.begins_with("follow:"):
			var c := s.substr(7).split(":")
			focus_on(get(c[0]), c[1])
		elif s.begins_with("joy:"):
			var c := s.substr(4).split(";")
			hud.flight.joy = Vector2(float(c[0]), float(c[1]))
			hud.flight.climb = float(c[2]) if c.size() > 2 else 0.0
		elif s.begins_with("ridecam:"):
			var c := s.substr(8).split(";")
			_dbg_cam = Vector3(float(c[0]), float(c[1]), float(c[2]))
		elif s.begins_with("girlpos:"):
			var c := s.substr(8).split(";")
			girl.stop()
			girl.position = Vector3(float(c[0]), 0, float(c[1]))
			girl.rotation.y = deg_to_rad(float(c[2]))
		elif s == "pp":
			print("PUP ", puppy.global_position, " moving=", puppy.moving, " cur=", puppy.current)
		elif s == "bigmap":
			hud.open_big_map()
		elif s.begins_with("door:"):
			var c := s.substr(5).split(":")
			world.set_door(c[0], c[1] == "1", 0.3)
		elif s.begins_with("tapk:"):
			_tap_object(s.substr(5))
		elif s == "dbg_girl":
			print("PROG ", Game.state["progress"], " seeds=", Game.state["seeds"])
			print("GIRL cur=", girl.current, " pos=", girl.global_position, " doing=", girl.doing, " moving=", girl.moving, " dragon=", dragon.global_position)
		elif s == "mount_only":
			dragon.hold = true
			await girl.mount()
			dragon.rider = girl
		elif s == "ride":
			start_ride()
		elif s == "ride_home":
			dragon.go_home()
		elif s.begins_with("overview"):
			overview()
		elif s.begins_with("fly:"):
			var c := s.substr(4).split(";")
			beep.fly_to(Vector3(float(c[0]), 0, float(c[1])))
		elif s.begins_with("quest:"):
			Game.state["quest"] = int(s.substr(6))
			Game.state["progress"] = 0
			Game.start_quest()
		elif s.begins_with("set:"):
			var c := s.substr(4).split(":")
			Game.state[c[0]] = float(c[1])
		elif s.begins_with("track:"):
			_track = get(s.substr(6))
		elif s == "warm":
			Game.state["gecko"]["temp"] = 30.0
			Game.state["gecko"]["lamp"] = true
		elif s == "tap_beep":
			tap(rig.cam.unproject_position(beep.global_position + Vector3(0, 1.05, 0)))
		elif s == "tap_puppy":
			tap(rig.cam.unproject_position(puppy.global_position + Vector3(0, 0.25, 0)))
		elif s == "tap_grandpa":
			tap(rig.cam.unproject_position(grandpa.global_position + Vector3(0, 1.0, 0)))
		elif s == "tap_house":
			tap(rig.cam.unproject_position(world.HOUSE_POS + Vector3(0, 2.0, 0)))
		elif s.begins_with("focus_puppy"):
			rig.focus = puppy.global_position + Vector3(0, 0.3, 0)
			rig.dist = 2.4
			set_process(false)
		elif s.begins_with("focus_grandpa"):
			rig.focus = grandpa.global_position + Vector3(0, 1.0, 0)
			rig.dist = 3.5
			set_process(false)
		elif s.begins_with("focus_terr"):
			_tap_object("terrarium")
			rig.pitch = -14.0
		elif s.begins_with("portrait:"):
			hud.visible = false
			grandpa.stop()
			grandpa.set_process(false)
			grandpa.play("idle")
			grandpa.ap.speed_scale = 0.0
			set_process(false)
			var head: Vector3 = grandpa.global_position + Vector3(0, 1.36, 0)
			rig.setup(head, rad_to_deg(grandpa.rotation.y) + 18.0, -4.0, 1.5, 0.5, 5.0)
			rig.cam.fov = 30.0
			await get_tree().create_timer(0.5).timeout
			get_viewport().get_texture().get_image().save_png(s.substr(9))
			hud.visible = true
		elif s.begins_with("face:"):
			# face:хто:висота_голови:файл — портрет для діалогу
			var c := s.substr(5).split(":")
			var who: Node3D = get(c[0])
			hud.visible = false
			who.set_process(false)
			if who.has_method("play"):
				who.play("idle")
			if "ap" in who and who.ap:
				who.ap.speed_scale = 0.0
			set_process(false)
			var head: Vector3 = who.global_position + Vector3(0, float(c[1]), 0)
			rig.setup(head, rad_to_deg(who.rotation.y) + 15.0, -4.0, float(c[3]) if c.size() > 3 else 1.2, 0.3, 5.0)
			rig.cam.fov = 30.0
			await get_tree().create_timer(0.5).timeout
			get_viewport().get_texture().get_image().save_png(c[2])
			hud.visible = true
			set_process(true)
			who.set_process(true)
		elif s.begins_with("pupwalk"):
			puppy.position = Vector3(-2, 0, 0)
			puppy.rotation.y = 0.0
			puppy.walk_to(Vector3(-2, 0, 3.5))
			puppy.set_process(true)
		elif s.begins_with("camside"):
			_track = puppy
			rig.setup(puppy.global_position + Vector3(0, 0.3, 0), 90.0, -18.0, 2.6, 1.0, 9.0)
		elif s.begins_with("camfront"):
			_track = puppy
			rig.setup(puppy.global_position + Vector3(0, 0.3, 0), 0.0, -18.0, 2.6, 1.0, 9.0)
		elif s == "dbg2":
			for n in world.yard_root.get_children():
				if n.has_method("talk") or "drops" in n:
					print("NODE ", n.get_script().resource_path.get_file(), " ", n.global_position, " vis=", n.visible, " model=", n.get("model"))
		elif s == "dbg":
			var g: Node3D = terrarium.gecko
			for mi in g.find_children("*", "MeshInstance3D", true, false):
				print("GECKO mesh aabb ", (mi as MeshInstance3D).global_transform * (mi as MeshInstance3D).get_aabb())
			print("GECKO pos ", g.global_position, " terr ", terrarium.global_position)
			var tm: Node3D = terrarium.get_child(0)
			for mi in tm.find_children("*", "MeshInstance3D", true, false):
				print("TERR aabb ", (mi as MeshInstance3D).global_transform * (mi as MeshInstance3D).get_aabb())
		elif s == "fast":
			Game.state["gecko"]["temp"] = 27.98
			Game.state["gecko"]["lamp"] = true
			Game._tick(1.0)
		else:
			_on_action(s)
	print("DEMO END quest=", Game.state["quest"], " coins=", Game.state["coins"])
	get_tree().quit()

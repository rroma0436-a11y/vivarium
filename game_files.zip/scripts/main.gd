extends Node
## Головна сцена 3D-версії: світ, камера за Beep, персонажі, торкання, квести дідуся.

var world
var audio
var _bark_t := 6.0
var _hen_t := 4.0
var rig
var hud
var puppy
var grandpa
var beep
var terrarium
var bowl: Node3D
var kibble: Node3D
var _shot := ""
var _demo := ""
var _frames := 0
var _greeted := false
var _track: Node3D
var _last_tap := Vector2.ZERO


func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shot="):
			_shot = a.substr(7)
		elif a.begins_with("--demo="):
			_demo = a.substr(7)
		elif a.begins_with("--time="):
			Game.state["time"] = float(a.substr(7))
	world = preload("res://scripts/world.gd").new()
	add_child(world)
	audio = preload("res://scripts/audio.gd").new()
	audio.name = "Audio"
	add_child(audio)
	rig = preload("res://scripts/cam_rig.gd").new()
	add_child(rig)
	rig.tapped.connect(tap)
	_spawn_characters()
	hud = preload("res://scripts/hud.gd").new()
	var ui := CanvasLayer.new()
	ui.layer = 1
	add_child(ui)
	ui.add_child(hud)
	hud.action.connect(_on_action)
	Game.quest_started.connect(_on_quest_started)
	Game.quest_done.connect(_on_quest_done)
	go_to(Game.state["location"], true)
	await get_tree().process_frame
	Game.start_quest()
	if _demo != "":
		_run_demo()


func _spawn_characters() -> void:
	var sp: Dictionary = world.spots
	# миска з кормом (корм — купка гранул, яка зменшується, поки Бім їсть)
	bowl = Node3D.new()
	bowl.position = sp["bowl"]
	world.yard_root.add_child(bowl)
	var bm := Models.spawn(bowl, "bowl", 0.13)
	if bm == null:
		bowl.add_child(Util.cyl(0.14, 0.11, 0.1, Util.mat(Color(0.85, 0.2, 0.2), 0.35), Vector3(0, 0.05, 0)))
	kibble = Node3D.new()
	bowl.add_child(kibble)
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var cols := [Color(0.62, 0.38, 0.18), Color(0.78, 0.52, 0.25), Color(0.9, 0.7, 0.35)]
	for i in 34:
		var a := rng.randf() * TAU
		var r := sqrt(rng.randf()) * 0.1
		var y := 0.075 + (0.1 - r) * 0.35 + rng.randf() * 0.015
		var k := Util.sphere(0.017, Util.mat(cols[i % 3], 0.8), Vector3(cos(a) * r, y, sin(a) * r), Vector3(1.3, 0.8, 1))
		k.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		kibble.add_child(k)
	bowl.add_child(Util.pick_area("bowl", Vector3(0.5, 0.3, 0.5), Vector3(0, 0.1, 0)))
	puppy = preload("res://scripts/puppy.gd").new()
	puppy.position = sp["doghouse"] + Vector3(1.2, 0, 1.6)
	world.yard_root.add_child(puppy)
	puppy.bowl_pos = sp["bowl"]
	puppy.home_pos = sp["doghouse"]
	grandpa = preload("res://scripts/grandpa.gd").new()
	grandpa.spots = sp
	grandpa.position = sp["porch"] + Vector3(1.2, 0, 0.4)
	world.yard_root.add_child(grandpa)
	beep = preload("res://scripts/beep.gd").new()
	add_child(beep)
	puppy.follow = beep
	# курочки й півник біля курника
	for i in 3:
		var b := preload("res://scripts/bird.gd").new()
		world.yard_root.add_child(b)
		var at: Vector3 = sp.get("coop", Vector3(6.6, 0, -1.6)) + Vector3(randf_range(-1.5, 0.2), 0, randf_range(-1.2, 1.2))
		if i == 0:
			b.setup("rooster", 0.6, at, true)
		else:
			b.setup("hen", 0.48, at)
	# сусідський хлопчик Тарасик і маленький робот Гвинтик
	var NPC := preload("res://scripts/npc.gd")
	if Models.exists("kid"):
		var kid = NPC.new()
		world.yard_root.add_child(kid)
		kid.position = Vector3(-4.6, 0, 2.0)
		kid.setup("kid", 1.15, {"idle": ["idle_03", "idle"], "walk": ["walk"], "run": ["run"], "talk": ["listening", "idle_02"]},
			["idle", "walk", "run"],
			["Привіт! Я Тарасик, живу через дорогу.", "А Бім уміє приносити палицю?", "Дідусь каже, що гарбузи вже майже великі!", "Хочеш, покажу, де жаби в ставку?"],
			[Vector3(-5.5, 0, 2.6), Vector3(-2.0, 0, 3.0), Vector3(1.5, 0, 0.5), Vector3(-6.0, 0, -1.0)], "npc")
	if Models.exists("robot_kid"):
		var rb = NPC.new()
		world.yard_root.add_child(rb)
		rb.position = Vector3(5.6, 0, -2.6)
		rb.setup("robot_kid", 0.9, {"idle": ["idle"], "walk": ["walk"], "run": ["run"], "dance": ["dance"]},
			["idle", "walk", "run", "dance"],
			["Біп! Я Гвинтик — молодший помічник.", "Зарядився на 100%!", "Можна я потанцюю? Біп-біп!", "Курочки сьогодні знесли три яйця!"],
			[Vector3(5.6, 0, -2.6), Vector3(4.0, 0, 0.5), Vector3(6.5, 0, -6.0), Vector3(2.5, 0, -3.5)], "npc")
	if Models.exists("drone"):
		var dr := preload("res://scripts/drone.gd").new()
		world.yard_root.add_child(dr)
		dr.setup(Vector3(-5.6, 0, 2.4))
	terrarium = preload("res://scripts/terrarium.gd").new()
	terrarium.position = sp["terrarium"]
	terrarium.rotation.y = deg_to_rad(18)
	world.room_root.add_child(terrarium)
	terrarium.position = sp["terrarium"] - world.ROOM


func go_to(loc: String, instant := false) -> void:
	Game.state["location"] = loc
	var sp: Dictionary = world.spots
	rig.blockers = [AABB(world.HOUSE_POS + Vector3(-3.0, 0, -2.4), Vector3(6.0, 4.6, 4.8))] if loc == "yard" else []
	if loc == "yard":
		beep.position = sp["porch"] + Vector3(2.4, 0, 2.2) if instant or beep.position.z > 100 else sp["porch"] + Vector3(0.4, 0, 1.2)
		rig.setup(beep.position + Vector3(0, 0.9, 0), 0.0, -20.0, 6.8, 3.0, 14.0)
	else:
		beep.position = world.ROOM + Vector3(-0.3, 0, -1.6)
		rig.setup(world.ROOM + Vector3(0, 1.25, 0.2), 20.0, -14.0, 2.2, 0.3, 2.4, 400.0, -45.0, 8.0)
	beep.moving = false
	if hud:
		hud.refresh()


func _ambient_voices(delta: float) -> void:
	## Бім іноді гавкає, кури кудкудакають, зранку кукурікає півень, уночі ухкає сова.
	if Game.state["location"] != "yard":
		return
	_bark_t -= delta
	if _bark_t <= 0.0:
		_bark_t = randf_range(10.0, 25.0)
		if not Game.is_night():
			audio.play_at("puppy_bark" if randf() < 0.6 else "small_dog", puppy, -6.0)
	_hen_t -= delta
	if _hen_t <= 0.0:
		_hen_t = randf_range(7.0, 16.0)
		for b in world.yard_root.get_children():
			if "rooster" in b:
				if Game.is_night():
					if randf() < 0.3:
						audio.play_at("owl", world.yard_root, -10.0)
				elif b.rooster and Game.hour() < 9.5 and randf() < 0.5:
					audio.play_at("rooster", b, -4.0)
				else:
					audio.play_at("hens" if randf() < 0.7 else "chicks", b, -10.0)
				break


func _process(_delta: float) -> void:
	var loc: String = Game.state["location"]
	if _track:
		rig.focus = _track.global_position + Vector3(0, 0.3, 0)
	elif loc == "yard":
		rig.focus = beep.global_position + Vector3(0, 0.8, 0)
	kibble.visible = Game.state["puppy"]["bowl"] > 0.0
	_frames += 1
	if _frames % 30 == 0 and hud:
		hud.refresh()
	_ambient_voices(_delta)
	if _shot != "" and _frames == 60:
		get_viewport().get_texture().get_image().save_png(_shot)
		print("SHOT ", _shot)
		if _demo == "":
			get_tree().quit()


# ------------------------------------------------------------------ торкання
func tap(pos: Vector2) -> void:
	_last_tap = pos
	if hud.dialog_open():
		return
	var cam: Camera3D = rig.cam
	var from := cam.project_ray_origin(pos)
	var dir := cam.project_ray_normal(pos)
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 80.0)
	q.collide_with_areas = true
	q.collide_with_bodies = false
	var hit := cam.get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty() and hit["collider"].is_visible_in_tree() and hit["collider"].input_ray_pickable:
		_tap_object(String(hit["collider"].get_meta("kind")))
		return
	if dir.y < -0.01:
		var t := -from.y / dir.y
		var p := from + dir * t
		if Game.state["location"] == "yard":
			p.x = clampf(p.x, -8.5, 8.5)
			p.z = clampf(p.z, -6.8, 4.5)
			beep.fly_to(p)
			if randf() < 0.35:
				puppy.walk_to(p + Vector3(randf_range(-1, 1), 0, 1.0), true)
		else:
			var r: Vector3 = world.ROOM
			p.x = clampf(p.x, r.x - 3.0, r.x + 3.0)
			p.z = clampf(p.z, r.z - 1.8, r.z + 2.0)
			beep.fly_to(p)
			rig.focus = world.ROOM + Vector3(0, 1.25, 0.2)
			rig.dist = 2.2


func _tap_object(kind: String) -> void:
	match kind:
		"beep":
			audio.play_at("robot_beep", beep, 0.0)
			beep.happy()
			beep.say(_beep_hint(), 3.5)
			Game.emit_event("tap_beep")
		"puppy":
			beep.fly_to(puppy.global_position + Vector3(0.6, 0, 0.8))
			puppy.pet(rig.cam.global_position)
			audio.play_at("puppy_bark", puppy, -2.0, 1.1)
		"grandpa":
			grandpa.wave_at(rig.cam.global_position)
			var q := Game.current_quest()
			var txt: String = q["text"] if not q.is_empty() else "Відпочинь, онучку. Завтра буде новий день!"
			_grandpa_dialog(txt)
		"bowl":
			_on_action("feed")
		"house":
			audio.play("door_open", -4.0)
			go_to("room")
		"room_exit":
			audio.play("door_close", -4.0)
			go_to("yard")
		"bird":
			_poke_nearest_bird()
			audio.play("hens", -6.0)
		"npc":
			var best: Node3D = null
			var bd := INF
			for n in world.yard_root.get_children():
				if n.has_method("talk"):
					var d: float = rig.cam.unproject_position(n.global_position + Vector3(0, 0.6, 0)).distance_to(_last_tap)
					if d < bd:
						bd = d
						best = n
			if best:
				best.talk(rig.cam.global_position)
				audio.play_at("robot_beep" if "robot" in str(best.model) else "question", best, -4.0)
		"drone":
			for n in world.yard_root.get_children():
				if n.has_method("poke") and n.has_method("setup") and "drops" in n:
					n.poke()
			audio.play("robot_beep", -6.0, 1.4)
		"well":
			audio.play("metal_drop", -8.0)
			beep.say("Вода в криниці холодна й смачна!", 2.5)
		"terrarium":
			# наближаємось до тераріуму; ще раз торкнутися — показати температуру
			var c: Vector3 = terrarium.global_position + Vector3(0, 0.78, 0)
			if rig.focus.distance_to(c) > 0.1:
				rig.focus = c
				rig.dist = 1.15
				rig.pitch = -14.0
				rig.yaw = rad_to_deg(terrarium.rotation.y)
			hud.toast("%s · %.1f °C" % [Game.gecko_mood(), Game.state["gecko"]["temp"]], 3.0)


func _poke_nearest_bird() -> void:
	var best: Node3D = null
	var bd := INF
	var cam_pos: Vector3 = rig.cam.global_position
	for b in world.yard_root.get_children():
		if "rooster" in b:
			var d: float = (b as Node3D).global_position.distance_to(cam_pos)
			if d < bd:
				bd = d
				best = b
	if best:
		best.poke()


func _grandpa_dialog(text: String) -> void:
	grandpa.start_talk(rig.cam.global_position)
	audio.play("page", -8.0)
	hud.show_dialog("Дідусь Петро", text, null, func(): grandpa.end_talk())


func _beep_hint() -> String:
	var q := Game.current_quest()
	if q.is_empty():
		return "Біп! Усе зроблено!"
	if q["where"] != "" and q["where"] != Game.state["location"]:
		return "Біп-буп! Нам треба в %s." % ("подвір'я" if q["where"] == "yard" else "хату — торкнись її")
	match q["id"]:
		"meet_beep":
			return "Біп-буп! Привіт! Я Beep."
		"feed_puppy":
			return "Натисни «Корм» — я насиплю!"
		"pet_puppy":
			return "Торкнись Біма, щоб погладити."
		"warm_gecko":
			return "Увімкни лампу й стеж за термометром."
		"feed_gecko":
			return "Коли тепло — натисни «Цвіркуни»."
	return "Біп!"


# ------------------------------------------------------------------ дії з кнопок
func _on_action(name: String) -> void:
	match name:
		"feed":
			if Game.state["puppy"]["bowl"] > 0.0:
				hud.toast("Мисочка вже повна")
				return
			beep.say("Насипаю корм!", 2.0)
			beep.fly_to(bowl.global_position + Vector3(0.3, 0, 0.5), func():
				Game.fill_bowl()
				audio.play_at("plate", bowl, -4.0)
				beep.happy()
				puppy.say("Гав! Їжа!", 2.0)
				puppy.go_eat())
		"lamp":
			var on: bool = Game.toggle_lamp()
			audio.play("click", 0.0, 0.8)
			beep.say("Лампу ввімкнено. Стеж за термометром!" if on else "Лампу вимкнено.", 2.5)
		"crickets":
			beep.fly_to(terrarium.global_position + Vector3(1.0, 0, 0.1))
			var msg: String = Game.feed_gecko()
			if msg.begins_with("Ням"):
				terrarium.tongue()
				audio.play("pop", -4.0)
			beep.say(msg, 3.5)
		"help":
			beep.say(_beep_hint(), 3.5)
			beep.happy()
		"go_yard":
			audio.play("door_close", -4.0)
			go_to("yard")
		"go_room":
			audio.play("door_open", -4.0)
			go_to("room")
		"sound":
			audio.set_muted(not audio.is_muted())
			hud.buttons["sound"].text = "♪" if not audio.is_muted() else "✕"


# ------------------------------------------------------------------ квести
func _on_quest_started(q: Dictionary) -> void:
	if not _greeted and Game.state["location"] == "yard":
		_greeted = true
		grandpa.wave_at(rig.cam.global_position)
		await get_tree().create_timer(1.2).timeout
	_grandpa_dialog(q["text"])


func _on_quest_done(q: Dictionary) -> void:
	audio.play("win", -2.0)
	audio.play("coins", -6.0)
	if q.get("done", "") != "":
		hud.toast("+%d ●   %s" % [q["reward"], q["done"]], 3.5)
	await get_tree().create_timer(1.6).timeout
	Game.start_quest()


# ------------------------------------------------------------------ перевірка (лише для розробки)
func _run_demo() -> void:
	var steps: PackedStringArray = _demo.split(",")
	for s in steps:
		await get_tree().create_timer(0.6).timeout
		if hud.dialog_open() and not s.begins_with("shot"):
			hud._close_dialog()
			await get_tree().create_timer(0.3).timeout
		print("DEMO ", s)
		if s.begins_with("wait"):
			await get_tree().create_timer(float(s.substr(4))).timeout
		elif s.begins_with("shot:"):
			get_viewport().get_texture().get_image().save_png(s.substr(5))
			print("SHOT ", s.substr(5))
		elif s.begins_with("time:"):
			Game.state["time"] = float(s.substr(5))
		elif s.begins_with("lookat:"):
			var xz := s.substr(7).split(";")
			_track = Node3D.new()
			add_child(_track)
			_track.position = Vector3(float(xz[0]), 0.5, float(xz[1]))
		elif s.begins_with("yaw:"):
			rig.yaw = float(s.substr(4))
		elif s.begins_with("dist:"):
			rig.dist = float(s.substr(5))
		elif s == "tap_beep":
			tap(rig.cam.unproject_position(beep.global_position + Vector3(0, 1.05, 0)))
		elif s == "tap_puppy":
			tap(rig.cam.unproject_position(puppy.global_position + Vector3(0, 0.25, 0)))
		elif s == "tap_grandpa":
			tap(rig.cam.unproject_position(grandpa.global_position + Vector3(0, 1.0, 0)))
		elif s == "tap_house":
			tap(rig.cam.unproject_position(world.HOUSE_POS + Vector3(0, 2.0, 0)))
		elif s.begins_with("focus_puppy"):
			rig.focus = puppy.global_position + Vector3(0, 0.3, 0)
			rig.dist = 2.4
			set_process(false)
		elif s.begins_with("focus_grandpa"):
			rig.focus = grandpa.global_position + Vector3(0, 1.0, 0)
			rig.dist = 3.5
			set_process(false)
		elif s.begins_with("focus_terr"):
			_tap_object("terrarium")
			rig.pitch = -14.0
		elif s.begins_with("portrait:"):
			hud.visible = false
			grandpa.stop()
			grandpa.set_process(false)
			grandpa.play("idle")
			grandpa.ap.speed_scale = 0.0
			set_process(false)
			var head: Vector3 = grandpa.global_position + Vector3(0, 1.36, 0)
			rig.setup(head, rad_to_deg(grandpa.rotation.y) + 18.0, -4.0, 1.5, 0.5, 5.0)
			rig.cam.fov = 30.0
			await get_tree().create_timer(0.5).timeout
			get_viewport().get_texture().get_image().save_png(s.substr(9))
			hud.visible = true
		elif s.begins_with("pupwalk"):
			puppy.position = Vector3(-2, 0, 0)
			puppy.rotation.y = 0.0
			puppy.walk_to(Vector3(-2, 0, 3.5))
			puppy.set_process(true)
		elif s.begins_with("camside"):
			_track = puppy
			rig.setup(puppy.global_position + Vector3(0, 0.3, 0), 90.0, -18.0, 2.6, 1.0, 9.0)
		elif s.begins_with("camfront"):
			_track = puppy
			rig.setup(puppy.global_position + Vector3(0, 0.3, 0), 0.0, -18.0, 2.6, 1.0, 9.0)
		elif s == "dbg2":
			for n in world.yard_root.get_children():
				if n.has_method("talk") or "drops" in n:
					print("NODE ", n.get_script().resource_path.get_file(), " ", n.global_position, " vis=", n.visible, " model=", n.get("model"))
		elif s == "dbg":
			var g: Node3D = terrarium.gecko
			for mi in g.find_children("*", "MeshInstance3D", true, false):
				print("GECKO mesh aabb ", (mi as MeshInstance3D).global_transform * (mi as MeshInstance3D).get_aabb())
			print("GECKO pos ", g.global_position, " terr ", terrarium.global_position)
			var tm: Node3D = terrarium.get_child(0)
			for mi in tm.find_children("*", "MeshInstance3D", true, false):
				print("TERR aabb ", (mi as MeshInstance3D).global_transform * (mi as MeshInstance3D).get_aabb())
		elif s == "fast":
			Game.state["gecko"]["temp"] = 27.98
			Game.state["gecko"]["lamp"] = true
			Game._tick(1.0)
		else:
			_on_action(s)
	print("DEMO END quest=", Game.state["quest"], " coins=", Game.state["coins"])
	get_tree().quit()

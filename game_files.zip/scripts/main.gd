extends Node
## Головна сцена 3D-версії: світ, камера за Beep, персонажі, торкання, квести дідуся.

var world
var audio
var _bark_t := 6.0
var _hen_t := 4.0
var rig
var hud
var puppy
var grandpa
var beep
var terrarium
var kid
var gvintyk
var drone
var birds: Array = []
var geese: Array = []
var dragon
var plane
var tractor
var orchard
var forest
var hit_area: Node
var _ctl_beep := false                  # гравець сам керує Beep (джойстик)
var _ctl_veh: Node3D = null             # гравець сам кермує трактором чи конем із возом (джойстик)
var _veh_kind := ""                     # "tractor" / "horse"
var girl
var seeds
var riding := false                    # дівчинка на драконі, керує гравець
var gold_flower: Node3D
var _geese_day := -1
var ball: Node3D
var _herd_day := -1
var _out_day := -1
var bowl: Node3D
var kibble: Node3D
var _shot := ""
var _demo := ""
var _frames := 0
var _greeted := false
var _track: Node3D
var _last_tap := Vector2.ZERO


func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shot="):
			_shot = a.substr(7)
		elif a.begins_with("--demo="):
			_demo = a.substr(7)
		elif a.begins_with("--time="):
			Game.state["time"] = float(a.substr(7))
	world = preload("res://scripts/world.gd").new()
	add_child(world)
	audio = preload("res://scripts/audio.gd").new()
	audio.name = "Audio"
	add_child(audio)
	rig = preload("res://scripts/cam_rig.gd").new()
	add_child(rig)
	rig.tapped.connect(tap)
	_spawn_characters()
	hud = preload("res://scripts/hud.gd").new()
	var ui := CanvasLayer.new()
	ui.layer = 1
	add_child(ui)
	ui.add_child(hud)
	hud.action.connect(_on_action)
	hud.place_provider = func(): return world.outer.place_name(plane.global_position if riding and plane else beep.global_position)
	hud.flight.home_pressed.connect(func():
		if _ctl_veh:
			_ctl_veh = null                  # «Готово» — дідусь сам ставить транспорт на місце
		elif _ctl_beep:
			stop_beep_control()
		elif plane and riding:
			plane.go_home())
	hud.flight.land_pressed.connect(func():
		if _ctl_beep:
			beep._lift_want = 0.0
		elif plane and riding:
			plane.land_here())
	hud.build_minimap(world.outer, world.YARD)
	hud.marker_provider = _map_markers
	hud.seed_provider = func() -> Array:
		var a: Array = []
		if seeds:
			for i in seeds.nodes.size():
				if seeds.nodes[i].visible:
					a.append(seeds.SPOTS[i])
		return a
	hud.map_tapped.connect(func(p: Vector3):
		if Game.state["location"] == "yard":
			audio.play("click", -6.0)
			beep.fly_to(p))
	Game.quest_started.connect(_on_quest_started)
	Game.quest_done.connect(_on_quest_done)
	Game.night_started.connect(_on_night_started)
	go_to(Game.state["location"], true)
	await get_tree().process_frame
	Game.start_quest()
	if _demo != "":
		_run_demo()


func _spawn_characters() -> void:
	var sp: Dictionary = world.spots
	# миска з кормом (корм — купка гранул, яка зменшується, поки Бім їсть)
	bowl = Node3D.new()
	bowl.position = sp["bowl"] + Vector3(0, world.BOWL_STAND_H, 0)
	world.yard_root.add_child(bowl)
	var bm := Models.spawn(bowl, "bowl", 0.13)
	if bm == null:
		bowl.add_child(Util.cyl(0.14, 0.11, 0.1, Util.mat(Color(0.85, 0.2, 0.2), 0.35), Vector3(0, 0.05, 0)))
	kibble = Node3D.new()
	bowl.add_child(kibble)
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var cols := [Color(0.62, 0.38, 0.18), Color(0.78, 0.52, 0.25), Color(0.9, 0.7, 0.35)]
	for i in 34:
		var a := rng.randf() * TAU
		var r := sqrt(rng.randf()) * 0.1
		var y := 0.075 + (0.1 - r) * 0.35 + rng.randf() * 0.015
		var k := Util.sphere(0.017, Util.mat(cols[i % 3], 0.8), Vector3(cos(a) * r, y, sin(a) * r), Vector3(1.3, 0.8, 1))
		k.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		kibble.add_child(k)
	bowl.add_child(Util.pick_area("bowl", Vector3(0.5, 0.3, 0.5), Vector3(0, 0.1, 0)))
	puppy = preload("res://scripts/puppy.gd").new()
	puppy.position = sp["doghouse"] + Vector3(1.2, 0, 1.6)
	world.yard_root.add_child(puppy)
	puppy.bowl_pos = sp["bowl"]
	puppy.home_pos = sp["doghouse"]
	grandpa = preload("res://scripts/grandpa.gd").new()
	grandpa.spots = sp
	grandpa.world = world
	grandpa.position = sp["porch"] + Vector3(1.2, 0, 0.4)
	world.yard_root.add_child(grandpa)
	grandpa.setup_seats()
	beep = preload("res://scripts/beep.gd").new()
	add_child(beep)
	puppy.follow = beep
	# курочки й півник біля курника
	for i in 5:
		var b := preload("res://scripts/bird.gd").new()
		world.yard_root.add_child(b)
		var at: Vector3 = sp.get("coop", Vector3(6.6, 0, -1.6)) + Vector3(randf_range(-1.5, 0.2), 0, randf_range(-1.2, 1.2))
		if i == 0:
			b.setup("rooster", 0.6, at, true)
		else:
			b.setup("hen", 0.48, at)
	# сусідський хлопчик Тарасик і маленький робот Гвинтик
	if Models.exists("kid"):
		kid = preload("res://scripts/kid.gd").new()
		kid.main = self
		world.yard_root.add_child(kid)
		kid.position = Vector3(-2.5, 0, 2.0)
		kid.setup("kid", 1.15, {"idle": ["idle_022", "idle_02"], "walk": ["walk"], "run": ["run"], "talk": ["listening"]},
			["idle", "walk", "run"],
			["Привіт! Я Тарасик, живу через дорогу.", "А Бім уміє приносити м'ячик?", "Я ношу воду з криниці — я сильний!", "Дідусь каже, що гарбузи вже майже великі!", "Хочеш, покажу, де жаби в ставку?"],
			[Vector3(-2.5, 0, 2.5), Vector3(-2.0, 0, 3.0), Vector3(1.5, 0, 0.5), Vector3(-6.0, 0, -1.0), Vector3(-10.0, 0, -4.0), Vector3(-12.0, 0, -7.5)], "npc")
		kid.setup_pose()
		kid.make_bucket()
		_lives_outside(kid)
	if Models.exists("robot_kid"):
		gvintyk = preload("res://scripts/gvintyk.gd").new()
		gvintyk.main = self
		world.yard_root.add_child(gvintyk)
		gvintyk.position = Vector3(5.6, 0, -2.6)
		gvintyk.setup("robot_kid", 0.9, {"idle": ["idle"], "walk": ["walk"], "run": ["run"], "dance": ["dance"]},
			["idle", "walk", "run", "dance"],
			["Біп! Я Гвинтик — молодший помічник.", "Зарядився на 100%!", "Можна я потанцюю? Біп-біп!", "Я ношу дрова й збираю яйця!"],
			[Vector3(5.6, 0, -2.6), Vector3(4.0, 0, 0.5), Vector3(6.5, 0, -6.0), Vector3(2.5, 0, -3.5), Vector3(-13.0, 0, -2.0), Vector3(-15.0, 0, -7.5)], "npc")
		gvintyk.setup_pose()
		gvintyk.make_props()
		_lives_outside(gvintyk)
	if Models.exists("drone"):
		drone = preload("res://scripts/drone.gd").new()
		world.yard_root.add_child(drone)
		drone.setup(Vector3(-5.6, 0, 2.4), sp)
	for b in world.yard_root.get_children():
		if "rooster" in b:
			birds.append(b)
	# гуси гуляють у лівій частині двору, на ніч ідуть у сарай
	if Models.exists("goose"):
		for i in 3:
			var g := preload("res://scripts/bird.gd").new()
			g.goose = true
			world.yard_root.add_child(g)
			g.setup("goose", 0.62 if i > 0 else 0.7, Vector3(-12.0 + i * 0.9, 0, 1.0 + i * 0.6))
			g.base_radius = 3.5
			g.radius = 3.5
			g.speed *= 0.8
			g.coop_hole = world.spots["barn"] + Vector3(0, 0, -0.75)
			geese.append(g)
	# індик гуляє з гусьми, на ніч теж іде в сарай
	if Models.exists("turkey"):
		var tk := preload("res://scripts/bird.gd").new()
		tk.goose = true
		tk.voice = "Бал-бал-бал!"
		world.yard_root.add_child(tk)
		tk.setup("turkey", 0.85, Vector3(-10.0, 0, -4.5))
		tk.base_radius = 3.0
		tk.radius = 3.0
		tk.speed *= 0.7
		tk.coop_hole = world.spots["barn"] + Vector3(0.6, 0, -0.75)
		geese.append(tk)
	_spawn_shopkeepers()
	_check_models()
	_spawn_cattle()
	if Models.exists("plane_y"):
		plane = preload("res://scripts/plane.gd").new()
		world.yard_root.add_child(plane)
		plane.setup(world.outer.HANGAR, world.outer.RUNWAY_A, world.outer.RUNWAY_B)
		plane.hangar_door = world.outer.set_hangar_door
		plane.landed.connect(_on_plane_landed)
	_spawn_farm_extras()
	if Models.exists("girl"):
		girl = preload("res://scripts/girl.gd").new()
		girl.main = self
		world.yard_root.add_child(girl)
		girl.position = girl.HOME_YARD
		girl.setup_girl()
	seeds = preload("res://scripts/seeds.gd").new()
	world.yard_root.add_child(seeds)
	seeds.build()
	seeds.dragon = plane
	seeds.collected.connect(_on_seed)
	if Game.state["seeds"].size() >= seeds.SPOTS.size():
		_make_gold_flower(false)
	puppy.water_pos = sp["water_bowl"]
	var bl: Vector3 = sp["water_bowl"] - sp["bowl"]
	puppy.bowl_front = Vector3(-bl.z, 0, bl.x).normalized()
	puppy.main = self
	terrarium = preload("res://scripts/terrarium.gd").new()
	terrarium.position = sp["terrarium"]
	terrarium.rotation.y = deg_to_rad(18)
	world.room_root.add_child(terrarium)
	terrarium.position = sp["terrarium"] - world.ROOM
	terrarium.scale = Vector3.ONE * 1.35                   # більший тераріум — більше місця Лимончикові
	terrarium.gecko.scale = Vector3.ONE / 1.35


func go_to(loc: String, instant := false, keep_beep := false) -> void:
	Game.state["location"] = loc
	beep.outdoors = loc == "yard"
	if loc != "yard":
		beep.lift = 0.0
		beep._lift_want = 0.0
		beep._cruise = false
	cam_follow = null
	_cam_up = 0.8
	if hud:
		hud.show_overview_button(false)
	var sp: Dictionary = world.spots
	rig.blockers = [AABB(world.HOUSE_POS + Vector3(-3.2, 0, -3.7), Vector3(6.4, 6.0, 7.1)) if world.big_house else AABB(world.HOUSE_POS + Vector3(-3.0, 0, -2.4), Vector3(6.0, 4.6, 4.8))] if loc == "yard" else []
	if loc == "yard":
		if not keep_beep:
			beep.position = sp["porch"] + Vector3(2.4, 0, 2.2) if instant or beep.position.z < -500 else sp["porch"] + Vector3(0.4, 0, 1.2)
		rig.setup(sp["door"] + Vector3(0, 0.9, 1.0) if keep_beep else beep.position + Vector3(0, 0.9, 0), 0.0, -20.0, 6.8, 3.0, 26.0)
	else:
		beep.position = world.ROOM + Vector3(-0.3, 0, -1.6)
		rig.setup(world.ROOM + Vector3(0, 1.25, 0.2), 20.0, -14.0, 2.2, 0.3, 2.4, 400.0, -45.0, 8.0)
	rig.inside_box = AABB(world.ROOM + Vector3(-3.3, 0.25, -2.55), Vector3(6.6, 2.55, 5.1)) if loc == "room" else AABB()
	if not keep_beep:
		beep.moving = false
	if hud:
		hud.refresh()


func _ambient_voices(delta: float) -> void:
	## Бім іноді гавкає, кури кудкудакають, зранку кукурікає півень, уночі ухкає сова.
	if Game.state["location"] != "yard":
		return
	_bark_t -= delta
	if _bark_t <= 0.0:
		_bark_t = randf_range(10.0, 25.0)
		if not Game.is_night():
			audio.play_at("puppy_bark" if randf() < 0.6 else "small_dog", puppy, -6.0)
	_hen_t -= delta
	if _hen_t <= 0.0:
		_hen_t = randf_range(7.0, 16.0)
		for b in world.yard_root.get_children():
			if "rooster" in b:
				if Game.is_night():
					if randf() < 0.3:
						audio.play_at("owl", world.yard_root, -10.0)
				elif b.rooster and Game.hour() < 9.5 and randf() < 0.5:
					audio.play_at("rooster", b, -4.0)
				else:
					audio.play_at("hens" if randf() < 0.7 else "chicks", b, -10.0)
				break


var _door_acc := 0.0
var _lod_acc := 0.0


func _lod_characters(dt: float) -> void:
	## Далекі персонажі: не малюємо й не рахуємо скелет/анімацію (логіка — ходьба, справи — працює далі).
	_lod_acc += dt
	if _lod_acc < 0.3:
		return
	_lod_acc = 0.0
	if rig == null or rig.cam == null:
		return
	var cp: Vector3 = rig.cam.global_position
	var list: Array = [girl, tea_boy, market_bot, kid, gvintyk, puppy, grandpa, horse]
	list.append_array(cows)
	list.append_array(geese)
	list.append_array(birds)
	for w in list:
		if w == null or not is_instance_valid(w):
			continue
		var n: Node3D = w
		var far := n.global_position.distance_to(cp) > 75.0
		var m = n.get("model")
		if m is Node3D:
			(m as Node3D).visible = not far
		var a = n.get("ap")
		if a is AnimationPlayer:
			(a as AnimationPlayer).active = not far


func _watch_doors(dt: float) -> void:
	## Двері будинків і ворота відчиняються, коли хтось підходить.
	_door_acc += dt
	if _door_acc < 0.25:
		return
	var mv: Array = []
	if Game.state["location"] == "yard" and not beep.piloting and beep.lift < 3.0:
		mv.append(beep.global_position)
	for w in [grandpa, girl, kid, gvintyk, puppy]:
		if w and is_instance_valid(w) and w.visible and (w as Node3D).global_position.z > -500.0:
			mv.append((w as Node3D).global_position)
	for g in geese:
		if g.visible:
			mv.append(g.global_position)
	for c in cows:
		if c.visible:
			mv.append(c.global_position)
	if horse and horse.visible:
		mv.append(horse.global_position)
	world.door_watch(mv, _door_acc)
	_door_acc = 0.0


func _process(_delta: float) -> void:
	_watch_doors(_delta)
	_lod_characters(_delta)
	var loc: String = Game.state["location"]
	if riding and plane and plane.state != "rest":
		_ride_cam(_delta)
	elif _ctl_veh:
		_veh_cam(_delta)
	elif _ctl_beep:
		_beep_cam(_delta)
	elif _track:
		rig.focus = _track.global_position + Vector3(0, 0.3, 0)
	elif loc == "yard":
		if cam_follow and (not is_instance_valid(cam_follow) or not cam_follow.is_visible_in_tree()):
			overview()
		if cam_follow:
			rig.focus = cam_follow.global_position + Vector3(0, _cam_up, 0)
		else:
			rig.focus = beep.global_position + Vector3(0, _cam_up + beep.lift, 0)
	kibble.visible = Game.state["puppy"]["bowl"] > 0.0
	if hud and loc == "yard":
		hud.update_map_dot(plane.global_position if riding and plane else beep.global_position)
	if _frames % 60 == 5 and seeds and hud:
		var flags: Array = []
		for n in seeds.nodes:
			flags.append(n.visible)
		hud.set_seed_dots(seeds.SPOTS, flags)
	_frames += 1
	if _frames % 30 == 0 and hud:
		hud.refresh()
	if _frames % 60 == 0:
		_farm_tick()
	if _frames % 15 == 7:
		_night_step()
	_ambient_voices(_delta)
	if _shot != "" and _frames == 60:
		get_viewport().get_texture().get_image().save_png(_shot)
		print("SHOT ", _shot)
		if _demo == "":
			get_tree().quit()


# ------------------------------------------------------------------ торкання
func tap(pos: Vector2) -> void:
	_last_tap = pos
	if hud.dialog_open() or riding or _ctl_veh:
		return
	var cam: Camera3D = rig.cam
	var from := cam.project_ray_origin(pos)
	var dir := cam.project_ray_normal(pos)
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 80.0)
	q.collide_with_areas = true
	q.collide_with_bodies = false
	var hit := cam.get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty() and hit["collider"].is_visible_in_tree() and hit["collider"].input_ray_pickable:
		var kind := String(hit["collider"].get_meta("kind"))
		if Game.state["location"] == "yard":
			focus_on(hit["collider"].get_parent(), kind)
		hit_node = hit["collider"].get_parent()
		hit_area = hit["collider"]
		_tap_object(kind)
		return
	if dir.y < -0.01:
		var t := -from.y / dir.y
		var p := from + dir * t
		if Game.state["location"] == "yard":
			p.x = clampf(p.x, -world.outer.LIMIT, world.outer.LIMIT)
			p.z = clampf(p.z, -world.outer.LIMIT, world.outer.LIMIT)
			overview()
			beep.fly_to(p)
			if randf() < 0.35:
				puppy.walk_to(p + Vector3(randf_range(-1, 1), 0, 1.0), true)
		else:
			var r: Vector3 = world.ROOM
			p.x = clampf(p.x, r.x - 3.0, r.x + 3.0)
			p.z = clampf(p.z, r.z - 1.8, r.z + 2.0)
			beep.fly_to(p)
			rig.focus = world.ROOM + Vector3(0, 1.25, 0.2)
			rig.dist = 2.2


func _tap_object(kind: String) -> void:
	match kind:
		"beep":
			audio.play_at("robot_beep", beep, 0.0)
			beep.outdoors = Game.state["location"] == "yard"
			beep.hop()
			if beep.outdoors:
				rig.glide_to(9.0, -24.0)
			beep.say(_beep_hint(), 3.5)
			Game.emit_event("tap_beep")
		"puppy":
			if Game.hour() >= 18.5 and _hens_outside() and puppy.doing != "herd":
				herd_hens()
				return
			beep.fly_to(puppy.global_position + Vector3(0.6, 0, 0.8))
			puppy.pet(rig.cam.global_position)
			audio.play_at("puppy_bark", puppy, -2.0, 1.1)
		"grandpa":
			var nt := Game.night_task() if Game.night_active() else {}
			if not nt.is_empty() and nt["goal"] == "blanket":
				if grandpa.doing == "sleep" and (grandpa.lying or grandpa.seated == "armchair"):
					beep.fly_to(grandpa.global_position + (Vector3(-1.0, 0, 0.4) if grandpa.lying else grandpa.global_transform.basis.z * 1.0))
					grandpa.cover(true)
					audio.play("pop", -10.0, 0.8)
					Game.emit_event("blanket")
				else:
					beep.say("Дідусь ще не ліг — зачекаймо трішки.", 3.0)
				return
			if grandpa.doing == "sleep":
				beep.say("Тсс… дідусь спить.", 2.0)
				return
			if grandpa.at_home and grandpa.seated == "armchair" and (Game.day_done() or Game.hour() >= 19.0):
				grandpa.say("Ох, зачитався… Піду вже спати. Добраніч!", 3.0)
				grandpa.command_bed()
				return
			grandpa.wave_at(rig.cam.global_position)
			# дідусеві справи — у його власному меню
			hud.show_grandpa_menu(grandpa.at_home, grandpa.doing in ["plow", "orchard", "forest", "tractor", "cart"])
		"bowl":
			_on_action("feed")
		"house":
			enter_house()
		"room_exit":
			leave_house()
		"plane":
			if plane:
				if riding:
					plane.say("Летимо!", 1.5)
				elif plane.state == "rest":
					start_ride()
				else:
					plane.poke()
		"firefly":
			var ff: Node3D = hit_node if hit_node else null
			if ff:
				beep.fly_to(ff.global_position)
		"bull":
			if hit_node and hit_node.has_method("poke"):
				hit_node.poke()
				audio.play_at("pop", hit_node, -6.0, 0.6)
		"horse":
			if horse:
				horse.poke()
		"cart":
			hud.toast("Щоб поїхати на возі, торкнись дідуся → «Запрягти коня з возом»", 4.0)
		"gold_flower":
			audio.play("magic_bells", -6.0)
			hud.toast("Чарівний соняшник із золотих насінинок", 3.0)
		"tractor":
			if tractor:
				tractor.poke()
				if tractor.state == "parked":
					hud.toast("Щоб поорати поле, торкнись дідуся → «Зорати поле на тракторі»", 4.0)
		"orchard_tree":
			if orchard and hit_area and hit_area.has_meta("tree"):
				var ti: int = hit_area.get_meta("tree")
				var got: int = orchard.pick(ti, 3)
				if got > 0:
					beep.fly_to(orchard.pick_spot(ti, beep.global_position))
					beep.say("Зірвав %d — %s!" % [got, orchard.fruit_name(ti)], 2.5)
					audio.play("pop", -8.0, 1.2)
					Game.add_coins(got)
				else:
					hud.toast(orchard.describe(ti), 3.0)
		"forest_item":
			if forest and hit_area and hit_area.has_meta("item"):
				var gi: int = hit_area.get_meta("item")
				if forest.can_take(gi):
					beep.fly_to(forest.goods_pos(gi) + Vector3(0.8, 0, 0.8))
					forest.take(gi)
					beep.say("%s — у кошик!" % forest.label(gi), 2.5)
					audio.play("pop", -8.0, 1.1)
					Game.add_coins(1)
					Game.emit_event("forest")
				else:
					beep.say(forest.label(gi), 2.5)
		"stall":
			if hit_node and hit_node.has_meta("stall"):
				var info: Array = hit_node.get_meta("stall")
				hud.toast("Ларок «%s»: %s" % [info[0], info[1]], 3.5)
				audio.play("coins", -10.0)
				beep.say("Смакота!" if info[0] in ["Хліб", "Мед"] else "Гарний ларок!", 1.8)
		"girl":
			if girl:
				audio.play_at("question", girl, -4.0, 1.25)
				Game.emit_event("girl_met")
				# власне меню Ніки: поговорити, гриби й ягоди, у гості до діда, додому
				hud.show_girl_menu(girl.in_yard(), girl.doing in ["forest", "visit", "back", "home"], Game.hour() >= 16.5 or Game.hour() < 7.5)
		"bird":
			_poke_nearest_bird()
			audio.play("hens", -6.0)
		"npc":
			var best: Node3D = null
			var bd := INF
			for n in world.yard_root.get_children():
				if n.has_method("talk"):
					var d: float = rig.cam.unproject_position(n.global_position + Vector3(0, 0.6, 0)).distance_to(_last_tap)
					if d < bd:
						bd = d
						best = n
			var qid: String = Game.current_quest().get("id", "")
			if best and best == kid:
				# власне меню Тарасика (його справи — не в меню Beep)
				audio.play_at("question", kid, -4.0)
				if kid.doing == "" and not kid.moving:
					kid.face(rig.cam.global_position)
				hud.show_kid_menu(false)      # будь-яку нову справу можна замовити й під час іншої
			elif best and best == gvintyk and qid == "eggs" and gvintyk.doing == "":
				gvintyk.eggs_job()
			elif best:
				best.talk(rig.cam.global_position)
				audio.play_at("robot_beep" if "robot" in str(best.model) else "question", best, -4.0)
		"drone":
			for n in world.yard_root.get_children():
				if n.has_method("poke") and n.has_method("setup") and "drops" in n:
					n.poke()
			audio.play("robot_beep", -6.0, 1.4)
		"well":
			audio.play("metal_drop", -8.0)
			beep.say("Вода в криниці холодна й смачна!", 2.5)
		"terrarium":
			# наближаємось до тераріуму; ще раз торкнутися — показати температуру
			var c: Vector3 = terrarium.global_position + Vector3(0, 1.0, 0)
			if rig.focus.distance_to(c) > 0.1:
				rig.focus = c
				rig.dist = 1.5
				rig.pitch = -14.0
				rig.yaw = rad_to_deg(terrarium.rotation.y)
			hud.toast("%s · %.1f °C" % [Game.gecko_mood(), Game.state["gecko"]["temp"]], 3.0)


func _poke_nearest_bird() -> void:
	var best: Node3D = null
	var bd := INF
	var cam_pos: Vector3 = rig.cam.global_position
	for b in world.yard_root.get_children():
		if "rooster" in b:
			var d: float = (b as Node3D).global_position.distance_to(cam_pos)
			if d < bd:
				bd = d
				best = b
	if best:
		best.poke()


func _grandpa_dialog(text: String) -> void:
	grandpa.start_talk(rig.cam.global_position)
	audio.play("page", -8.0)
	hud.show_dialog("Дідусь Петро", text, null, func(): grandpa.end_talk())


func _beep_hint() -> String:
	var q := Game.current_quest()
	if q.is_empty():
		return "Біп! Усе зроблено!"
	if q["where"] != "" and q["where"] != Game.state["location"]:
		return "Біп-буп! Нам треба в %s." % ("подвір'я" if q["where"] == "yard" else "хату — торкнись її")
	match q["id"]:
		"meet_beep":
			return "Біп-буп! Привіт! Я Beep."
		"feed_puppy":
			return "Натисни «Корм» — я насиплю!"
		"pet_puppy":
			return "Торкнись Біма, щоб погладити."
		"warm_gecko":
			return "Увімкни лампу й стеж за термометром."
		"feed_gecko":
			return "Коли тепло — натисни «Цвіркуни»."
	return "Біп!"


# ------------------------------------------------------------------ дії з кнопок
func _on_action(name: String) -> void:
	match name:
		"feed":
			if Game.state["puppy"]["bowl"] > 0.0:
				hud.toast("Мисочка вже повна")
				return
			beep.say("Насипаю корм!", 2.0)
			beep.fly_to(bowl.global_position + Vector3(0.3, 0, 0.5), func():
				Game.fill_bowl()
				audio.play_at("plate", bowl, -4.0)
				beep.happy()
				puppy.say("Гав! Їжа!", 2.0)
				puppy.go_eat())
		"lamp":
			var on: bool = Game.toggle_lamp()
			audio.play("click", 0.0, 0.8)
			beep.say("Лампу ввімкнено. Стеж за термометром!" if on else "Лампу вимкнено.", 2.5)
		"crickets":
			beep.fly_to(terrarium.global_position + Vector3(1.0, 0, 0.1))
			var msg: String = Game.feed_gecko()
			if msg.begins_with("Ням"):
				terrarium.tongue()
				audio.play("pop", -4.0)
			beep.say(msg, 3.5)
		"help":
			hud.show_beep_menu(Game.state["location"] == "yard", Game.is_night(), beep.lamp.visible, grandpa.at_home)
		"hint":
			beep.say(_beep_hint(), 3.5)
			beep.happy()
			audio.play_at("robot_beep", beep, -2.0)
		"drone_feed":
			if drone == null:
				return
			if drone.busy():
				hud.toast("Дрон зараз зайнятий")
				return
			beep.say("Біп! Дроне, нагодуй курей!", 2.5)
			drone.feed_hens()
		"drone_water":
			if drone == null:
				return
			if drone.busy():
				hud.toast("Дрон зараз зайнятий")
				return
			beep.say("Біп! Дроне, полий город!", 2.5)
			drone.water_field()
		"ball":
			throw_ball()
		"light":
			var on: bool = beep.toggle_lamp()
			audio.play("click", -2.0, 1.3)
			beep.say("Ліхтарик увімкнено!" if on else "Ліхтарик вимкнено.", 2.0)
		"scan":
			beep.happy()
			audio.play_at("magic_bells", beep, -6.0)
			hud.show_dialog("Beep · сканер", _scan_text(), load("res://assets/ui/beep.png") if ResourceLoader.exists("res://assets/ui/beep.png") else null)
		"herd":
			if _hens_outside():
				herd_hens()
			else:
				hud.toast("Усі кури вже в курнику")
		"overview":
			overview()
		"goodnight":
			_goodnight()
		"sleep":
			_sleep_to_morning()
		"to_plane", "to_dragon":
			if plane == null:
				hud.toast("Немає моделі літака — завантаж на GitHub файл models_10.zip", 5.0)
				return
			if riding:
				return
			start_ride()
		"beep_ctl":
			start_beep_control()
		"home":
			beep.say("Летимо додому!", 2.0)
			beep.fly_to(world.spots["door"] + Vector3(1.5, 0, 2.0))
			overview()
		"go_yard":
			leave_house()
		"go_room":
			enter_house()
		"grandpa_in", "gp_in":
			grandpa.command_in()
		"grandpa_out", "gp_out":
			grandpa.command_out()
		"grandpa_bed", "gp_bed":
			grandpa.say("Добре, онучку, лягаю спати…", 2.5)
			grandpa.command_bed()
		"gp_talk":
			_grandpa_talk()
		"gp_plow":
			if tractor == null:
				hud.toast("Немає моделі трактора — завантаж на GitHub файл models_10.zip", 5.0)
				return
			grandpa.cancel_job()
			grandpa.plow_job()
			_follow_later(grandpa)
		"kid_talk":
			if kid:
				kid.talk(rig.cam.global_position)
				audio.play_at("question", kid, -4.0)
		"kid_water", "water":
			if kid:
				kid.cancel_job()
				kid.say("Зараз принесу води!", 2.0)
				kid.water_job()
				_follow_later(kid)
		"kid_play":
			if kid:
				kid.cancel_job()
				kid.play_with_bim()
				_follow_later(kid)
		"kid_field":
			if kid:
				kid.cancel_job()
				kid.look_at_field()
				_follow_later(kid)
		"girl_talk":
			if girl:
				girl.talk(rig.cam.global_position)
		"girl_forest":
			if girl:
				girl.cancel_job()
				girl.forest_job()
				_follow_later(girl)
		"girl_visit":
			if girl:
				girl.cancel_job()
				girl.visit_grandpa()
				_follow_later(girl)
		"girl_home":
			if girl:
				girl.cancel_job()
				girl.back_to_village()
				_follow_later(girl)
		"gp_tractor":
			if tractor == null:
				hud.toast("Немає моделі трактора — завантаж на GitHub файл models_10.zip", 5.0)
				return
			grandpa.cancel_job()
			grandpa.tractor_drive_job()
			_follow_later(grandpa)
		"gp_horse":
			if horse == null or horse_cart == null:
				hud.toast("Немає моделі коня чи воза — завантаж на GitHub файл models_11.zip", 5.0)
				return
			grandpa.cancel_job()
			grandpa.horse_job()
			_follow_later(grandpa)
		"gp_orchard":
			grandpa.cancel_job()
			grandpa.orchard_job()
			_follow_later(grandpa)
		"gp_forest":
			grandpa.cancel_job()
			grandpa.forest_job()
			_follow_later(grandpa)
		"sound":
			audio.set_muted(not audio.is_muted())
			hud.buttons["sound"].text = "♪" if not audio.is_muted() else "✕"


# ------------------------------------------------------------------ камера: зосередитись на тому, кого торкнулись, або загальний огляд
var cam_follow: Node3D                 # за ким стежить камера (null — загальний огляд за Beep)
var _cam_up := 0.8
const FOCUS := {
	# вид: [відстань, нахил, висота точки, на яку дивимось]
	"beep": [3.2, -14.0, 0.9], "puppy": [2.4, -14.0, 0.35], "grandpa": [3.4, -10.0, 1.1], "npc": [3.0, -10.0, 0.75],
	"bird": [2.0, -16.0, 0.3], "bowl": [2.6, -30.0, 0.3], "well": [5.5, -16.0, 1.3], "house": [11.0, -14.0, 2.2],
	"drone": [4.5, -14.0, 0.0], "plane": [12.0, -14.0, 1.2], "dragon": [9.5, -12.0, 1.4], "barn": [12.0, -16.0, 2.5], "workshop": [9.0, -14.0, 1.4],
	"girl": [2.8, -10.0, 0.65], "bull": [5.5, -14.0, 1.0], "gold_flower": [5.0, -12.0, 1.8],
}


var tea_boy
var market_bot
var bull


func _spawn_shopkeepers() -> void:
	## Хлопець-школяр працює в чайній, робот EngineBot — на ринку (на площі в селі).
	var o = world.outer
	if Models.exists("student"):
		tea_boy = preload("res://scripts/npc.gd").new()
		tea_boy.name = "TeaBoy"
		tea_boy.main = self
		world.yard_root.add_child(tea_boy)
		var tp: Vector3 = o.TEA_POS
		var to_c: Vector3 = (o.VILLAGE - tp).normalized()
		var side := Vector3(-to_c.z, 0, to_c.x)
		var spots := [tp + to_c * 0.2, tp + to_c * 0.2 + side * 0.9, tp + to_c * 0.2 - side * 0.9, tp + to_c * 2.6]
		tea_boy.position = spots[0]
		tea_boy.setup("student", 1.6, {"idle": ["walking"], "walk": ["walking"], "run": ["running"], "dance": ["all_night"]},
			["walk", "run", "dance"],
			["Вітаю в чайній! Чай із чебрецем чи з м'ятою?", "Є свіжий узвар і пиріжки з вишнями!", "Я тут працюю після школи.",
			 "Сідай на лавку біля фонтану — принесу чаю!", "Кажуть, над селом літає дракон!"], spots, "npc")
		tea_boy.bounds = Rect2(tp.x - 4.0, tp.z - 4.0, 8.0, 8.0)
		tea_boy.avoid = false
		tea_boy.setup_pose()
		tea_boy.make_idle_from("walk")
		tea_boy.shopkeeper = true
		tea_boy.idle_left = 20.0
		tea_boy.play("idle")
		tea_boy.face(o.VILLAGE)
		tea_boy.set_meta("view_from", to_c)
	if Models.exists("enginebot"):
		market_bot = preload("res://scripts/npc.gd").new()
		market_bot.name = "MarketBot"
		market_bot.main = self
		world.yard_root.add_child(market_bot)
		var mp: Vector3 = o.MARKET_POS
		var to_c2: Vector3 = (o.VILLAGE - mp).normalized()
		var side2 := Vector3(-to_c2.z, 0, to_c2.x)
		var front := mp + to_c2 * 5.6
		var spots2 := [front, front + side2 * 3.0, front - side2 * 3.0, front + to_c2 * 1.5]
		market_bot.position = front
		market_bot.setup("enginebot", 1.9, {"idle": ["walking"], "walk": ["walking"], "run": ["running"]},
			["walk", "run"],
			["Біп-буп! Ринок відкрито!", "Мед, глечики, гарбузи — усе свіже!", "Я EngineBot. Рахую решту без помилок.",
			 "Зілля для курочок, щоб краще неслися? Жартую! Біп!", "Заходь, подивися на прилавки!"], spots2, "npc")
		market_bot.bounds = Rect2(front.x - 5.0, front.z - 5.0, 10.0, 10.0)
		market_bot.avoid = false
		market_bot.setup_pose()
		market_bot.make_idle_from("walk")
		market_bot.shopkeeper = true
		market_bot.idle_left = 20.0
		market_bot.play("idle")
		market_bot.face(o.VILLAGE)
		market_bot.set_meta("view_from", to_c2)


func _map_markers() -> Array:
	## Для великої мапи: хто де.
	var m: Array = []
	if plane:
		m.append(["Літак" + (" (летить)" if plane.flying() else (" (в ангарі)" if plane.in_hangar else "")), plane.global_position, Color(0.95, 0.75, 0.1)])
	if girl and girl.visible:
		m.append(["Ніка", girl.global_position, Color(0.9, 0.15, 0.15)])
	if grandpa:
		if grandpa.at_home:
			m.append(["Дідусь (у хаті)", world.HOUSE_POS, Color(0.45, 0.35, 0.25)])
		else:
			m.append(["Дідусь", grandpa.global_position, Color(0.45, 0.35, 0.25)])
	m.append(["Бім", puppy.global_position, Color(0.9, 0.55, 0.15)])
	for n in [kid, gvintyk]:
		if n and n.visible:
			m.append(["Тарасик" if n == kid else "Гвинтик", n.global_position, Color(0.2, 0.55, 0.85) if n == kid else Color(0.4, 0.5, 0.55)])
	if drone:
		m.append(["Дрон", drone.global_position, Color(0.3, 0.6, 0.3)])
	if bull and bull.visible:
		m.append(["Бичок", bull.global_position, Color(0.4, 0.25, 0.15)])
	var nc := 0
	var cp := Vector3.ZERO
	for c in cows:
		if c != bull and c.visible:
			nc += 1
			cp = c.global_position
	if nc > 0:
		m.append(["Корови (%d)" % nc, cp, Color(0.25, 0.25, 0.25)])
	if horse and horse.visible:
		m.append(["Кінь", horse.global_position, Color(0.6, 0.45, 0.3)])
	if tea_boy:
		m.append(["Хлопець у чайній", tea_boy.global_position, Color(0.25, 0.35, 0.7)])
	if market_bot:
		m.append(["EngineBot на ринку", market_bot.global_position, Color(0.5, 0.5, 0.6)])
	m.append(["Beep (ти)", beep.global_position if Game.state["location"] == "yard" else world.HOUSE_POS, Color(0.1, 0.7, 0.75)])
	for e in m:
		var pn: String = world.outer.place_name(e[1])
		if String(e[0]).ends_with("(у хаті)"):
			pn = "у хаті"
		e.append(pn)
	return m


# ------------------------------------------------------------------ трактор, садок, грибний ліс
const COW_DOOR := Vector3(11.9, 0, -25.5)          # біля дверей корівника (зовні)
const COW_PASTURE := Rect2(1.0, -44.0, 22.0, 12.0)    # пасовисько за корівником
const HORSE_DOOR := Vector3(-8.7, 0, -21.5)           # біля дверей стайні
const HORSE_PADDOCK := Rect2(-19.0, -21.0, 8.5, 4.0)
const CART_PARK := Vector3(-16.0, 0, -26.0)            # де стоїть віз (західніше стайні)
var cows: Array = []                                  # корови + бичок
var horse
var horse_cart


func _spawn_cattle() -> void:
	## Бичок і п'ять корів (пасуться за корівником, на ніч — у корівник), кінь — у стайні.
	var rng := RandomNumberGenerator.new()
	rng.seed = 31
	if Models.exists("bull"):
		bull = preload("res://scripts/bull.gd").new()
		world.yard_root.add_child(bull)
		bull.setup(Vector3(12.0, 0, -36.0), COW_DOOR, "bull", 1.55, COW_PASTURE)
		bull.door_in = Vector3(-3.0, 0, 0)
		cows.append(bull)
	if Models.exists("cow"):
		var names := ["Зірка", "Ласка", "Квітка", "Красуля", "Мілка"]
		for i in 5:
			var c = preload("res://scripts/bull.gd").new()
			world.yard_root.add_child(c)
			c.setup(Vector3(rng.randf_range(3.0, 21.0), 0, rng.randf_range(-42.0, -33.0)), COW_DOOR, "cow", rng.randf_range(1.35, 1.5), COW_PASTURE)
			c.door_in = Vector3(-3.0, 0, rng.randf_range(-0.6, 0.6))
			c.voices = ["Му-у-у! Я — %s." % names[i], "Мууу!", "Му-у! Молочко буде!"]
			c.night_from = 19.8 + i * 0.08
			c.set_meta("name", names[i])
			cows.append(c)
	if Models.exists("horse"):
		horse = preload("res://scripts/bull.gd").new()
		world.yard_root.add_child(horse)
		horse.setup(Vector3(-15.0, 0, -18.5), HORSE_DOOR, "horse", 1.75, HORSE_PADDOCK)
		horse.door_in = Vector3(0, 0, -3.0)
		horse.voices = ["І-го-го!", "Пфррр!", "І-го-го! Поїдемо кудись?"]
		horse.area.set_meta("kind", "horse")
		horse.night_from = 20.3
		if Models.exists("cart"):
			# віз стоїть біля стайні, оглоблями на північ (кінь стає перед ним)
			horse_cart = preload("res://scripts/cart.gd").new()
			world.yard_root.add_child(horse_cart)
			horse_cart.setup(CART_PARK, PI)


func _check_models() -> void:
	## Якщо якогось архіву з моделями не завантажили на GitHub — кажемо, якого саме.
	var need := {"girl": "models_3.zip", "turkey": "models_4.zip", "market": "models_5.zip", "bull": "models_6.zip", "cow": "models_11.zip", "horse": "models_11.zip", "cart": "models_11.zip",
		"bed": "models_7.zip", "kiosks": "models_9.zip", "plane_y": "models_10.zip", "tractor": "models_10.zip", "grandpa_house": "models_10.zip"}
	var miss: Array = []
	for id in need:
		if not Models.exists(id) and not (need[id] in miss):
			miss.append(need[id])
	if not miss.is_empty():
		await get_tree().create_timer(2.0).timeout
		hud.toast("Не вистачає моделей — завантаж на GitHub: " + ", ".join(miss), 8.0)


func _grandpa_talk() -> void:
	var q := Game.current_quest()
	var txt: String = "Відпочинь, онучку. Завтра буде новий день!"
	if not q.is_empty() and q.get("giver", "Дідусь Петро") == "Дідусь Петро":
		txt = q["text"]
	elif not q.is_empty():
		txt = "%s просить тебе: %s" % [q["giver"], q["short"]]
	_grandpa_dialog(txt)


func _follow_later(who: Node3D) -> void:
	## Камера йде за дідусем, поки він працює за двором.
	await get_tree().create_timer(0.3).timeout
	if Game.state["location"] != "yard":
		leave_house()
		await get_tree().create_timer(0.8).timeout
	cam_follow = who


func _spawn_farm_extras() -> void:
	var o = world.outer
	if Models.exists("tractor"):
		tractor = preload("res://scripts/tractor.gd").new()
		world.yard_root.add_child(tractor)
		tractor.setup(o.SHED, PI / 2.0, o.PLOW_FIELD)
		tractor.make_field(world.yard_root)
		_make_tractor_shed(o.SHED)
		grandpa.tractor = tractor
	orchard = preload("res://scripts/orchard.gd").new()
	world.yard_root.add_child(orchard)
	orchard.build()
	grandpa.orchard = orchard
	forest = preload("res://scripts/forest_goods.gd").new()
	world.yard_root.add_child(forest)
	forest.build(o.trees)
	grandpa.forest = forest
	o.apply_view_ranges(forest, 3.0, 45.0)


func _make_tractor_shed(p: Vector3) -> void:
	## Навіс для трактора: чотири стовпи й похилий дах з дощок.
	var n := Node3D.new()
	n.position = p
	world.yard_root.add_child(n)
	var wood := Util.mat(Color(0.5, 0.35, 0.22), 0.9)
	var roof := Util.mat(Color(0.45, 0.4, 0.36), 0.8)
	for sx in [-2.6, 2.6]:
		for sz in [-1.7, 1.7]:
			n.add_child(Util.box(Vector3(0.16, 3.4 if sz < 0.0 else 3.1, 0.16), wood, Vector3(sx, (3.4 if sz < 0.0 else 3.1) * 0.5, sz)))
			Obstacles.add_outer(p.x + sx, p.z + sz, 0.25, 2.5)
	for sz in [-1.7, 1.7]:
		n.add_child(Util.box(Vector3(5.6, 0.14, 0.14), wood, Vector3(0, 3.4 if sz < 0.0 else 3.1, sz)))
	for k in 9:
		var pl := Util.box(Vector3(0.62, 0.06, 4.2), roof if k % 2 == 0 else wood, Vector3(-2.5 + k * 0.62, 3.32, 0))
		pl.rotation.x = -0.09
		n.add_child(pl)
	Obstacles.finish()


# ------------------------------------------------------------------ політ на літаку
func start_ride() -> void:
	## Beep летить на аеродром, літак виїжджає з ангара, Beep сідає в кабіну — і злітаємо.
	if riding or plane == null:
		return
	if _ctl_beep:
		stop_beep_control()
	if Game.state["location"] != "yard":
		leave_house()
		await get_tree().create_timer(0.8).timeout
	riding = true
	cam_follow = null
	beep.outdoors = true
	beep.say("Летимо до літака!", 2.5)
	var side: Vector3 = plane.global_position + Vector3(0, 0, 5.5)
	if plane.in_hangar:
		side = world.outer.RUNWAY_A + Vector3(2.0, 0, 6.0)
		plane.roll_out()
	var arrived := [false]
	beep.fly_to(side, func(): arrived[0] = true)
	_track = beep
	rig.glide_to(14.0, -20.0)
	var t := 0.0
	while not arrived[0] and t < 90.0:
		t += get_process_delta_time()
		await get_tree().process_frame
	while plane.state != "rest" and t < 120.0:
		t += get_process_delta_time()
		await get_tree().process_frame
	if not riding:
		return
	# у кабіну сідає Ніка (якщо її нема — Beep)
	_track = plane
	plane.say("Р-р-р-р! Мотор працює!", 2.0)
	if girl and girl.has_method("board_plane"):
		if girl.global_position.distance_to(plane.global_position) > 14.0:
			hud.fade(true)
			await get_tree().create_timer(0.45).timeout
			girl.cancel_job()
			girl.visible = true
			girl.global_position = plane.to_global(Vector3(-3.2, 0, 1.0))
			hud.fade(false)
		beep.say("Ніко, сідай за штурвал!", 2.5)
		girl.say("Лечу-у-у!", 2.0)
		await girl.board_plane(plane)
		plane.rider = girl
		beep.moving = false
		beep.fly_to(world.outer.RUNWAY_A + Vector3(3.0, 0, 7.0))
	else:
		var from: Vector3 = beep.global_position + Vector3(0, beep.HOVER, 0)
		var k := 0.0
		beep.moving = false
		beep.piloting = true
		while k < 1.0:
			k = minf(1.0, k + get_process_delta_time() / 1.2)
			var to: Vector3 = plane.seat_global()
			var p: Vector3 = from.lerp(to, k)
			p.y += sin(k * PI) * 1.2
			beep.global_position = p
			await get_tree().process_frame
		plane.pilot = beep
		plane.rider = beep
		beep.say("Пристебнувся!", 1.5)
	_track = null
	hud.show_flight(true)
	hud.flight.home_text = "В ангар"
	hud.flight.land_text = "Сісти"
	hud.toast("Джойстик — кермо, ▲▼ — висота", 4.0)
	rig.glide_to(12.0, -12.0)
	await plane.take_off(true)


var _dbg_cam := Vector3.ZERO          # лише для перевірки: близько до літака


func _ride_cam(delta: float) -> void:
	## Камера позаду літака, трохи згори.
	plane.joy = hud.flight.joy
	plane.climb = hud.flight.climb
	rig.focus = plane.global_position + Vector3(0, 1.6, 0)
	rig.target = rig.focus
	var want := rad_to_deg(plane.rotation.y) + 180.0 + _dbg_cam.y
	if _dbg_cam.x > 0.0:
		rig.dist = _dbg_cam.x
		rig.pitch = _dbg_cam.z
		rig.yaw = want
		return
	rig.yaw += wrapf(want - rig.yaw, -180.0, 180.0) * (1.0 - exp(-delta * 2.5))
	rig.yaw = wrapf(rig.yaw, rig.yaw_center - 180.0, rig.yaw_center + 180.0)
	if rig._want_dist < 0.0:
		rig.dist = lerpf(rig.dist, 13.0, 1.0 - exp(-delta * 1.0))


func _on_plane_landed() -> void:
	if not riding:
		return
	hud.show_flight(false)
	Game.emit_event("plane_flight")
	Game.emit_event("dragon_flight")
	var was: Node3D = plane.rider
	plane.pilot = null
	plane.rider = null
	if was == girl and girl:
		await girl.leave_plane(plane)
		girl.say("Приземлились! Ох і гарно було!", 2.5)
	else:
		beep.piloting = false
		# Beep вистрибує з кабіни поруч
		var to: Vector3 = plane.global_position + plane.global_transform.basis.x * 3.0
		to.y = 0.0
		var from: Vector3 = beep.global_position
		var k := 0.0
		while k < 1.0:
			k = minf(1.0, k + get_process_delta_time() / 0.8)
			var p: Vector3 = from.lerp(to, k)
			p.y = lerpf(from.y, 0.0, k) + sin(k * PI) * 0.8
			beep.global_position = p
			await get_tree().process_frame
		beep.global_position = to
		beep.rotation = Vector3(0, beep.rotation.y, 0)
	riding = false
	beep.say("Приземлились!" if not plane.in_hangar else "Літак в ангарі!", 2.0)
	overview()


# ------------------------------------------------------------------ ручне керування трактором і возом
func vehicle_control_start(kind: String, veh: Node3D) -> void:
	## Дідусь уже сидить — гравець бере кермо: джойстик їде й повертає, «Готово» віддає кермо.
	_ctl_veh = veh
	_veh_kind = kind
	cam_follow = null
	hud.show_flight(true)
	hud.flight.home_text = "Готово"
	hud.flight.land_text = ""
	if kind == "tractor":
		hud.toast("Джойстик — їхати й повертати, ▲ — підняти плуг, ▼ — опустити. «Готово» — поставити трактор додому", 6.0)
	else:
		hud.toast("Джойстик — вести коня з возом. «Готово» — повернути коня в стайню", 5.0)


func vehicle_control_stop() -> void:
	if _ctl_veh == null and _veh_kind == "":
		return
	_ctl_veh = null
	_veh_kind = ""
	hud.show_flight(false)
	hud.flight.home_text = "В ангар"
	hud.flight.land_text = "Сісти"
	overview()


func _veh_cam(delta: float) -> void:
	## Керування й камера: позаду транспорту, трохи згори.
	var j: Vector2 = hud.flight.joy
	var v: Node3D = _ctl_veh
	if _veh_kind == "tractor":
		tractor.manual_step(j, hud.flight.climb, delta)
	elif horse_cart:
		horse_cart.manual_step(j, delta)
	rig.focus = v.global_position + Vector3(0, 1.2, 0)
	rig.target = rig.focus
	var moving_fast: bool = absf(float(v.get("speed"))) > 0.4
	if moving_fast:
		var want := rad_to_deg(v.rotation.y) + 180.0
		rig.yaw += wrapf(want - rig.yaw, -180.0, 180.0) * (1.0 - exp(-delta * 1.2))
		rig.yaw = wrapf(rig.yaw, rig.yaw_center - 180.0, rig.yaw_center + 180.0)
	if rig._want_dist < 0.0:
		rig.dist = lerpf(rig.dist, 9.0, 1.0 - exp(-delta * 1.0))


# ------------------------------------------------------------------ ручне керування Beep
func start_beep_control() -> void:
	if riding:
		return
	if Game.state["location"] != "yard":
		leave_house()
		await get_tree().create_timer(0.6).timeout
	_ctl_beep = true
	beep.moving = false
	cam_follow = null
	hud.show_flight(true)
	hud.flight.home_text = "Готово"
	hud.flight.land_text = "На землю"
	hud.toast("Джойстик — куди летіти, ▲▼ — вище й нижче. «Готово» — Beep знову сам", 4.5)


func stop_beep_control() -> void:
	_ctl_beep = false
	hud.show_flight(false)
	beep.drive(Vector2.ZERO, 0.0, 0.0)
	beep._lift_want = 0.0
	overview()


func _beep_cam(delta: float) -> void:
	var j: Vector2 = hud.flight.joy
	beep.drive(j, hud.flight.climb, delta, rig.yaw)
	rig.focus = beep.global_position + Vector3(0, 0.6 + beep.lift, 0)
	rig.target = rig.focus
	if j.length() > 0.2:
		var want := rad_to_deg(beep.rotation.y) + 180.0
		rig.yaw += wrapf(want - rig.yaw, -180.0, 180.0) * (1.0 - exp(-delta * 0.8))
		rig.yaw = wrapf(rig.yaw, rig.yaw_center - 180.0, rig.yaw_center + 180.0)


func _on_seed(left: int) -> void:
	audio.play("magic_bells", -2.0, 1.2)
	audio.play("coins", -8.0)
	if left > 0:
		hud.toast("Золота насінинка!  Залишилось: %d" % left, 2.5)
		beep.say(["Є!", "Ура, ще одна!", "Ловимо!", "Яка блискуча!"][randi() % 4], 1.5)
	else:
		hud.toast("Усі золоті насінинки зібрано!", 4.0)
		beep.say("Усі! Летимо до дідуся!", 3.0)
		_make_gold_flower(true)


func _make_gold_flower(grow: bool) -> void:
	## Чарівний соняшник біля хати — нагорода за всі насінинки.
	if gold_flower:
		return
	gold_flower = Node3D.new()
	gold_flower.position = GOLD_FLOWER_POS
	world.yard_root.add_child(gold_flower)
	var stem := Util.mat(Color(0.35, 0.6, 0.2), 0.7)
	gold_flower.add_child(Util.cyl(0.05, 0.07, 2.4, stem, Vector3(0, 1.2, 0)))
	for k in 4:
		var leaf := Util.sphere(0.25, stem, Vector3(0.22 if k % 2 == 0 else -0.22, 0.6 + k * 0.4, 0), Vector3(1.3, 0.12, 0.6))
		leaf.rotation.z = 0.5 if k % 2 == 0 else -0.5
		gold_flower.add_child(leaf)
	var head := Node3D.new()
	head.position = Vector3(0, 2.45, 0.08)
	head.rotation.x = deg_to_rad(-18)
	gold_flower.add_child(head)
	var petal := Util.mat(Color(1.0, 0.8, 0.15), 0.35, 0.3, Color(1.0, 0.7, 0.1), 1.2)
	for k in 20:
		var a := TAU * k / 20.0
		var pt := Util.sphere(0.2, petal, Vector3(cos(a) * 0.42, sin(a) * 0.42, 0), Vector3(0.45, 1.0, 0.12))
		pt.rotation.z = a - PI / 2.0
		head.add_child(pt)
	head.add_child(Util.cyl(0.32, 0.32, 0.12, Util.mat(Color(0.4, 0.25, 0.08), 0.8, 0.0, Color(0.5, 0.3, 0.05), 0.4), Vector3(0, 0, 0.03), Vector3(PI / 2, 0, 0)))
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.82, 0.4)
	l.light_energy = 1.4
	l.omni_range = 6.0
	l.position = Vector3(0, 2.5, 0.6)
	gold_flower.add_child(l)
	gold_flower.add_child(Util.pick_area("gold_flower", Vector3(1.2, 3.0, 1.2), Vector3(0, 1.5, 0)))
	if grow:
		gold_flower.scale = Vector3(0.05, 0.05, 0.05)
		create_tween().tween_property(gold_flower, "scale", Vector3.ONE, 6.0).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT).set_delay(2.0)


func focus_on(n: Node3D, kind: String) -> void:
	## Торкнулися персонажа чи предмета — камера підлітає й стежить за ним.
	if n == null or not FOCUS.has(kind):
		return
	if kind == "beep":
		cam_follow = null
	else:
		cam_follow = n
	var f: Array = FOCUS[kind]
	_cam_up = float(f[2])
	rig.glide_to(float(f[0]), float(f[1]))
	if n.has_meta("view_from"):
		# продавці стоять за прилавком — дивимося з боку покупця
		var vf: Vector3 = n.get_meta("view_from")
		rig.yaw = rad_to_deg(atan2(vf.x, vf.z))
	if hud:
		hud.show_overview_button(cam_follow != null)


func overview() -> void:
	## Загальний огляд: камера відлітає вгору й показує все довкола Beep (у хаті — усю кімнату).
	cam_follow = null
	if Game.state["location"] == "room":
		rig.focus = world.ROOM + Vector3(0, 1.25, 0.2)
		rig.yaw = 20.0
		rig.glide_to(2.3, -16.0)
		if hud:
			hud.show_overview_button(false)
		return
	_cam_up = 0.8
	rig.glide_to(15.0, -34.0)
	if hud:
		hud.show_overview_button(false)


# ------------------------------------------------------------------ Beep заходить у хату й виходить через двері
var _door_busy := false


func enter_house() -> void:
	if _door_busy or Game.state["location"] == "room":
		return
	_door_busy = true
	var sp: Dictionary = world.spots
	var door: Vector3 = sp["door"]
	await _beep_fly_and_wait(door + Vector3(0, 0, 0.3))
	world.set_door("house", true)
	await get_tree().create_timer(0.5).timeout
	await _beep_fly_and_wait(door + Vector3(0, 0, -0.9))
	world.set_door("house", false, 0.3)
	go_to("room")
	# у кімнаті: залітає з-за дверей
	var rd: Vector3 = sp["room_door"]
	beep.position = rd + Vector3(0, 0, 1.0)
	world.set_door("room", true, 0.35)
	await get_tree().create_timer(0.35).timeout
	await _beep_fly_and_wait(rd + Vector3(1.3, 0, -2.2))
	world.set_door("room", false)
	_door_busy = false


func leave_house() -> void:
	if _door_busy or Game.state["location"] != "room":
		return
	_door_busy = true
	var sp: Dictionary = world.spots
	var rd: Vector3 = sp["room_door"]
	await _beep_fly_and_wait(rd + Vector3(0, 0, -0.2))
	world.set_door("room", true)
	await get_tree().create_timer(0.5).timeout
	await _beep_fly_and_wait(rd + Vector3(0, 0, 1.0))
	world.set_door("room", false, 0.3)
	go_to("yard", false, true)
	var door: Vector3 = sp["door"]
	beep.position = door + Vector3(0, 0, -0.9)
	world.set_door("house", true, 0.35)
	await get_tree().create_timer(0.35).timeout
	await _beep_fly_and_wait(door + Vector3(0.4, 0, 1.4))
	world.set_door("house", false)
	_door_busy = false


func _beep_fly_and_wait(p: Vector3) -> void:
	var done := [false]
	beep.fly_to_raw(p, func(): done[0] = true)
	var t := 0.0
	while not done[0] and t < 6.0:
		t += get_process_delta_time()
		await get_tree().process_frame


# ------------------------------------------------------------------ життя на фермі
func _lives_outside(n) -> void:
	n.lives_outside = true
	var h := Game.hour()
	if h >= 19.3 or h < 7.3:
		n.at_home = true
		n.visible = false
		n.bounds = n.OUT_BOUNDS
		n.position = world.spots["kid_home"]

func _hens_outside() -> bool:
	for b in birds:
		if b.mode != "inside":
			return true
	return false


func herd_hens() -> void:
	if puppy.doing == "herd":
		return
	beep.say("Біме, жени курочок додому!", 2.5)
	audio.play_at("puppy_bark", puppy, -2.0)
	puppy.herd_hens(birds, world.spots["coop_door"])


func throw_ball() -> void:
	## Beep кидає м'ячик, Бім біжить і приносить.
	if Game.state["location"] != "yard":
		return
	if puppy.doing == "fetch":
		hud.toast("Бім уже біжить за м'ячиком!")
		return
	if ball == null:
		ball = Node3D.new()
		ball.add_child(Util.sphere(0.07, Util.mat(Color(0.9, 0.2, 0.2), 0.4), Vector3.ZERO))
		ball.add_child(Util.sphere(0.071, Util.mat(Color(1, 0.95, 0.4), 0.4), Vector3.ZERO, Vector3(1, 0.25, 1)))
		world.yard_root.add_child(ball)
	if ball.get_parent() != world.yard_root:
		ball.reparent(world.yard_root)
	var from: Vector3 = beep.global_position + Vector3(0, 1.0, 0)
	var a := randf() * TAU
	var to := Vector3(clampf(from.x + cos(a) * randf_range(3.0, 5.5), -20.0, 8.0), 0.07, clampf(from.z + sin(a) * randf_range(3.0, 5.5), -14.0, 4.2))
	to = Obstacles.push_out(to, 0.25)
	ball.global_position = from
	beep.say("Апорт!", 1.5)
	beep.happy()
	audio.play_at("pop", beep, -4.0)
	puppy.say("Гав!", 1.0)
	var tw := create_tween()
	tw.tween_method(func(t: float):
		var p: Vector3 = from.lerp(to, t)
		p.y = lerpf(from.y, 0.07, t) + sin(t * PI) * 1.6
		ball.global_position = p, 0.0, 1.0, 0.9)
	await tw.finished
	puppy.fetch(ball, beep)


func _scan_text() -> String:
	var s := Game.state
	var p: Dictionary = s["puppy"]
	var lines: Array = []
	lines.append("Бім: ситість %d%%, радість %d%%%s" % [100 - int(p["hunger"]), int(p["joy"]), "" if float(s["water_bowl"]) > 1.0 else ", мисочка з водою порожня"])
	lines.append("Кури: %s, %s" % ["нагодовані" if float(s["hens_fed"]) > 30.0 else "голодні", "корито з водою" if float(s["trough"]) > 1.0 else "корито порожнє"])
	var f: Dictionary = s["field"]
	lines.append("Город: вологість %d%%, соняшники виросли на %d%%" % [int(f["water"]), int(float(f["growth"]) * 100.0)])
	lines.append("Яєць у кошику: %d" % int(s.get("eggs", 0)))
	lines.append("Лимончик: %.1f °C — %s" % [float(s["gecko"]["temp"]), Game.gecko_mood()])
	return "\n".join(lines)


var _pond_day := -1
var _back_day := -1
const GEESE_WAY := [Vector3(-3.0, 0, 2.6), Vector3(0, 0, 3.6), Vector3(0, 0, 7.5), Vector3(0.5, 0, 19.0), Vector3(0, 0, 28.5),
	Vector3(-23.0, 0, 26.0), Vector3(-45.0, 0, 23.5), Vector3(-50.0, 0, 27.5)]


func _swimmers() -> Array:
	## Плавають лише гуси (індик лишається на подвір'ї).
	return geese.filter(func(g): return g.voice == "Га-га-га!")


func _geese_home() -> bool:
	for g in _swimmers():
		if not g.mode in ["free", "grain", "trough"]:
			return false
	return not geese.is_empty()


func _geese_at_pond() -> bool:
	for g in geese:
		if g.mode == "swim" or g.mode == "trek":
			return true
	return false


func geese_to_pond() -> void:
	var c: Vector3 = world.outer.POND
	var flock := _swimmers()
	puppy.herd_geese(flock, true, GEESE_WAY, func():
		var i := 0
		for g in flock:
			g.pond_c = c
			g.pond_r = 7.0
			g.trek_offset = Vector3(randf_range(-0.6, 0.6), 0, randf_range(-0.6, 0.6))
			g.start_trek(GEESE_WAY, "swim", i * 0.7)
			i += 1)


func geese_from_pond() -> void:
	var back := GEESE_WAY.duplicate()
	back.reverse()
	back.append(Vector3(-8.0, 0, 1.0))
	puppy.herd_geese(_swimmers(), false, GEESE_WAY, func():
		var i := 0
		for g in geese:
			if g.mode == "swim":
				var pts: Array = [g.global_position + (back[0] - g.global_position).normalized() * 0.0]
				pts.append_array(back)
				g.start_trek(pts, "free", i * 0.6)
			i += 1)


func _farm_tick() -> void:
	## Раз на секунду: увечері Бім заганяє курей (якщо гравець не встиг), зранку кури виходять.
	var h := Game.hour()
	var d := int(Game.state["day"])
	var waiting_for_player: bool = Game.current_quest().get("id", "") == "hens_home"
	if (h >= (21.5 if waiting_for_player else 20.3) or h < 5.0) and _hens_outside() and _herd_day != d and puppy.doing != "herd":
		_herd_day = d
		herd_hens()
	if h >= 6.5 and h < 11.0 and _out_day != d:
		_out_day = d
		for b in birds:
			b.come_out(world.spots["coop_door"])
		for g in geese:
			g.come_out(world.spots["barn"])
	# удень Бім жене гусей (й індика) на ставок, по обіді — назад
	if h >= 10.0 and h < 13.0 and _pond_day != d and _geese_home() and puppy.doing == "" and not puppy.in_house and Game.state["location"] == "yard":
		_pond_day = d
		geese_to_pond()
	if (h >= 16.0 and h < 20.0 or h >= 20.0 and _geese_at_pond()) and _geese_at_pond() and _back_day != d and puppy.doing in ["", "doghouse"]:
		_back_day = d
		geese_from_pond()
	# гуси самі йдуть ночувати в сарай
	if (h >= 20.0 or h < 5.0) and _geese_day != d and not _geese_at_pond():
		_geese_day = d
		for g in geese:
			if g.mode != "inside":
				g.go_coop(world.spots["barn"])
	if waiting_for_player and h >= 18.5 and h < 18.6:
		hud.toast("Вечоріє! Торкнись Біма — він зажене курей", 3.0)


# ------------------------------------------------------------------ квести
const PORTRAITS := {"Дідусь Петро": "grandpa", "Тарасик": "kid", "Гвинтик": "gvintyk", "Beep": "beep", "Ніка": "girl"}
const GOLD_FLOWER_POS := Vector3(2.6, 0, -5.4)


func _portrait(giver: String) -> Texture2D:
	var f := "res://assets/ui/%s.png" % PORTRAITS.get(giver, "grandpa")
	return load(f) if ResourceLoader.exists(f) else null


func _on_quest_started(q: Dictionary) -> void:
	var giver: String = q.get("giver", "Дідусь Петро")
	if q["goal"] == "seed" and seeds and seeds.left() == 0:
		Game.complete_quest.call_deferred()
	if giver != "Дідусь Петро":
		audio.play("page", -8.0)
		hud.show_dialog(giver, q["text"], _portrait(giver))
		return
	if not _greeted and Game.state["location"] == "yard":
		_greeted = true
		grandpa.wave_at(rig.cam.global_position)
		await get_tree().create_timer(1.2).timeout
	_grandpa_dialog(q["text"])


# ------------------------------------------------------------------ день і ніч
var fireflies: Array = []
var falling_star: Node3D
var _night_busy := false
var hit_node: Node3D                   # чого торкнулися останнім (для світлячків)


func _sleep_mode() -> String:
	if _night_busy or riding:
		return ""
	if Game.night_active():
		return "sleep" if Game.night_done() else ""
	if Game.is_night():
		return "sleep"                     # денні справи не зроблено, а вже ніч (стара гра) — можна спати
	if Game.day_done():
		if Game.current_quest().is_empty() and Game.hour() < 15.0:
			return ""
		return "goodnight"
	return ""


func _goodnight() -> void:
	## «На добраніч»: сонце швидко сідає, усі розходяться по домівках.
	if _night_busy:
		return
	_night_busy = true
	hud.toast("На добраніч! Усі розходяться по домівках…", 3.5)
	overview()
	var h0 := Game.hour()
	var tw := create_tween()
	tw.tween_method(func(v: float): Game.state["time"] = v, h0, 21.3, 5.0).set_trans(Tween.TRANS_SINE)
	await tw.finished
	_night_busy = false


func _sleep_to_morning() -> void:
	if _night_busy:
		return
	_night_busy = true
	if beep.lamp.visible:
		beep.toggle_lamp()
	await hud.fade(true, 1.2)
	Game.sleep_to_morning()
	grandpa.bed_now = false
	_clear_night_things()
	grandpa.cover(false)
	await get_tree().create_timer(0.6).timeout
	await hud.fade(false, 1.2)
	hud.toast("Доброго ранку! День %d" % int(Game.state["day"]), 3.0)
	_night_busy = false


func _on_night_started(t: Dictionary) -> void:
	audio.play("page", -8.0)
	var giver: String = t.get("giver", "Beep")
	hud.show_dialog(giver, t["text"], _portrait(giver))


func _night_step() -> void:
	## Раз на чверть секунди: кнопка сну, нічні справи (світлячки, зірка, обхід курника).
	if hud:
		hud.update_sleep_button(_sleep_mode())
	var t := Game.night_task() if Game.night_active() else {}
	var goal: String = t.get("goal", "")
	# світлячки
	if goal == "firefly":
		if fireflies.is_empty():
			_spawn_fireflies(int(t["count"]) - int(Game.state["night"].get("progress", 0)))
		for f in fireflies.duplicate():
			if not is_instance_valid(f):
				fireflies.erase(f)
				continue
			var d := Vector2(f.global_position.x - beep.global_position.x, f.global_position.z - beep.global_position.z).length()
			if d < 1.3 and Game.state["location"] == "yard":
				fireflies.erase(f)
				_pop_sparkles(f.global_position, Color(0.8, 1.0, 0.4))
				f.queue_free()
				audio.play("magic_bells", -10.0, 1.4)
				Game.emit_event("firefly")
	elif not fireflies.is_empty():
		for f in fireflies:
			if is_instance_valid(f):
				f.queue_free()
		fireflies.clear()
	# падаюча зірка
	if goal == "star":
		if falling_star == null:
			_spawn_star()
		elif plane and riding and falling_star.global_position.distance_to(plane.global_position) < 7.0:
			_pop_sparkles(falling_star.global_position, Color(1.0, 0.9, 0.5))
			falling_star.queue_free()
			falling_star = null
			audio.play("magic_bells", -2.0, 1.1)
			beep.say("Спіймали зірочку!", 2.5)
			Game.emit_event("star")
	elif falling_star:
		falling_star.queue_free()
		falling_star = null
	# обхід курника з ліхтариком
	if goal == "coop_checked" and beep.lamp.visible and Game.state["location"] == "yard":
		var cp: Vector3 = world.spots["coop"]
		if Vector2(beep.global_position.x - cp.x, beep.global_position.z - cp.z).length() < 3.0:
			beep.say("Раз, два, три… усі вдома!", 2.5)
			Game.emit_event("coop_checked")


func _clear_night_things() -> void:
	for f in fireflies:
		if is_instance_valid(f):
			f.queue_free()
	fireflies.clear()
	if falling_star:
		falling_star.queue_free()
		falling_star = null


const FIREFLY_SPOTS := [Vector3(12.0, 0, -6.0), Vector3(15.5, 0, -2.0), Vector3(18.0, 0, -9.0), Vector3(13.0, 0, 1.5),
	Vector3(-4.0, 0, 3.0), Vector3(-9.5, 0, -3.0), Vector3(2.0, 0, 3.6), Vector3(-12.0, 0, -6.0)]


func _spawn_fireflies(n: int) -> void:
	var glow := StandardMaterial3D.new()
	glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	glow.albedo_color = Color(0.85, 1.0, 0.45)
	var spots := FIREFLY_SPOTS.duplicate()
	spots.shuffle()
	for i in mini(n, spots.size()):
		var f := Node3D.new()
		f.set_script(preload("res://scripts/firefly.gd"))
		world.yard_root.add_child(f)
		f.position = spots[i] + Vector3(0, 1.1, 0)
		f.add_child(Util.sphere(0.07, glow, Vector3.ZERO))
		var l := OmniLight3D.new()
		l.light_color = Color(0.8, 1.0, 0.45)
		l.light_energy = 1.4
		l.omni_range = 2.2
		f.add_child(l)
		f.add_child(Util.pick_area("firefly", Vector3(1.0, 1.0, 1.0), Vector3.ZERO))
		fireflies.append(f)


func _spawn_star() -> void:
	## Падаюча зірка повільно пливе над селом — її ловлять верхи на драконі.
	falling_star = Node3D.new()
	falling_star.set_script(preload("res://scripts/firefly.gd"))
	falling_star.set("drift", 3.0)
	world.yard_root.add_child(falling_star)
	falling_star.position = Vector3(-8.0, 24.0, 40.0)
	var gold := StandardMaterial3D.new()
	gold.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	gold.albedo_color = Color(1.0, 0.92, 0.55)
	var st := Node3D.new()
	falling_star.add_child(st)
	for k in 5:
		var a := TAU * k / 5.0
		var ray := Util.sphere(0.35, gold, Vector3(sin(a), cos(a), 0) * 0.6, Vector3(0.45, 1.3, 0.3))
		ray.rotation.z = -a
		st.add_child(ray)
	st.add_child(Util.sphere(0.55, gold, Vector3.ZERO))
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.9, 0.6)
	l.light_energy = 3.0
	l.omni_range = 12.0
	falling_star.add_child(l)
	var tail := CPUParticles3D.new()
	tail.amount = 60
	tail.lifetime = 1.6
	tail.gravity = Vector3(0, -0.6, 0)
	tail.initial_velocity_min = 0.2
	tail.initial_velocity_max = 0.6
	tail.spread = 180.0
	var m := SphereMesh.new()
	m.radius = 0.12
	m.height = 0.24
	m.radial_segments = 6
	m.rings = 3
	tail.mesh = m
	tail.material_override = gold
	falling_star.add_child(tail)


func _pop_sparkles(at: Vector3, col: Color) -> void:
	var p := CPUParticles3D.new()
	p.amount = 30
	p.one_shot = true
	p.explosiveness = 0.9
	p.lifetime = 1.0
	p.spread = 180.0
	p.initial_velocity_min = 1.5
	p.initial_velocity_max = 3.0
	p.gravity = Vector3(0, -1.5, 0)
	var m := SphereMesh.new()
	m.radius = 0.05
	m.height = 0.1
	m.radial_segments = 6
	m.rings = 3
	p.mesh = m
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.albedo_color = col
	p.material_override = mt
	world.yard_root.add_child(p)
	p.global_position = at
	p.emitting = true
	get_tree().create_timer(1.6).timeout.connect(p.queue_free)


func _on_quest_done(q: Dictionary) -> void:
	audio.play("win", -2.0)
	audio.play("coins", -6.0)
	if q.get("done", "") != "":
		hud.toast("+%d ●   %s" % [q["reward"], q["done"]], 3.5)
	await get_tree().create_timer(1.6).timeout
	Game.start_quest()


# ------------------------------------------------------------------ перевірка (лише для розробки)
func _run_demo() -> void:
	var steps: PackedStringArray = _demo.split(",")
	for s in steps:
		await get_tree().create_timer(0.6).timeout
		if hud.dialog_open() and not s.begins_with("shot"):
			hud._close_dialog()
			await get_tree().create_timer(0.3).timeout
		print("DEMO ", s)
		if s.begins_with("wait"):
			await get_tree().create_timer(float(s.substr(4))).timeout
		elif s.begins_with("shot:"):
			get_viewport().get_texture().get_image().save_png(s.substr(5))
			print("SHOT ", s.substr(5))
		elif s.begins_with("time:"):
			Game.state["time"] = float(s.substr(5))
		elif s.begins_with("lookat:"):
			var xz := s.substr(7).split(";")
			_track = Node3D.new()
			add_child(_track)
			_track.position = Vector3(float(xz[0]), float(xz[2]) if xz.size() > 2 else 0.5, float(xz[1]))
		elif s.begins_with("yaw:"):
			rig.yaw = float(s.substr(4))
		elif s.begins_with("dist:"):
			rig.dist = float(s.substr(5))
		elif s.begins_with("pitch:"):
			rig.pitch = float(s.substr(6))
		elif s.begins_with("call:"):
			# call:хто:метод[:аргумент] — для перевірки справ персонажів
			var c := s.substr(5).split(":")
			var who = get(c[0])
			if who:
				var args: Array = []
				if c.size() > 2:
					args.append(c[2])
				who.callv(c[1], args)
		elif s.begins_with("ortho:"):
			# ortho:x;z;розмір — вигляд згори (для розстановки перешкод)
			var c := s.substr(6).split(";")
			rig.set_process(false)
			set_process(false)
			hud.visible = false
			rig.cam.projection = Camera3D.PROJECTION_ORTHOGONAL
			rig.cam.size = float(c[2])
			rig.cam.global_transform = Transform3D(Basis.from_euler(Vector3(-PI / 2, 0, 0)), Vector3(float(c[0]), 40, float(c[1])))
			rig.cam.far = 100.0
		elif s == "persp":
			rig.cam.projection = Camera3D.PROJECTION_PERSPECTIVE
			rig.cam.far = 400.0
			rig.set_process(true)
			set_process(true)
			hud.visible = true
		elif s.begins_with("orthof:"):
			# orthof:x;y;z;розмір;кут — вигляд збоку без перспективи (камера дивиться в точку з боку кута)
			var c := s.substr(7).split(";")
			rig.set_process(false)
			set_process(false)
			hud.visible = false
			var yw := deg_to_rad(float(c[4]))
			var at := Vector3(float(c[0]), float(c[1]), float(c[2]))
			rig.cam.projection = Camera3D.PROJECTION_ORTHOGONAL
			rig.cam.size = float(c[3])
			rig.cam.global_transform = Transform3D(Basis(Vector3.UP, yw), at + Basis(Vector3.UP, yw) * Vector3(0, 0, float(c[5]) if c.size() > 5 else 20.0))
			rig.cam.far = 60.0
		elif s.begins_with("follow:"):
			var c := s.substr(7).split(":")
			focus_on(get(c[0]), c[1])
		elif s.begins_with("joy:"):
			var c := s.substr(4).split(";")
			hud.flight.joy = Vector2(float(c[0]), float(c[1]))
			hud.flight.climb = float(c[2]) if c.size() > 2 else 0.0
		elif s.begins_with("ridecam:"):
			var c := s.substr(8).split(";")
			_dbg_cam = Vector3(float(c[0]), float(c[1]), float(c[2]))
		elif s.begins_with("girlpos:"):
			var c := s.substr(8).split(";")
			girl.stop()
			girl.position = Vector3(float(c[0]), 0, float(c[1]))
			girl.rotation.y = deg_to_rad(float(c[2]))
		elif s.begins_with("nightstep:"):
			Game.state["night"] = {"day": Game.night_owner_day(), "step": int(s.substr(10)), "progress": 0}
		elif s == "tapgp":
			_tap_object("grandpa")
		elif s == "gp":
			print("GP ", grandpa.global_position, " lying=", grandpa.lying, " doing=", grandpa.doing, " cur=", grandpa.current, " vis=", grandpa.is_visible_in_tree(), " home=", grandpa.at_home, " model_y=", grandpa.model.position.y, " anim=", grandpa.ap.current_animation)
		elif s == "pp":
			print("PUP ", puppy.global_position, " moving=", puppy.moving, " cur=", puppy.current)
		elif s == "bigmap":
			hud.open_big_map()
		elif s.begins_with("door:"):
			var c := s.substr(5).split(":")
			print("DBG door ", c[0], " exists=", world.doors.has(c[0]))
			world.set_door(c[0], c[1] == "1", 0.3)
		elif s.begins_with("tapk:"):
			_tap_object(s.substr(5))
		elif s == "dbg_girl":
			print("PROG ", Game.state["progress"], " seeds=", Game.state["seeds"])
			print("GIRL cur=", girl.current, " pos=", girl.global_position, " doing=", girl.doing, " moving=", girl.moving, " vis=", girl.visible, " mvis=", girl.model.visible, " onp=", girl.on_plane != null, " anim=", girl.ap.current_animation if girl.ap else "")
		elif s == "geese_out":
			_pond_day = int(Game.state["day"])
			geese_to_pond()
		elif s == "geese_swim":
			for g in _swimmers():
				g.pond_c = world.outer.POND
				g.global_position = world.outer.POND + Vector3(randf_range(-4, 4), 0, randf_range(-4, 4))
				g.mode = "swim"
				g._target = g._swim_point()
		elif s == "geese_back":
			geese_from_pond()
		elif s == "gdbg":
			for g in geese:
				print("DBG goose ", g.mode, " ", g.global_position)
			print("DBG pup ", puppy.global_position, " ", puppy.doing, " vis=", puppy.visible, " in_house=", puppy.in_house, " cur=", puppy.current)
		elif s.begins_with("speed:"):
			Engine.time_scale = float(s.substr(6))
		elif s == "plane_dbg":
			print("PLANE ", plane.global_position, " st=", plane.state, " rot=", plane.rotation, " pilot=", plane.pilot, " seat=", plane.pilot_seat, " tg=", plane.to_global(plane.pilot_seat), " girl=", girl.global_position if girl else Vector3.ZERO, " gpar=", girl.get_parent().name if girl else "")
		elif s == "ride":
			start_ride()
		elif s == "ride_home":
			plane.go_home()
		elif s == "land":
			plane.land_here()
		elif s == "beepctl":
			start_beep_control()
		elif s.begins_with("overview"):
			overview()
		elif s.begins_with("fly:"):
			var c := s.substr(4).split(";")
			beep.fly_to(Vector3(float(c[0]), 0, float(c[1])))
		elif s.begins_with("quest:"):
			Game.state["quest"] = int(s.substr(6))
			Game.state["progress"] = 0
			Game.start_quest()
		elif s.begins_with("set:"):
			var c := s.substr(4).split(":")
			Game.state[c[0]] = float(c[1])
		elif s.begins_with("track:"):
			_track = get(s.substr(6))
		elif s == "warm":
			Game.state["gecko"]["temp"] = 30.0
			Game.state["gecko"]["lamp"] = true
		elif s == "tap_beep":
			tap(rig.cam.unproject_position(beep.global_position + Vector3(0, 1.05, 0)))
		elif s == "tap_puppy":
			tap(rig.cam.unproject_position(puppy.global_position + Vector3(0, 0.25, 0)))
		elif s == "tap_grandpa":
			tap(rig.cam.unproject_position(grandpa.global_position + Vector3(0, 1.0, 0)))
		elif s == "tap_house":
			tap(rig.cam.unproject_position(world.HOUSE_POS + Vector3(0, 2.0, 0)))
		elif s.begins_with("focus_puppy"):
			rig.focus = puppy.global_position + Vector3(0, 0.3, 0)
			rig.dist = 2.4
			set_process(false)
		elif s.begins_with("focus_grandpa"):
			rig.focus = grandpa.global_position + Vector3(0, 1.0, 0)
			rig.dist = 3.5
			set_process(false)
		elif s.begins_with("focus_terr"):
			_tap_object("terrarium")
			rig.pitch = -14.0
		elif s.begins_with("portrait:"):
			hud.visible = false
			grandpa.stop()
			grandpa.set_process(false)
			grandpa.play("idle")
			grandpa.ap.speed_scale = 0.0
			set_process(false)
			var head: Vector3 = grandpa.global_position + Vector3(0, 1.36, 0)
			rig.setup(head, rad_to_deg(grandpa.rotation.y) + 18.0, -4.0, 1.5, 0.5, 5.0)
			rig.cam.fov = 30.0
			await get_tree().create_timer(0.5).timeout
			get_viewport().get_texture().get_image().save_png(s.substr(9))
			hud.visible = true
		elif s.begins_with("face:"):
			# face:хто:висота_голови:файл — портрет для діалогу
			var c := s.substr(5).split(":")
			var who: Node3D = get(c[0])
			hud.visible = false
			who.set_process(false)
			if who.has_method("play"):
				who.play("idle")
			if "ap" in who and who.ap:
				who.ap.speed_scale = 0.0
			set_process(false)
			var head: Vector3 = who.global_position + Vector3(0, float(c[1]), 0)
			rig.setup(head, rad_to_deg(who.rotation.y) + 15.0, -4.0, float(c[3]) if c.size() > 3 else 1.2, 0.3, 5.0)
			rig.cam.fov = 30.0
			await get_tree().create_timer(0.5).timeout
			get_viewport().get_texture().get_image().save_png(c[2])
			hud.visible = true
			set_process(true)
			who.set_process(true)
		elif s.begins_with("pupwalk"):
			puppy.position = Vector3(-2, 0, 0)
			puppy.rotation.y = 0.0
			puppy.walk_to(Vector3(-2, 0, 3.5))
			puppy.set_process(true)
		elif s.begins_with("camside"):
			_track = puppy
			rig.setup(puppy.global_position + Vector3(0, 0.3, 0), 90.0, -18.0, 2.6, 1.0, 9.0)
		elif s.begins_with("camfront"):
			_track = puppy
			rig.setup(puppy.global_position + Vector3(0, 0.3, 0), 0.0, -18.0, 2.6, 1.0, 9.0)
		elif s == "dbg2":
			for n in world.yard_root.get_children():
				if n.has_method("talk") or "drops" in n:
					print("NODE ", n.get_script().resource_path.get_file(), " ", n.global_position, " vis=", n.visible, " model=", n.get("model"))
		elif s == "dbg":
			var g: Node3D = terrarium.gecko
			for mi in g.find_children("*", "MeshInstance3D", true, false):
				print("GECKO mesh aabb ", (mi as MeshInstance3D).global_transform * (mi as MeshInstance3D).get_aabb())
			print("GECKO pos ", g.global_position, " terr ", terrarium.global_position)
			var tm: Node3D = terrarium.get_child(0)
			for mi in tm.find_children("*", "MeshInstance3D", true, false):
				print("TERR aabb ", (mi as MeshInstance3D).global_transform * (mi as MeshInstance3D).get_aabb())
		elif s == "fast":
			Game.state["gecko"]["temp"] = 27.98
			Game.state["gecko"]["lamp"] = true
			Game._tick(1.0)
		else:
			_on_action(s)
	print("DEMO END quest=", Game.state["quest"], " coins=", Game.state["coins"])
	get_tree().quit()

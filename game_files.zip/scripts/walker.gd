extends Node3D
class_name Walker

signal arrived
## Спільне для персонажів, що ходять землею: модель з Meshy, анімації, ходьба до точки з поворотом,
## бульбашка з текстом, зона торкання.

var model: Node3D
var ap: AnimationPlayer
var anims := {}                    # наша назва → назва анімації в моделі
var bubble: Label3D
var area: Area3D
var shadow: MeshInstance3D
var walk_speed := 0.8
var run_speed := 2.0
var turn_speed := 6.0
var target := Vector3.ZERO
var moving := false
var running := false
var bounds := Rect2(-8.5, -11.5, 17.0, 16.0)
var current := ""
var _then: Callable
var _bubble_left := 0.0
var _face_to := NAN
var pose                           # пози поверх анімації (сидіти, пити, нести) — для людей
var hand: BoneAttachment3D         # права кисть: сюди «беремо» глечик, відро, кошик
var hand_l: BoneAttachment3D       # ліва кисть
var held: Node3D
var thigh := 0.45                  # довжина стегна (щоб правильно сісти)
var _base_y := 0.0


func setup_model(id: String, height: float, map: Dictionary, loops: Array) -> bool:
	model = Models.spawn(self, id, height)
	if model == null:
		return false
	ap = Models.anim_player(model)
	for k in map:
		anims[k] = Models.find_anim(ap, map[k])
	var lp: Array = []
	for k in loops:
		lp.append(anims.get(k, ""))
	if ap:
		Models.set_loop(ap, lp)
		ap.playback_default_blend_time = 0.25
	_base_y = model.position.y
	return true


func setup_pose() -> void:
	## Для людей: модифікатор поз і «рука», в яку можна щось узяти.
	var sks := model.find_children("*", "Skeleton3D", true, false)
	if sks.is_empty():
		return
	var sk: Skeleton3D = sks[0]
	pose = preload("res://scripts/humanoid_pose.gd").new()
	pose.axis_node = self
	pose.setup(sk)
	sk.add_child(pose)
	var hb: int = pose.find(sk, "RightHand")
	if hb >= 0:
		hand = BoneAttachment3D.new()
		hand.bone_name = sk.get_bone_name(hb)
		sk.add_child(hand)
	hb = pose.find(sk, "LeftHand")
	if hb >= 0:
		hand_l = BoneAttachment3D.new()
		hand_l.bone_name = sk.get_bone_name(hb)
		sk.add_child(hand_l)
	var up: int = pose.find(sk, "LeftUpLeg")
	var kn: int = pose.find(sk, "LeftLeg")
	if up >= 0 and kn >= 0:
		var a := (sk.global_transform * sk.get_bone_global_rest(up)).origin
		var b := (sk.global_transform * sk.get_bone_global_rest(kn)).origin
		thigh = a.distance_to(b) / maxf(global_transform.basis.get_scale().x, 0.001)


func hold(obj: Node3D, offset := Vector3.ZERO, left := false, rot := Basis()) -> void:
	## Взяти річ у праву (або ліву) руку, зберігаючи її справжній розмір.
	var h := hand_l if left else hand
	if h == null or obj == null:
		return
	drop()
	if obj.get_parent():
		obj.get_parent().remove_child(obj)
	h.add_child(obj)
	var sc := h.global_transform.basis.get_scale().x
	obj.transform = Transform3D(rot.scaled(Vector3.ONE / maxf(sc, 0.0001)), offset / maxf(sc, 0.0001))
	held = obj


func drop() -> Node3D:
	var o := held
	held = null
	if o and o.get_parent():
		o.get_parent().remove_child(o)
	return o


func place_held(where: Node3D, at: Vector3) -> void:
	## Поставити річ, яку тримає, у певне місце світу.
	var o := drop()
	if o == null:
		return
	where.add_child(o)
	o.transform = Transform3D(Basis(), at)


# ---------------- «справи» (послідовності дій): кожна має свій номер; нова справа скасовує стару
var job := 0
var doing := ""


func begin_job(name: String) -> int:
	job += 1
	doing = name
	put_back_held()
	return job


func end_job(id: int) -> void:
	if id == job:
		doing = ""


func cancel_job() -> void:
	job += 1
	doing = ""
	stop()
	put_back_held()


func go(p: Vector3, run := false) -> void:
	## Для «справ»: await go(точка). Якщо справу перервали — теж повертається.
	walk_to(p, run)
	await arrived


func wait(t: float) -> void:
	await get_tree().create_timer(t).timeout


func put_back_held() -> void:
	## Якщо справу перервали з річчю в руці — річ повертається на своє місце.
	if held == null:
		return
	var o := drop()
	var home: Node = o.get_meta("home_parent", null)
	if home and is_instance_valid(home):
		home.add_child(o)
		o.transform = o.get_meta("home_tr", Transform3D())
	else:
		o.queue_free()


static func remember_home(o: Node3D) -> void:
	o.set_meta("home_parent", o.get_parent())
	o.set_meta("home_tr", o.transform)


func sit_down(on: bool, speed := 1.6) -> void:
	## Плавно сісти/встати (пози кодом; модель опускається на довжину стегна).
	if pose == null:
		return
	var from: float = pose.sit
	var to := 1.0 if on else 0.0
	var t := 0.0
	while t < 1.0:
		t = minf(1.0, t + get_process_delta_time() * speed)
		pose.sit = lerpf(from, to, t)
		await get_tree().process_frame


func setup_common(kind: String, pick_size: Vector3, bubble_h: float, shadow_r: float) -> void:
	area = Util.pick_area(kind, pick_size, Vector3(0, pick_size.y / 2.0, 0))
	add_child(area)
	bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 44)
	bubble.pixel_size = 0.0035
	bubble.position = Vector3(0, bubble_h, 0)
	add_child(bubble)
	shadow = Util.blob_shadow(shadow_r, 0.28)
	add_child(shadow)


func play(kind: String, speed := 1.0) -> void:
	if ap == null:
		return
	var n: String = anims.get(kind, "")
	if n == "" or not ap.has_animation(n):
		return
	if current == kind and ap.is_playing() and ap.current_animation == n:
		ap.speed_scale = speed
		return
	current = kind
	ap.play(n, 0.25)
	ap.speed_scale = speed


func anim_length(kind: String) -> float:
	var n: String = anims.get(kind, "")
	if ap and n != "" and ap.has_animation(n):
		return ap.get_animation(n).length
	return 1.0


func walk_to(p: Vector3, run := false, then := Callable()) -> void:
	p.y = 0.0
	p.x = clampf(p.x, bounds.position.x, bounds.end.x)
	p.z = clampf(p.z, bounds.position.y, bounds.end.y)
	target = p
	moving = true
	running = run
	_then = then
	_face_to = NAN


func stop() -> void:
	var was := moving
	moving = false
	_then = Callable()
	if was:
		arrived.emit()


func face(p: Vector3) -> void:
	var d := p - global_position
	if Vector2(d.x, d.z).length() > 0.05:
		_face_to = atan2(d.x, d.z)


func say(text: String, secs := 3.0) -> void:
	bubble.text = text
	bubble.visible = true
	_bubble_left = secs


func _physics_step(delta: float) -> void:
	## Викликати з _process нащадка.
	if pose and model and float(pose.sit) > 0.0:
		model.position.y = _base_y - thigh * float(pose.sit)
	if _bubble_left > 0.0:
		_bubble_left -= delta
		if _bubble_left <= 0.0:
			bubble.visible = false
	if moving and pose and float(pose.sit) > 0.0:
		pose.sit = maxf(0.0, float(pose.sit) - delta * 1.8)     # спершу встає, потім іде
		play("idle")
	elif moving:
		var to := target - position
		to.y = 0.0
		var d := to.length()
		var v := (run_speed if running else walk_speed) * delta
		if d > 0.02:
			var want := atan2(to.x, to.z)
			rotation.y = lerp_angle(rotation.y, want, 1.0 - exp(-delta * turn_speed))
		if d <= v:
			position = Vector3(target.x, 0, target.z)
			moving = false
			_on_arrived()
			if _then.is_valid():
				var cb := _then
				_then = Callable()
				cb.call()
			arrived.emit()
		else:
			# іде туди, куди дивиться (плавні повороти, без ковзання боком)
			var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
			var step := fwd * v * clampf(fwd.dot(to / d) * 1.3, 0.25, 1.0)
			position += step
	elif not is_nan(_face_to):
		rotation.y = lerp_angle(rotation.y, _face_to, 1.0 - exp(-delta * turn_speed))
		if abs(angle_difference(rotation.y, _face_to)) < 0.02:
			_face_to = NAN


func _on_arrived() -> void:
	pass

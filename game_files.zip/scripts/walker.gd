extends Node3D
class_name Walker
## Спільне для персонажів, що ходять землею: модель з Meshy, анімації, ходьба до точки з поворотом,
## бульбашка з текстом, зона торкання.

var model: Node3D
var ap: AnimationPlayer
var anims := {}                    # наша назва → назва анімації в моделі
var bubble: Label3D
var area: Area3D
var shadow: MeshInstance3D
var walk_speed := 0.8
var run_speed := 2.0
var turn_speed := 6.0
var target := Vector3.ZERO
var moving := false
var running := false
var bounds := Rect2(-8.5, -11.5, 17.0, 16.0)
var current := ""
var _then: Callable
var _bubble_left := 0.0
var _face_to := NAN


func setup_model(id: String, height: float, map: Dictionary, loops: Array) -> bool:
	model = Models.spawn(self, id, height)
	if model == null:
		return false
	ap = Models.anim_player(model)
	for k in map:
		anims[k] = Models.find_anim(ap, map[k])
	var lp: Array = []
	for k in loops:
		lp.append(anims.get(k, ""))
	if ap:
		Models.set_loop(ap, lp)
		ap.playback_default_blend_time = 0.25
	return true


func setup_common(kind: String, pick_size: Vector3, bubble_h: float, shadow_r: float) -> void:
	area = Util.pick_area(kind, pick_size, Vector3(0, pick_size.y / 2.0, 0))
	add_child(area)
	bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 44)
	bubble.pixel_size = 0.0035
	bubble.position = Vector3(0, bubble_h, 0)
	add_child(bubble)
	shadow = Util.blob_shadow(shadow_r, 0.28)
	add_child(shadow)


func play(kind: String, speed := 1.0) -> void:
	if ap == null:
		return
	var n: String = anims.get(kind, "")
	if n == "" or not ap.has_animation(n):
		return
	if current == kind and ap.is_playing() and ap.current_animation == n:
		ap.speed_scale = speed
		return
	current = kind
	ap.play(n, 0.25)
	ap.speed_scale = speed


func anim_length(kind: String) -> float:
	var n: String = anims.get(kind, "")
	if ap and n != "" and ap.has_animation(n):
		return ap.get_animation(n).length
	return 1.0


func walk_to(p: Vector3, run := false, then := Callable()) -> void:
	p.y = 0.0
	p.x = clampf(p.x, bounds.position.x, bounds.end.x)
	p.z = clampf(p.z, bounds.position.y, bounds.end.y)
	target = p
	moving = true
	running = run
	_then = then
	_face_to = NAN


func stop() -> void:
	moving = false
	_then = Callable()


func face(p: Vector3) -> void:
	var d := p - global_position
	if Vector2(d.x, d.z).length() > 0.05:
		_face_to = atan2(d.x, d.z)


func say(text: String, secs := 3.0) -> void:
	bubble.text = text
	bubble.visible = true
	_bubble_left = secs


func _physics_step(delta: float) -> void:
	## Викликати з _process нащадка.
	if _bubble_left > 0.0:
		_bubble_left -= delta
		if _bubble_left <= 0.0:
			bubble.visible = false
	if moving:
		var to := target - position
		to.y = 0.0
		var d := to.length()
		var v := (run_speed if running else walk_speed) * delta
		if d > 0.02:
			var want := atan2(to.x, to.z)
			rotation.y = lerp_angle(rotation.y, want, 1.0 - exp(-delta * turn_speed))
		if d <= v:
			position = Vector3(target.x, 0, target.z)
			moving = false
			_on_arrived()
			if _then.is_valid():
				var cb := _then
				_then = Callable()
				cb.call()
		else:
			# іде туди, куди дивиться (плавні повороти, без ковзання боком)
			var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
			var step := fwd * v * clampf(fwd.dot(to / d) * 1.3, 0.25, 1.0)
			position += step
	elif not is_nan(_face_to):
		rotation.y = lerp_angle(rotation.y, _face_to, 1.0 - exp(-delta * turn_speed))
		if abs(angle_difference(rotation.y, _face_to)) < 0.02:
			_face_to = NAN


func _on_arrived() -> void:
	pass

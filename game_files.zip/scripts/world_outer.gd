extends Node3D
## Відкритий світ за ворітьми: дорога, село з церквою, річка з містком, ставок з очеретом,
## пшеничне поле, вітряк на пагорбі, ліс. Дерева лісу малюються «пачками» (MultiMesh по шматках),
## далекі шматки ховаються — щоб на телефоні не гальмувало.

const VILLAGE := Vector3(0, 0, 60)
const RIVER_Z := 102.0
const RIVER_W := 8.0
const POND := Vector3(-56, 0, 18)
const POND_R := 9.0
const WHEAT := Rect2(26, 14, 44, 30)          # x, z, ширина, глибина
const MILL_HILL := Vector3(-82, 0, -50)
const MILL_HILL_R := 22.0
const MILL_HILL_H := 6.5
const LIMIT := 230.0
const DRAGON_HOME := Vector3(-40, 0, -2)                           # далі — пагорби й туман

var world
var mill_blades: Node3D
var _water_mats: Array = []
var _obst: Array = []                          # [x, z, r, h]
var places := []                               # [назва, центр, радіус] — для назви місця й мапи
var houses: Array = []                         # для мапи: [x, z]
var trees: Array = []                          # для мапи: [x, z]
var _t := 0.0


func build(w) -> void:
	world = w
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	_make_village(rng)
	_make_church(VILLAGE + Vector3(0, 0, 20))
	_make_river()
	_make_pond(rng)
	_make_wheat(rng)
	_make_mill()
	_make_forest(rng)
	_make_meadow(rng)
	places = [
		["Подвір'я", Vector3(-6, 0, -5), 16.0],
		["Город", Vector3(14.5, 0, -4.5), 6.0],
		["Село", VILLAGE, 30.0],
		["Річка", Vector3(0, 0, RIVER_Z), 0.0],
		["Ставок", POND, 16.0],
		["Пшеничне поле", Vector3(WHEAT.get_center().x, 0, WHEAT.get_center().y), 24.0],
		["Вітряк", MILL_HILL, 28.0],
		["Галявина дракона", DRAGON_HOME, 11.0],
		["Ліс", Vector3(80, 0, -20), 0.0],
	]


func register_obstacles() -> void:
	for o in _obst:
		Obstacles.add_outer(o[0], o[1], o[2], o[3])


func place_name(p: Vector3) -> String:
	## Як називається місце, де зараз Beep.
	if p.x > -21.5 and p.x < 9.5 and p.z > -15.5 and p.z < 5.5:
		return "Подвір'я"
	if absf(p.z - RIVER_Z) < RIVER_W:
		return "Річка"
	if p.x > 70.0 or p.z > 115.0 or (p.x > 25.0 and p.z < 10.0):
		return "Ліс"
	var best := "Луки"
	var bd := INF
	for pl in places:
		var r: float = pl[2]
		if r <= 0.0:
			continue
		var d := Vector2(p.x - pl[1].x, p.z - pl[1].z).length()
		if d < r and d < bd:
			bd = d
			best = pl[0]
	return best


func _process(delta: float) -> void:
	_t += delta
	if mill_blades:
		mill_blades.rotate_object_local(Vector3.FORWARD, delta * 0.6)


# ------------------------------------------------------------------ село
func _make_village(rng: RandomNumberGenerator) -> void:
	var spots := [
		["hata", 4.4, VILLAGE + Vector3(-17, 0, -8), 90.0],
		["kid_house", 4.4, VILLAGE + Vector3(19, 0, -10), -90.0],
		["hata", 4.4, VILLAGE + Vector3(18, 0, 9), -90.0],
		["kid_house", 4.4, VILLAGE + Vector3(-19, 0, 10), 90.0],
		["hata", 4.4, VILLAGE + Vector3(-8, 0, -22), 0.0],
	]
	for sp in spots:
		var h := Models.spawn(self, sp[0], sp[1])
		if h == null:
			continue
		h.position = sp[2]
		h.rotation.y = deg_to_rad(sp[3])
		var hp: Vector3 = sp[2]
		_obst.append([hp.x, hp.z, 4.2, 4.0])
		houses.append([hp.x, hp.z])
		# тин перед хатою
		_low_fence(hp + Basis(Vector3.UP, deg_to_rad(sp[3])) * Vector3(-4.5, 0, 4.5), hp + Basis(Vector3.UP, deg_to_rad(sp[3])) * Vector3(4.5, 0, 4.5))
	# криниця посеред села, лавки, соняшники біля хат
	var wl := Models.spawn(self, "well", 2.3)
	if wl:
		wl.position = VILLAGE + Vector3(5, 0, 2)
		wl.rotation.y = 0.5
		_obst.append([wl.position.x, wl.position.z, 1.0, 2.3])
	for k in 3:
		var b := Models.spawn(self, "bench", 0.9)
		if b:
			var a := k * TAU / 3.0 + 0.4
			b.position = VILLAGE + Vector3(cos(a) * 7.0, 0, sin(a) * 7.0)
			b.rotation.y = -a
	for k in 10:
		var sf := Models.spawn(self, "sunflower", rng.randf_range(1.6, 2.0))
		if sf:
			var hp2: Array = spots[k % spots.size()]
			sf.position = (hp2[2] as Vector3) + Basis(Vector3.UP, deg_to_rad(hp2[3])) * Vector3(rng.randf_range(-4.0, 4.0), 0, 5.3)
			sf.rotation.y = rng.randf() * TAU


func _low_fence(a: Vector3, b: Vector3) -> void:
	var post := Util.mat(Color(0.45, 0.32, 0.2), 0.9)
	var weave := Util.mat(Color(0.62, 0.47, 0.3), 0.95)
	var n := int(ceil(a.distance_to(b) / 1.2))
	for i in n + 1:
		var p := a.lerp(b, float(i) / n)
		add_child(Util.cyl(0.04, 0.05, 1.0, post, Vector3(p.x, 0.5, p.z)))
	var mid := (a + b) / 2.0
	var ang := atan2(b.x - a.x, b.z - a.z)
	for k in 4:
		var bar := Util.box(Vector3(0.06, 0.1, a.distance_to(b)), weave, Vector3(mid.x, 0.2 + k * 0.18, mid.z))
		bar.rotation.y = ang
		add_child(bar)


func _make_church(p: Vector3) -> void:
	## Біла дерев'яна церковка з блакитною банею — видно здалеку.
	var n := Node3D.new()
	n.position = p
	add_child(n)
	var white := Util.mat(Color(0.96, 0.95, 0.9), 0.85)
	var blue := Util.mat(Color(0.3, 0.55, 0.9), 0.4)
	var gold := Util.mat(Color(0.95, 0.75, 0.25), 0.3, 0.7)
	var wood := Util.mat(Color(0.5, 0.33, 0.2), 0.9)
	n.add_child(Util.box(Vector3(6.0, 4.5, 8.0), white, Vector3(0, 2.25, 0)))
	n.add_child(Util.mesh(PrismMesh.new(), blue, Vector3(0, 5.3, 0), Vector3.ZERO, Vector3(6.6, 1.6, 8.6)))
	n.add_child(Util.box(Vector3(3.0, 3.0, 3.0), white, Vector3(0, 6.5, 0)))
	n.add_child(Util.cyl(1.3, 1.3, 1.2, white, Vector3(0, 8.6, 0)))
	n.add_child(Util.sphere(1.5, blue, Vector3(0, 9.9, 0), Vector3(1, 1.25, 1)))
	n.add_child(Util.cyl(0.05, 0.15, 1.2, gold, Vector3(0, 11.9, 0)))
	n.add_child(Util.box(Vector3(0.08, 1.0, 0.08), gold, Vector3(0, 12.9, 0)))
	n.add_child(Util.box(Vector3(0.6, 0.08, 0.08), gold, Vector3(0, 13.1, 0)))
	n.add_child(Util.box(Vector3(1.4, 2.4, 0.1), wood, Vector3(0, 1.2, -4.03)))
	for wx in [-1.8, 1.8]:
		n.add_child(Util.box(Vector3(0.8, 1.3, 0.1), blue, Vector3(wx, 2.6, -4.03)))
	_obst.append([p.x, p.z, 5.0, 12.0])
	houses.append([p.x, p.z])


# ------------------------------------------------------------------ вода
func _water_mat() -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
render_mode specular_schlick_ggx;
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	float r = sin(wp.x * 1.3 + TIME * 1.5) * 0.5 + sin(wp.z * 1.7 - TIME * 1.1 + wp.x * 0.4) * 0.5;
	ALBEDO = mix(vec3(0.18, 0.42, 0.62), vec3(0.32, 0.6, 0.78), r * 0.25 + 0.4);
	ROUGHNESS = 0.08;
	METALLIC = 0.0;
	SPECULAR = 0.7;
	NORMAL_MAP = vec3(0.5 + r * 0.05, 0.5 + r * 0.04, 1.0);
}
"""
	var m := ShaderMaterial.new()
	m.shader = sh
	return m


func _make_river() -> void:
	var water := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(LIMIT * 2.4, RIVER_W)
	pm.subdivide_width = 40
	water.mesh = pm
	water.material_override = _water_mat()
	water.position = Vector3(0, 0.04, RIVER_Z)
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(water)
	# дерев'яний місток на дорозі
	var plank: Material = world._planks_mat(Color(0.55, 0.4, 0.26), true)
	var post := Util.mat(Color(0.4, 0.28, 0.18), 0.9)
	var br := Util.box(Vector3(3.4, 0.16, RIVER_W + 4.0), plank, Vector3(0, 0.35, RIVER_Z))
	add_child(br)
	for side in [-1.0, 1.0]:
		add_child(Util.box(Vector3(0.1, 0.08, RIVER_W + 4.0), post, Vector3(side * 1.6, 1.15, RIVER_Z)))
		for k in 7:
			var z := RIVER_Z - (RIVER_W + 4.0) / 2.0 + k * (RIVER_W + 4.0) / 6.0
			add_child(Util.cyl(0.07, 0.08, 1.2, post, Vector3(side * 1.6, 0.6, z)))
	# очерет уздовж берегів
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var pts: Array = []
	for i in 260:
		var x := rng.randf_range(-LIMIT, LIMIT)
		if absf(x) < 4.0:
			continue
		var z := RIVER_Z + (RIVER_W / 2.0 + rng.randf_range(-0.3, 0.8)) * (1.0 if rng.randf() < 0.5 else -1.0)
		pts.append(Vector3(x, 0, z))
	_reeds(pts, rng)


func _make_pond(rng: RandomNumberGenerator) -> void:
	var water := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = POND_R
	cm.bottom_radius = POND_R
	cm.height = 0.02
	cm.radial_segments = 40
	water.mesh = cm
	water.material_override = _water_mat()
	water.position = POND + Vector3(0, 0.04, 0)
	add_child(water)
	var pts: Array = []
	for i in 140:
		var a := rng.randf() * TAU
		if a > 0.3 and a < 0.9:
			continue          # тут місток-причал
		var r := POND_R + rng.randf_range(-0.6, 0.5)
		pts.append(POND + Vector3(cos(a) * r, 0, sin(a) * r))
	_reeds(pts, rng)
	# причал
	var plank: Material = world._planks_mat(Color(0.55, 0.4, 0.26), true)
	var a2 := 0.6
	var dir := Vector3(cos(a2), 0, sin(a2))
	var pier := Util.box(Vector3(1.4, 0.12, 4.0), plank, POND + dir * (POND_R - 1.2) + Vector3(0, 0.3, 0))
	pier.rotation.y = atan2(dir.x, dir.z)
	add_child(pier)
	_obst.append([POND.x, POND.z, POND_R - 0.5, 0.1])


func _reeds(pts: Array, rng: RandomNumberGenerator) -> void:
	## Очерет: тонкі зелені стебла з коричневими «качалками» — одним MultiMesh.
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for k in 5:
		var a := float(k) / 5.0 * TAU
		var off := Vector3(cos(a), 0, sin(a)) * 0.12
		var hgt := 1.1 + 0.25 * sin(k * 2.3)
		var side := Vector3(-sin(a), 0, cos(a)) * 0.02
		st.set_color(Color(0.25, 0.42, 0.15))
		st.add_vertex(off - side)
		st.add_vertex(off + side)
		st.set_color(Color(0.5, 0.62, 0.25))
		st.add_vertex(off + Vector3(0, hgt, 0) + off * 0.3)
		if k % 2 == 0:
			var top := off + Vector3(0, hgt * 0.8, 0) + off * 0.25
			st.set_color(Color(0.4, 0.25, 0.12))
			st.add_vertex(top - side * 1.8)
			st.add_vertex(top + side * 1.8)
			st.add_vertex(top + Vector3(0, 0.2, 0))
	st.generate_normals()
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = st.commit()
	mm.instance_count = pts.size()
	for i in pts.size():
		mm.set_instance_transform(i, Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.8, 1.3)), pts[i]))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = world.grass.material_override
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


# ------------------------------------------------------------------ поле пшениці
func _make_wheat(rng: RandomNumberGenerator) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for k in 6:
		var a := float(k) / 6.0 * TAU
		var off := Vector3(cos(a), 0, sin(a)) * 0.08
		var side := Vector3(-sin(a), 0, cos(a)) * 0.018
		var h := 0.95 + 0.15 * sin(k * 1.7)
		st.set_color(Color(0.7, 0.58, 0.25))
		st.add_vertex(off - side)
		st.add_vertex(off + side)
		st.set_color(Color(0.95, 0.82, 0.4))
		st.add_vertex(off + Vector3(0, h, 0))
		# колосок
		var top := off + Vector3(0, h - 0.18, 0)
		st.set_color(Color(0.92, 0.75, 0.3))
		st.add_vertex(top - side * 2.5)
		st.add_vertex(top + side * 2.5)
		st.add_vertex(top + Vector3(0, 0.26, 0))
	st.generate_normals()
	var pts: Array = []
	for i in 5200:
		pts.append(Vector3(WHEAT.position.x + rng.randf() * WHEAT.size.x, 0, WHEAT.position.y + rng.randf() * WHEAT.size.y))
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = st.commit()
	mm.instance_count = pts.size()
	for i in pts.size():
		mm.set_instance_transform(i, Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.8, 1.2)), pts[i]))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = world.grass.material_override
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	# копички й опудало
	for k in 4:
		var hs := Models.spawn(self, "haystack", rng.randf_range(1.3, 1.7))
		if hs:
			hs.position = Vector3(WHEAT.position.x + 6 + k * 10.0, 0, WHEAT.end.y + 3.0)
			_obst.append([hs.position.x, hs.position.z, 1.1, 1.5])
	var sc := Models.spawn(self, "scarecrow", 1.9)
	if sc:
		sc.position = Vector3(WHEAT.get_center().x, 0, WHEAT.get_center().y)


# ------------------------------------------------------------------ вітряк на пагорбі
func _make_mill() -> void:
	var hill := Util.sphere(1.0, Util.mat(Color(0.45, 0.6, 0.28), 1.0), MILL_HILL + Vector3(0, -MILL_HILL_H * 0.6, 0),
		Vector3(MILL_HILL_R, MILL_HILL_H * 1.6, MILL_HILL_R))
	hill.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(hill)
	var top := MILL_HILL + Vector3(0, MILL_HILL_H - 0.3, 0)
	var wood: Material = world._planks_mat(Color(0.6, 0.42, 0.26))
	var roof: Material = world._planks_mat(Color(0.45, 0.3, 0.2), true)
	var m := Node3D.new()
	m.position = top
	add_child(m)
	m.add_child(Util.cyl(1.6, 2.4, 6.0, wood, Vector3(0, 3.0, 0)))
	var cap := Util.mesh(PrismMesh.new(), roof, Vector3(0, 6.9, 0), Vector3.ZERO, Vector3(3.6, 1.8, 4.2))
	m.add_child(cap)
	m.add_child(Util.box(Vector3(1.0, 1.7, 0.1), Util.mat(Color(0.35, 0.22, 0.14), 0.9), Vector3(0, 0.85, 2.3)))
	# крила
	mill_blades = Node3D.new()
	mill_blades.position = Vector3(0, 5.8, 2.6)
	m.add_child(mill_blades)
	mill_blades.add_child(Util.cyl(0.25, 0.25, 0.5, Util.mat(Color(0.3, 0.2, 0.12), 0.8), Vector3.ZERO, Vector3(90, 0, 0)))
	var sail := Util.mat(Color(0.92, 0.88, 0.78), 0.9)
	for k in 4:
		var arm := Node3D.new()
		arm.rotation.z = k * PI / 2.0
		mill_blades.add_child(arm)
		arm.add_child(Util.box(Vector3(0.18, 5.5, 0.12), Util.mat(Color(0.4, 0.28, 0.18), 0.9), Vector3(0, 2.8, 0.1)))
		arm.add_child(Util.box(Vector3(1.1, 4.2, 0.04), sail, Vector3(0.6, 3.2, 0.16)))
	_obst.append([MILL_HILL.x, MILL_HILL.z, MILL_HILL_R - 2.0, MILL_HILL_H])


# ------------------------------------------------------------------ луки: трава й квіти за тином
func _on_road(p: Vector3) -> bool:
	var q := Vector2(p.x, p.z)
	var segs := [[Vector2(0, 5), Vector2(0, 150)], [Vector2(0, 30), Vector2(-46, 22)], [Vector2(-46, 22), Vector2(-72, -30)], [Vector2(0, 36), Vector2(26, 32)], [Vector2(0, 9), Vector2(-14, 12.5)]]
	for sg in segs:
		var a: Vector2 = sg[0]
		var b: Vector2 = sg[1]
		var ba := b - a
		var t := clampf((q - a).dot(ba) / ba.dot(ba), 0.0, 1.0)
		if q.distance_to(a + ba * t) < 1.6:
			return true
	return q.distance_to(Vector2(VILLAGE.x, VILLAGE.z)) < 10.0


func _make_meadow(rng: RandomNumberGenerator) -> void:
	## Пучки трави й квіти по луках — шматками, далекі не малюються.
	var chunk := 50.0
	var buckets := {}
	var tries := 0
	var n := 0
	while n < 7000 and tries < 20000:
		tries += 1
		var p := Vector3(rng.randf_range(-170, 170), 0, rng.randf_range(-150, 200))
		if p.length() > LIMIT:
			continue
		if p.x > -22.0 and p.x < 10.0 and p.z > -16.0 and p.z < 6.0:
			continue
		if _on_road(p) or absf(p.z - RIVER_Z) < RIVER_W / 2.0 + 0.5:
			continue
		if Vector2(p.x - POND.x, p.z - POND.z).length() < POND_R + 0.5:
			continue
		if p.x > WHEAT.position.x and p.x < WHEAT.end.x and p.z > WHEAT.position.y and p.z < WHEAT.end.y:
			continue
		var key := Vector2i(floori(p.x / chunk), floori(p.z / chunk))
		if not buckets.has(key):
			buckets[key] = []
		buckets[key].append(p)
		n += 1
	var gmesh: Mesh = world.grass.multimesh.mesh
	for key in buckets:
		var list: Array = buckets[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = gmesh
		mm.instance_count = list.size()
		for i in list.size():
			mm.set_instance_transform(i, Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.8, 1.6)), list[i]))
		var mi := MultiMeshInstance3D.new()
		mi.multimesh = mm
		mi.material_override = world.grass.material_override
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.visibility_range_end = 110.0
		add_child(mi)


# ------------------------------------------------------------------ ліс (MultiMesh по шматках)
func _ok_tree(p: Vector3) -> bool:
	if p.x > -26.0 and p.x < 22.0 and p.z > -20.0 and p.z < 9.0:
		return false                           # подвір'я й город
	if absf(p.x) < 7.0 and p.z > 5.0:
		return false                           # дорога на південь
	if Vector2(p.x - VILLAGE.x, p.z - VILLAGE.z).length() < 34.0:
		return false
	if absf(p.z - RIVER_Z) < RIVER_W:
		return false
	if Vector2(p.x - POND.x, p.z - POND.z).length() < POND_R + 5.0:
		return false
	if p.x > WHEAT.position.x - 4 and p.x < WHEAT.end.x + 4 and p.z > WHEAT.position.y - 4 and p.z < WHEAT.end.y + 6:
		return false
	if Vector2(p.x - MILL_HILL.x, p.z - MILL_HILL.z).length() < MILL_HILL_R + 2.0:
		return false
	if Vector2(p.x - DRAGON_HOME.x, p.z - DRAGON_HOME.z).length() < 13.0:
		return false                           # галявина дракона
	if Vector2(p.x + 11.5, p.z - 13.0).length() < 8.0:
		return false                           # хата Тарасика
	if absf(p.x + 23.0) < 4.0 and p.z > 18.0 and p.z < 30.0:
		return false
	return true


func _make_forest(rng: RandomNumberGenerator) -> void:
	var kinds := ["birch_b_lo", "pine_lo", "birch_a_lo", "pine_lo"]
	var heights := {"birch_b_lo": [7.0, 10.0], "pine_lo": [8.0, 12.0], "birch_a_lo": [6.5, 9.0]}
	var chunk := 40.0
	var buckets := {}               # (шматок, вид) → масив [позиція, кут, висота]
	var n := 0
	var tries := 0
	while n < 700 and tries < 9000:
		tries += 1
		var p: Vector3
		var r := rng.randf()
		if r < 0.45:
			p = Vector3(rng.randf_range(30, 160), 0, rng.randf_range(-90, 70))          # ліс на сході
		elif r < 0.75:
			p = Vector3(rng.randf_range(-170, 170), 0, rng.randf_range(112, 200))       # ліс за річкою
		elif r < 0.9:
			p = Vector3(rng.randf_range(-170, -40), 0, rng.randf_range(-130, -5))       # гай на заході
		else:
			p = Vector3(rng.randf_range(-170, 170), 0, rng.randf_range(-170, -40))      # за подвір'ям
		if p.length() > LIMIT + 30.0 or not _ok_tree(p):
			continue
		var k: String = kinds[rng.randi() % kinds.size()]
		if not Models.exists(k):
			continue
		var key := "%d_%d_%s" % [floori(p.x / chunk), floori(p.z / chunk), k]
		if not buckets.has(key):
			buckets[key] = []
		var hr: Array = heights[k]
		buckets[key].append([p, rng.randf() * TAU, rng.randf_range(hr[0], hr[1])])
		trees.append([p.x, p.z])
		_obst.append([p.x, p.z, 0.5, 6.0])
		n += 1
	# зразок кожного виду: меш і як він стоїть у моделі
	var proto := {}
	for k in kinds:
		if proto.has(k) or not Models.exists(k):
			continue
		var h := Models.spawn(self, k, 1.0)
		var mi: MeshInstance3D = h.find_children("*", "MeshInstance3D", true, false)[0]
		proto[k] = [mi.mesh, h.global_transform.affine_inverse() * mi.global_transform, mi.get_active_material(0)]
		h.queue_free()
	for key in buckets:
		var ks := String(key)
		var k := ks.substr(ks.find("_", ks.find("_") + 1) + 1)
		var pr: Array = proto[k]
		var list: Array = buckets[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = pr[0]
		mm.instance_count = list.size()
		for i in list.size():
			var it: Array = list[i]
			var tr := Transform3D(Basis(Vector3.UP, float(it[1])).scaled(Vector3.ONE * float(it[2])), it[0])
			mm.set_instance_transform(i, tr * (pr[1] as Transform3D))
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = pr[2]
		mmi.visibility_range_end = 170.0
		mmi.visibility_range_end_margin = 20.0
		mmi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED
		add_child(mmi)

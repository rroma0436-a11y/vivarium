extends Node3D
## Відкритий світ за ворітьми: дорога, село з церквою, річка з містком, ставок з очеретом,
## пшеничне поле, вітряк на пагорбі, ліс. Дерева лісу малюються «пачками» (MultiMesh по шматках),
## далекі шматки ховаються — щоб на телефоні не гальмувало.

const VILLAGE := Vector3(0, 0, 60)
const RIVER_Z := 102.0
const RIVER_W := 8.0
const POND := Vector3(-62, 0, 30)
const POND_R := 13.0
const WHEAT := Rect2(26, 14, 44, 30)          # x, z, ширина, глибина
const MILL_HILL := Vector3(-82, 0, -50)
const MILL_HILL_R := 22.0
const MILL_HILL_H := 6.5
const LIMIT := 230.0
const HANGAR := Vector3(-33, 0, -2)                                # ангар літака (ворота на захід)
const RUNWAY_A := Vector3(-44, 0, -2)                              # початок злітної смуги
const RUNWAY_B := Vector3(-112, 0, -2)                             # кінець смуги
const DRAGON_HOME := HANGAR

var world
var mill_blades: Node3D
var _water_mats: Array = []
var _obst: Array = []                          # [x, z, r, h]
var places := []                               # [назва, центр, радіус] — для назви місця й мапи
var houses: Array = []                         # для мапи: [x, z]
var trees: Array = []                          # для мапи: [x, z]
var _t := 0.0


func build(w) -> void:
	world = w
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	_make_village(rng)
	_make_stalls()
	_make_church(VILLAGE + Vector3(0, 0, 20))
	_make_river()
	_make_pond(rng)
	_make_wheat(rng)
	_make_mill()
	_make_forest(rng)
	_make_meadow(rng)
	_make_airfield()
	_make_sky_birds()
	places = [
		["Подвір'я", Vector3(-6, 0, -5), 16.0],
		["Город", Vector3(14.5, 0, -4.5), 6.0],
		["Село", VILLAGE, 30.0],
		["Річка", Vector3(0, 0, RIVER_Z), 0.0],
		["Ставок", POND, 16.0],
		["Пшеничне поле", Vector3(WHEAT.get_center().x, 0, WHEAT.get_center().y), 24.0],
		["Вітряк", MILL_HILL, 28.0],
		["Аеродром", Vector3(-70, 0, -2), 0.0],
		["Ліс", Vector3(80, 0, -20), 0.0],
	]


func register_obstacles() -> void:
	for o in _obst:
		Obstacles.add_outer(o[0], o[1], o[2], o[3])


func place_name(p: Vector3) -> String:
	## Як називається місце, де зараз Beep.
	if p.x > -21.5 and p.x < 9.5 and p.z > -15.5 and p.z < 5.5:
		return "Подвір'я"
	if absf(p.z - RIVER_Z) < RIVER_W:
		return "Річка"
	if p.x > 70.0 or p.z > 115.0 or (p.x > 25.0 and p.z < 10.0):
		return "Ліс"
	if p.x < -27.0 and p.x > -118.0 and absf(p.z + 2.0) < 9.0:
		return "Аеродром"
	var best := "Луки"
	var bd := INF
	for pl in places:
		var r: float = pl[2]
		if r <= 0.0:
			continue
		var d := Vector2(p.x - pl[1].x, p.z - pl[1].z).length()
		if d < r and d < bd:
			bd = d
			best = pl[0]
	return best


func _process(delta: float) -> void:
	_t += delta
	if mill_blades:
		mill_blades.rotate_object_local(Vector3.FORWARD, delta * 0.6)
	_boat_step(delta)
	_sky_birds_step(delta)


# ------------------------------------------------------------------ село
const MARKET_POS := Vector3(-14, 0, 59)      # фентезі-ринок (захід площі)
const MANSION_POS := Vector3(16.5, 0, 57)     # кам'яний особняк (схід)
const TEA_POS := Vector3(9.5, 0, 70.5)        # чайна «Tea Kadai» (південний схід)


func _make_village(rng: RandomNumberGenerator) -> void:
	var spots := [
		["hata", 4.4, VILLAGE + Vector3(-25, 0, -13), 90.0],
		["kid_house", 4.4, VILLAGE + Vector3(26, 0, -15), -90.0],
		["hata", 4.4, VILLAGE + Vector3(27, 0, 15), -90.0],
		["kid_house", 4.4, VILLAGE + Vector3(-26, 0, 15), 90.0],
		["hata", 4.4, VILLAGE + Vector3(-9, 0, -27), 0.0],
	]
	for sp in spots:
		var h := Models.spawn(self, sp[0], sp[1])
		if h == null:
			continue
		h.position = sp[2]
		h.rotation.y = deg_to_rad(sp[3])
		var di := spots.find(sp)
		if sp[0] == "hata":
			world.make_house_door(h, AABB(Vector3(-0.33, 0.22, 0.9), Vector3(0.93, 1.66, 1.4)), "v_door_%d" % di)
		else:
			var k: float = float(sp[1]) / 4.6
			world.make_house_door(h, AABB(Vector3(-4.6, 0.12, 2.8) * k, Vector3(0.95, 2.3, 2.7) * k), "v_door_%d" % di)
		var hp: Vector3 = sp[2]
		_obst.append([hp.x, hp.z, 4.2, 4.0])
		houses.append([hp.x, hp.z])
		# тин довкола садиби, хвіртка спереду посередині
		var bs := Basis(Vector3.UP, deg_to_rad(sp[3]))
		var hx := 5.8 if sp[0] == "hata" else 9.6
		var zf := 6.3 if sp[0] == "hata" else 7.4
		var zb := -5.2 if sp[0] == "hata" else -6.6
		var pts := [[Vector3(-1.1, 0, zf), Vector3(-hx, 0, zf)], [Vector3(-hx, 0, zf), Vector3(-hx, 0, zb)],
			[Vector3(-hx, 0, zb), Vector3(hx, 0, zb)], [Vector3(hx, 0, zb), Vector3(hx, 0, zf)],
			[Vector3(hx, 0, zf), Vector3(1.1, 0, zf)]]
		for seg in pts:
			_low_fence(hp + bs * (seg[0] as Vector3), hp + bs * (seg[1] as Vector3))
	_make_farm_buildings()
	# площа: посередині фонтан, довкола — ринок, особняк і чайна, усі дивляться на фонтан
	_make_fountain(VILLAGE)
	for b in [["market", 4.6, MARKET_POS, 5.2], ["mansion", 9.0, MANSION_POS, 5.4], ["tea_stall", 3.6, TEA_POS, 2.3]]:
		var m := Models.spawn(self, b[0], b[1])
		if m == null:
			continue
		m.position = b[2]
		var to: Vector3 = VILLAGE - (b[2] as Vector3)
		m.rotation.y = atan2(to.x, to.z) + float(SQUARE_FRONT.get(b[0], 0.0))
		_obst.append([m.position.x, m.position.z, b[3], 3.0])
		houses.append([m.position.x, m.position.z])
	# криниця трохи осторонь, лавки довкола фонтану — сидінням до фонтану
	var wl := Models.spawn(self, "well", 2.3)
	if wl:
		wl.position = VILLAGE + Vector3(-8, 0, -13)
		wl.rotation.y = 0.5
		_obst.append([wl.position.x, wl.position.z, 1.0, 2.3])
	for k in 4:
		var b2 := Models.spawn(self, "bench", 0.9)
		if b2:
			var a := PI / 4.0 + k * PI / 2.0
			b2.position = VILLAGE + Vector3(cos(a) * 5.6, 0, sin(a) * 5.6)
			var to2: Vector3 = VILLAGE - b2.position
			b2.rotation.y = atan2(to2.x, to2.z) + BENCH_FRONT
	for k in 10:
		var sf := Models.spawn(self, "sunflower", rng.randf_range(1.6, 2.0))
		if sf:
			var hp2: Array = spots[k % spots.size()]
			sf.position = (hp2[2] as Vector3) + Basis(Vector3.UP, deg_to_rad(hp2[3])) * Vector3(rng.randf_range(-4.0, 4.0), 0, 5.3)
			sf.rotation.y = rng.randf() * TAU


# у який бік «дивиться» модель (поправка до повороту, щоб фасад був до фонтану)
const SQUARE_FRONT := {"market": 0.0, "mansion": 0.0, "tea_stall": 0.0}
const BENCH_FRONT := -PI / 2.0


const STABLE_POS := Vector3(-8.0, 0, -25.5)
const COWSHED_POS := Vector3(7.0, 0, -25.5)


func _make_farm_buildings() -> void:
	## Стайня й корівник — за двором, на північ, фасадом до хати.
	for b in [["stable", 5.0, STABLE_POS, -PI / 2.0], ["cowshed", 5.0, COWSHED_POS, 0.0]]:
		var m := Models.spawn(self, b[0], b[1])
		if m == null:
			continue
		m.position = b[2]
		m.rotation.y = b[3]
		_obst.append([m.position.x, m.position.z, 4.6, 3.0])
		houses.append([m.position.x, m.position.z])
		m.add_child(Util.pick_area("barn", Vector3(8.0, 5.0, 7.0), Vector3(0, 2.5, 0)))


func _make_fountain(p: Vector3) -> void:
	## Кам'яний фонтан: широка чаша, колона з верхньою чашею, струмені води.
	var n := Node3D.new()
	n.position = p
	add_child(n)
	var stone := Util.mat(Color(0.78, 0.76, 0.72), 0.8)
	var stone2 := Util.mat(Color(0.68, 0.66, 0.62), 0.85)
	n.add_child(Util.cyl(2.7, 2.8, 0.6, stone, Vector3(0, 0.3, 0)))
	n.add_child(Util.cyl(2.85, 2.85, 0.12, stone2, Vector3(0, 0.62, 0)))
	var water := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 2.45
	cm.bottom_radius = 2.45
	cm.height = 0.02
	cm.radial_segments = 32
	water.mesh = cm
	water.material_override = _water_mat()
	water.position = Vector3(0, 0.66, 0)
	n.add_child(water)
	n.add_child(Util.cyl(0.32, 0.42, 1.7, stone2, Vector3(0, 1.4, 0)))
	n.add_child(Util.cyl(1.05, 0.45, 0.32, stone, Vector3(0, 2.3, 0)))
	var w2 := MeshInstance3D.new()
	var cm2 := CylinderMesh.new()
	cm2.top_radius = 0.92
	cm2.bottom_radius = 0.92
	cm2.height = 0.02
	cm2.radial_segments = 24
	w2.mesh = cm2
	w2.material_override = _water_mat()
	w2.position = Vector3(0, 2.45, 0)
	n.add_child(w2)
	n.add_child(Util.cyl(0.12, 0.16, 0.7, stone2, Vector3(0, 2.75, 0)))
	n.add_child(Util.sphere(0.2, stone, Vector3(0, 3.15, 0)))
	var drop := StandardMaterial3D.new()
	drop.albedo_color = Color(0.75, 0.9, 1.0, 0.7)
	drop.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	drop.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var dm := SphereMesh.new()
	dm.radius = 0.05
	dm.height = 0.1
	dm.radial_segments = 6
	dm.rings = 3
	# струмінь угору з верхівки
	var jet := CPUParticles3D.new()
	jet.mesh = dm
	jet.material_override = drop
	jet.amount = 70
	jet.lifetime = 1.1
	jet.direction = Vector3.UP
	jet.spread = 14.0
	jet.initial_velocity_min = 2.6
	jet.initial_velocity_max = 3.0
	jet.gravity = Vector3(0, -6.5, 0)
	jet.scale_amount_min = 0.6
	jet.scale_amount_max = 1.0
	jet.position = Vector3(0, 3.3, 0)
	n.add_child(jet)
	# вода переливається з верхньої чаші вниз
	var fall := CPUParticles3D.new()
	fall.mesh = dm
	fall.material_override = drop
	fall.amount = 90
	fall.lifetime = 0.8
	fall.emission_shape = CPUParticles3D.EMISSION_SHAPE_RING
	fall.emission_ring_axis = Vector3.UP
	fall.emission_ring_radius = 1.0
	fall.emission_ring_inner_radius = 0.95
	fall.emission_ring_height = 0.01
	fall.direction = Vector3.DOWN
	fall.spread = 6.0
	fall.initial_velocity_min = 0.3
	fall.initial_velocity_max = 0.5
	fall.gravity = Vector3(0, -6.0, 0)
	fall.scale_amount_min = 0.5
	fall.scale_amount_max = 0.8
	fall.position = Vector3(0, 2.42, 0)
	n.add_child(fall)
	fountain_jets = [jet, fall]
	n.add_child(Util.pick_area("fountain", Vector3(5.6, 3.2, 5.6), Vector3(0, 1.6, 0)))
	_obst.append([p.x, p.z, 3.0, 1.0])


var _fence_post: Material
var _fence_weave: Material


func _low_fence(a: Vector3, b: Vector3) -> void:
	if _fence_post == null:
		_fence_post = Util.mat(Color(0.45, 0.32, 0.2), 0.9)
		_fence_weave = Util.mat(Color(0.62, 0.47, 0.3), 0.95)
	var post := _fence_post
	var weave := _fence_weave
	var n := int(ceil(a.distance_to(b) / 1.2))
	for i in n + 1:
		var p := a.lerp(b, float(i) / n)
		add_child(Util.cyl(0.04, 0.05, 1.0, post, Vector3(p.x, 0.5, p.z)))
	var mid := (a + b) / 2.0
	var ang := atan2(b.x - a.x, b.z - a.z)
	for k in 4:
		var bar := Util.box(Vector3(0.06, 0.1, a.distance_to(b)), weave, Vector3(mid.x, 0.2 + k * 0.18, mid.z))
		bar.rotation.y = ang
		add_child(bar)


func _make_church(p: Vector3) -> void:
	## Біла дерев'яна церковка з блакитною банею — видно здалеку.
	var n := Node3D.new()
	n.position = p
	add_child(n)
	var white := Util.mat(Color(0.96, 0.95, 0.9), 0.85)
	var blue := Util.mat(Color(0.3, 0.55, 0.9), 0.4)
	var gold := Util.mat(Color(0.95, 0.75, 0.25), 0.3, 0.7)
	var wood := Util.mat(Color(0.5, 0.33, 0.2), 0.9)
	n.add_child(Util.box(Vector3(6.0, 4.5, 8.0), white, Vector3(0, 2.25, 0)))
	n.add_child(Util.mesh(PrismMesh.new(), blue, Vector3(0, 5.3, 0), Vector3.ZERO, Vector3(6.6, 1.6, 8.6)))
	n.add_child(Util.box(Vector3(3.0, 3.0, 3.0), white, Vector3(0, 6.5, 0)))
	n.add_child(Util.cyl(1.3, 1.3, 1.2, white, Vector3(0, 8.6, 0)))
	n.add_child(Util.sphere(1.5, blue, Vector3(0, 9.9, 0), Vector3(1, 1.25, 1)))
	n.add_child(Util.cyl(0.05, 0.15, 1.2, gold, Vector3(0, 11.9, 0)))
	n.add_child(Util.box(Vector3(0.08, 1.0, 0.08), gold, Vector3(0, 12.9, 0)))
	n.add_child(Util.box(Vector3(0.6, 0.08, 0.08), gold, Vector3(0, 13.1, 0)))
	n.add_child(Util.box(Vector3(1.4, 2.4, 0.1), wood, Vector3(0, 1.2, -4.03)))
	for wx in [-1.8, 1.8]:
		n.add_child(Util.box(Vector3(0.8, 1.3, 0.1), blue, Vector3(wx, 2.6, -4.03)))
	_obst.append([p.x, p.z, 5.0, 12.0])
	houses.append([p.x, p.z])


# ------------------------------------------------------------------ вода
func _water_mat() -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
render_mode specular_schlick_ggx;
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	float r = sin(wp.x * 1.3 + TIME * 1.5) * 0.5 + sin(wp.z * 1.7 - TIME * 1.1 + wp.x * 0.4) * 0.5;
	ALBEDO = mix(vec3(0.18, 0.42, 0.62), vec3(0.32, 0.6, 0.78), r * 0.25 + 0.4);
	ROUGHNESS = 0.08;
	METALLIC = 0.0;
	SPECULAR = 0.7;
	NORMAL_MAP = vec3(0.5 + r * 0.05, 0.5 + r * 0.04, 1.0);
}
"""
	var m := ShaderMaterial.new()
	m.shader = sh
	return m


func _make_river() -> void:
	var water := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(LIMIT * 2.4, RIVER_W)
	pm.subdivide_width = 40
	water.mesh = pm
	water.material_override = _water_mat()
	water.position = Vector3(0, 0.04, RIVER_Z)
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(water)
	# дерев'яний місток на дорозі
	var plank: Material = world._planks_mat(Color(0.55, 0.4, 0.26), true)
	var post := Util.mat(Color(0.4, 0.28, 0.18), 0.9)
	var br := Util.box(Vector3(3.4, 0.16, RIVER_W + 4.0), plank, Vector3(0, 0.35, RIVER_Z))
	add_child(br)
	for side in [-1.0, 1.0]:
		add_child(Util.box(Vector3(0.1, 0.08, RIVER_W + 4.0), post, Vector3(side * 1.6, 1.15, RIVER_Z)))
		for k in 7:
			var z := RIVER_Z - (RIVER_W + 4.0) / 2.0 + k * (RIVER_W + 4.0) / 6.0
			add_child(Util.cyl(0.07, 0.08, 1.2, post, Vector3(side * 1.6, 0.6, z)))
	# очерет уздовж берегів
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var pts: Array = []
	for i in 260:
		var x := rng.randf_range(-LIMIT, LIMIT)
		if absf(x) < 4.0:
			continue
		var z := RIVER_Z + (RIVER_W / 2.0 + rng.randf_range(-0.3, 0.8)) * (1.0 if rng.randf() < 0.5 else -1.0)
		pts.append(Vector3(x, 0, z))
	_reeds(pts, rng)


func _make_pond(rng: RandomNumberGenerator) -> void:
	var water := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = POND_R
	cm.bottom_radius = POND_R
	cm.height = 0.02
	cm.radial_segments = 40
	water.mesh = cm
	water.material_override = _water_mat()
	water.position = POND + Vector3(0, 0.04, 0)
	add_child(water)
	var pts: Array = []
	for i in 140:
		var a := rng.randf() * TAU
		if a > 0.3 and a < 0.9:
			continue          # тут місток-причал
		if a > TAU - 0.55 or a < 0.18:
			continue          # тут гуси заходять у воду
		var r := POND_R + rng.randf_range(-0.6, 0.5)
		pts.append(POND + Vector3(cos(a) * r, 0, sin(a) * r))
	_reeds(pts, rng)
	# причал і човен
	var a2 := 0.6
	var dir := Vector3(cos(a2), 0, sin(a2))
	var pm := Models.spawn(self, "pier", 4.6, "x") if Models.exists("pier") else null
	if pm:
		# модель лежить уздовж x — повертаємо так, щоб причал ішов від берега у воду
		pm.position = POND + dir * (POND_R - 1.0) + Vector3(0, -0.35, 0)
		pm.rotation.y = atan2(dir.x, dir.z) + PI / 2.0
	else:
		var plank: Material = world._planks_mat(Color(0.55, 0.4, 0.26), true)
		var pier := Util.box(Vector3(1.4, 0.12, 4.0), plank, POND + dir * (POND_R - 1.2) + Vector3(0, 0.3, 0))
		pier.rotation.y = atan2(dir.x, dir.z)
		add_child(pier)
	boat = Models.spawn(self, "boat", 3.4, "x") if Models.exists("boat") else null
	if boat:
		var side := Vector3(-dir.z, 0, dir.x)
		boat.position = POND + dir * (POND_R - 3.0) + side * 2.6 + Vector3(0, -0.12, 0)
		boat.rotation.y = atan2(dir.x, dir.z) + PI / 2.0 + 0.25
		_boat_y = boat.position.y
		_boat_rot = boat.rotation.y
	_obst.append([POND.x, POND.z, POND_R - 0.5, 0.1])


var boat: Node3D
var _boat_y := 0.0
var _boat_rot := 0.0
var _bt := 0.0
var fountain_jets: Array = []


func _boat_step(delta: float) -> void:
	_bt += delta
	if boat:
		# човен гойдається на воді
		boat.position.y = _boat_y + sin(_bt * 1.3) * 0.04
		boat.rotation.z = sin(_bt * 0.9) * 0.04
		boat.rotation.y = _boat_rot + sin(_bt * 0.25) * 0.06


func _reeds(pts: Array, rng: RandomNumberGenerator) -> void:
	## Очерет: тонкі зелені стебла з коричневими «качалками» — одним MultiMesh.
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for k in 5:
		var a := float(k) / 5.0 * TAU
		var off := Vector3(cos(a), 0, sin(a)) * 0.12
		var hgt := 1.1 + 0.25 * sin(k * 2.3)
		var side := Vector3(-sin(a), 0, cos(a)) * 0.02
		st.set_color(Color(0.25, 0.42, 0.15))
		st.add_vertex(off - side)
		st.add_vertex(off + side)
		st.set_color(Color(0.5, 0.62, 0.25))
		st.add_vertex(off + Vector3(0, hgt, 0) + off * 0.3)
		if k % 2 == 0:
			var top := off + Vector3(0, hgt * 0.8, 0) + off * 0.25
			st.set_color(Color(0.4, 0.25, 0.12))
			st.add_vertex(top - side * 1.8)
			st.add_vertex(top + side * 1.8)
			st.add_vertex(top + Vector3(0, 0.2, 0))
	st.generate_normals()
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = st.commit()
	mm.instance_count = pts.size()
	for i in pts.size():
		mm.set_instance_transform(i, Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.8, 1.3)), pts[i]))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = world.grass.material_override
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


# ------------------------------------------------------------------ поле пшениці
func _make_wheat(rng: RandomNumberGenerator) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for k in 6:
		var a := float(k) / 6.0 * TAU
		var off := Vector3(cos(a), 0, sin(a)) * 0.08
		var side := Vector3(-sin(a), 0, cos(a)) * 0.018
		var h := 0.95 + 0.15 * sin(k * 1.7)
		st.set_color(Color(0.7, 0.58, 0.25))
		st.add_vertex(off - side)
		st.add_vertex(off + side)
		st.set_color(Color(0.95, 0.82, 0.4))
		st.add_vertex(off + Vector3(0, h, 0))
		# колосок
		var top := off + Vector3(0, h - 0.18, 0)
		st.set_color(Color(0.92, 0.75, 0.3))
		st.add_vertex(top - side * 2.5)
		st.add_vertex(top + side * 2.5)
		st.add_vertex(top + Vector3(0, 0.26, 0))
	st.generate_normals()
	var pts: Array = []
	for i in 5200:
		pts.append(Vector3(WHEAT.position.x + rng.randf() * WHEAT.size.x, 0, WHEAT.position.y + rng.randf() * WHEAT.size.y))
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = st.commit()
	mm.instance_count = pts.size()
	for i in pts.size():
		mm.set_instance_transform(i, Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.8, 1.2)), pts[i]))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = world.grass.material_override
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	# копички й опудало
	for k in 4:
		var hs := Models.spawn(self, "haystack", rng.randf_range(1.3, 1.7))
		if hs:
			hs.position = Vector3(WHEAT.position.x + 6 + k * 10.0, 0, WHEAT.end.y + 3.0)
			_obst.append([hs.position.x, hs.position.z, 1.1, 1.5])
	var sc := Models.spawn(self, "scarecrow", 1.9)
	if sc:
		sc.position = Vector3(WHEAT.get_center().x, 0, WHEAT.get_center().y)


# ------------------------------------------------------------------ вітряк на пагорбі
func _make_mill() -> void:
	var hill := Util.sphere(1.0, Util.mat(Color(0.45, 0.6, 0.28), 1.0), MILL_HILL + Vector3(0, -MILL_HILL_H * 0.6, 0),
		Vector3(MILL_HILL_R, MILL_HILL_H * 1.6, MILL_HILL_R))
	hill.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(hill)
	var top := MILL_HILL + Vector3(0, MILL_HILL_H - 0.3, 0)
	var wood: Material = world._planks_mat(Color(0.6, 0.42, 0.26))
	var roof: Material = world._planks_mat(Color(0.45, 0.3, 0.2), true)
	var m := Node3D.new()
	m.position = top
	add_child(m)
	m.add_child(Util.cyl(1.6, 2.4, 6.0, wood, Vector3(0, 3.0, 0)))
	var cap := Util.mesh(PrismMesh.new(), roof, Vector3(0, 6.9, 0), Vector3.ZERO, Vector3(3.6, 1.8, 4.2))
	m.add_child(cap)
	m.add_child(Util.box(Vector3(1.0, 1.7, 0.1), Util.mat(Color(0.35, 0.22, 0.14), 0.9), Vector3(0, 0.85, 2.3)))
	# крила
	mill_blades = Node3D.new()
	mill_blades.position = Vector3(0, 5.8, 2.6)
	m.add_child(mill_blades)
	mill_blades.add_child(Util.cyl(0.25, 0.25, 0.5, Util.mat(Color(0.3, 0.2, 0.12), 0.8), Vector3.ZERO, Vector3(90, 0, 0)))
	var sail := Util.mat(Color(0.92, 0.88, 0.78), 0.9)
	for k in 4:
		var arm := Node3D.new()
		arm.rotation.z = k * PI / 2.0
		mill_blades.add_child(arm)
		arm.add_child(Util.box(Vector3(0.18, 5.5, 0.12), Util.mat(Color(0.4, 0.28, 0.18), 0.9), Vector3(0, 2.8, 0.1)))
		arm.add_child(Util.box(Vector3(1.1, 4.2, 0.04), sail, Vector3(0.6, 3.2, 0.16)))
	_obst.append([MILL_HILL.x, MILL_HILL.z, MILL_HILL_R - 2.0, MILL_HILL_H])


# ------------------------------------------------------------------ луки: трава й квіти за тином
func _on_road(p: Vector3) -> bool:
	var q := Vector2(p.x, p.z)
	var segs := [[Vector2(0, 5), Vector2(0, 150)], [Vector2(0, 30), Vector2(-46, 22)], [Vector2(-46, 22), Vector2(-72, -30)], [Vector2(0, 36), Vector2(26, 32)], [Vector2(0, 9), Vector2(-14, 12.5)]]
	for sg in segs:
		var a: Vector2 = sg[0]
		var b: Vector2 = sg[1]
		var ba := b - a
		var t := clampf((q - a).dot(ba) / ba.dot(ba), 0.0, 1.0)
		if q.distance_to(a + ba * t) < 1.6:
			return true
	return q.distance_to(Vector2(VILLAGE.x, VILLAGE.z)) < 10.0


func _make_meadow(rng: RandomNumberGenerator) -> void:
	## Пучки трави й квіти по луках — шматками, далекі не малюються.
	var chunk := 50.0
	var buckets := {}
	var tries := 0
	var n := 0
	while n < 7000 and tries < 20000:
		tries += 1
		var p := Vector3(rng.randf_range(-170, 170), 0, rng.randf_range(-150, 200))
		if p.length() > LIMIT:
			continue
		if p.x > -22.0 and p.x < 10.0 and p.z > -16.0 and p.z < 6.0:
			continue
		if _on_road(p) or absf(p.z - RIVER_Z) < RIVER_W / 2.0 + 0.5:
			continue
		if p.x < -28.0 and p.x > -116.0 and absf(p.z + 2.0) < 4.0:
			continue
		if Vector2(p.x - POND.x, p.z - POND.z).length() < POND_R + 0.5:
			continue
		if p.x > WHEAT.position.x and p.x < WHEAT.end.x and p.z > WHEAT.position.y and p.z < WHEAT.end.y:
			continue
		var key := Vector2i(floori(p.x / chunk), floori(p.z / chunk))
		if not buckets.has(key):
			buckets[key] = []
		buckets[key].append(p)
		n += 1
	var gmesh: Mesh = world.grass.multimesh.mesh
	for key in buckets:
		var list: Array = buckets[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = gmesh
		mm.instance_count = list.size()
		for i in list.size():
			mm.set_instance_transform(i, Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.8, 1.6)), list[i]))
		var mi := MultiMeshInstance3D.new()
		mi.multimesh = mm
		mi.material_override = world.grass.material_override
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.visibility_range_end = 110.0
		add_child(mi)


# ------------------------------------------------------------------ ліс (MultiMesh по шматках)
func _ok_tree(p: Vector3) -> bool:
	if p.x > -26.0 and p.x < 22.0 and p.z > -20.0 and p.z < 9.0:
		return false                           # подвір'я й город
	if p.x > -20.0 and p.x < 19.0 and p.z > -34.0 and p.z <= -20.0:
		return false                           # стайня й корівник за двором
	if absf(p.x) < 7.0 and p.z > 5.0:
		return false                           # дорога на південь
	if Vector2(p.x - VILLAGE.x, p.z - VILLAGE.z).length() < 34.0:
		return false
	if absf(p.z - RIVER_Z) < RIVER_W:
		return false
	if Vector2(p.x - POND.x, p.z - POND.z).length() < POND_R + 5.0:
		return false
	if p.x > WHEAT.position.x - 4 and p.x < WHEAT.end.x + 4 and p.z > WHEAT.position.y - 4 and p.z < WHEAT.end.y + 6:
		return false
	if Vector2(p.x - MILL_HILL.x, p.z - MILL_HILL.z).length() < MILL_HILL_R + 2.0:
		return false
	if p.x < -26.0 and p.x > -125.0 and absf(p.z + 2.0) < 16.0:
		return false                           # аеродром і смуга
	if Vector2(p.x + 11.5, p.z - 13.0).length() < 8.0:
		return false                           # хата Тарасика
	if absf(p.x + 23.0) < 4.0 and p.z > 18.0 and p.z < 30.0:
		return false
	return true


func _make_forest(rng: RandomNumberGenerator) -> void:
	var kinds := ["birch_b_lo", "pine_lo", "birch_a_lo", "pine_lo"]
	var heights := {"birch_b_lo": [7.0, 10.0], "pine_lo": [8.0, 12.0], "birch_a_lo": [6.5, 9.0]}
	var chunk := 40.0
	var buckets := {}               # (шматок, вид) → масив [позиція, кут, висота]
	var n := 0
	var tries := 0
	while n < 700 and tries < 9000:
		tries += 1
		var p: Vector3
		var r := rng.randf()
		if r < 0.45:
			p = Vector3(rng.randf_range(30, 160), 0, rng.randf_range(-90, 70))          # ліс на сході
		elif r < 0.75:
			p = Vector3(rng.randf_range(-170, 170), 0, rng.randf_range(112, 200))       # ліс за річкою
		elif r < 0.9:
			p = Vector3(rng.randf_range(-170, -40), 0, rng.randf_range(-130, -5))       # гай на заході
		else:
			p = Vector3(rng.randf_range(-170, 170), 0, rng.randf_range(-170, -40))      # за подвір'ям
		if p.length() > LIMIT + 30.0 or not _ok_tree(p):
			continue
		var k: String = kinds[rng.randi() % kinds.size()]
		if not Models.exists(k):
			continue
		var key := "%d_%d_%s" % [floori(p.x / chunk), floori(p.z / chunk), k]
		if not buckets.has(key):
			buckets[key] = []
		var hr: Array = heights[k]
		buckets[key].append([p, rng.randf() * TAU, rng.randf_range(hr[0], hr[1])])
		trees.append([p.x, p.z])
		_obst.append([p.x, p.z, 0.5, 6.0])
		n += 1
	# зразок кожного виду: меш і як він стоїть у моделі
	var proto := {}
	for k in kinds:
		if proto.has(k) or not Models.exists(k):
			continue
		var h := Models.spawn(self, k, 1.0)
		var mi: MeshInstance3D = h.find_children("*", "MeshInstance3D", true, false)[0]
		proto[k] = [mi.mesh, h.global_transform.affine_inverse() * mi.global_transform, mi.get_active_material(0)]
		h.queue_free()
	for key in buckets:
		var ks := String(key)
		var k := ks.substr(ks.find("_", ks.find("_") + 1) + 1)
		var pr: Array = proto[k]
		var list: Array = buckets[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = pr[0]
		mm.instance_count = list.size()
		for i in list.size():
			var it: Array = list[i]
			var tr := Transform3D(Basis(Vector3.UP, float(it[1])).scaled(Vector3.ONE * float(it[2])), it[0])
			mm.set_instance_transform(i, tr * (pr[1] as Transform3D))
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = pr[2]
		mmi.visibility_range_end = 170.0
		mmi.visibility_range_end_margin = 20.0
		mmi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED
		add_child(mmi)


# ------------------------------------------------------------------ аеродром: ангар і злітна смуга
var hangar_doors: Array = []                  # [лівий, правий]
var _hangar_tw: Tween
var hangar_open := false


func _make_airfield() -> void:
	var hg := Node3D.new()
	hg.name = "hangar"
	hg.position = HANGAR
	add_child(hg)
	var metal := Util.mat(Color(0.74, 0.76, 0.72), 0.55)
	var metal2 := Util.mat(Color(0.62, 0.66, 0.62), 0.55)
	var roof_m := Util.mat(Color(0.58, 0.36, 0.28), 0.7)
	var floor_m := Util.mat(Color(0.6, 0.6, 0.58), 0.95)
	const HX := 5.0          # пів-довжини (уздовж x)
	const HZ := 5.8          # пів-ширини
	const WH := 3.6          # висота стін
	hg.add_child(Util.box(Vector3(HX * 2.0, 0.06, HZ * 2.0), floor_m, Vector3(0, 0.03, 0)))
	# стіни: задня й бокові (ребристі — смужками двох відтінків)
	for i in 8:
		var z := -HZ + (i + 0.5) * HZ * 2.0 / 8.0
		hg.add_child(Util.box(Vector3(0.14, WH, HZ * 2.0 / 8.0), metal if i % 2 == 0 else metal2, Vector3(HX, WH / 2.0, z)))
	for sgn in [-1.0, 1.0]:
		for i in 7:
			var x := -HX + (i + 0.5) * HX * 2.0 / 7.0
			hg.add_child(Util.box(Vector3(HX * 2.0 / 7.0, WH, 0.14), metal if i % 2 == 0 else metal2, Vector3(x, WH / 2.0, sgn * HZ)))
		# віконця збоку
		for x in [-2.5, 0.0, 2.5]:
			hg.add_child(Util.box(Vector3(1.2, 0.6, 0.16), Util.mat(Color(0.55, 0.75, 0.9), 0.2), Vector3(x, 2.7, sgn * HZ)))
	# дах-арка (з дощок по дузі) і фронтони спереду й ззаду
	var n := 14
	for i in n:
		var t0 := -PI / 2.0 + PI * i / n
		var t1 := -PI / 2.0 + PI * (i + 1) / n
		var p0 := Vector2(HZ * 1.03 * sin(t0), WH + 2.4 * cos(t0))
		var p1 := Vector2(HZ * 1.03 * sin(t1), WH + 2.4 * cos(t1))
		var mid := (p0 + p1) / 2.0
		var seg := Util.box(Vector3(HX * 2.0 + 0.5, 0.12, p0.distance_to(p1) + 0.05), roof_m, Vector3(0, mid.y, mid.x))
		seg.rotation.x = -atan2(p1.y - p0.y, p1.x - p0.x)
		hg.add_child(seg)
		var gh := mid.y - WH
		if gh > 0.05:
			for sx in [-HX, HX]:
				hg.add_child(Util.box(Vector3(0.12, gh, p0.distance_to(p1) + 0.02), metal2, Vector3(sx, WH + gh / 2.0, mid.x)))
	# над воротами — балка й напис
	hg.add_child(Util.box(Vector3(0.3, 0.3, HZ * 2.0 + 0.2), Util.mat(Color(0.85, 0.7, 0.2), 0.6), Vector3(-HX - 0.05, WH - 0.1, 0)))
	var lb := Label3D.new()
	lb.text = "АНГАР"
	lb.font = load("res://assets/fonts/DejaVuSans-Bold.ttf")
	lb.font_size = 160
	lb.pixel_size = 0.006
	lb.modulate = Color(0.85, 0.2, 0.15)
	lb.outline_size = 0
	lb.position = Vector3(-HX - 0.15, WH + 1.0, 0)
	lb.rotation.y = -PI / 2.0
	hg.add_child(lb)
	# розсувні ворота (дві стулки)
	var door_m := Util.mat(Color(0.35, 0.5, 0.62), 0.5)
	for sgn in [-1.0, 1.0]:
		var d := Node3D.new()
		d.position = Vector3(-HX - 0.22, 0, sgn * HZ / 2.0)
		hg.add_child(d)
		d.add_child(Util.box(Vector3(0.1, WH - 0.25, HZ), door_m, Vector3(0, (WH - 0.25) / 2.0, 0)))
		for k in 3:
			d.add_child(Util.box(Vector3(0.12, 0.08, HZ - 0.1), Util.mat(Color(0.9, 0.85, 0.75), 0.6), Vector3(-0.02, 0.6 + k * 1.1, 0)))
		d.set_meta("closed_z", sgn * HZ / 2.0)
		d.set_meta("open_z", sgn * (HZ * 1.5 + 0.3))
		hangar_doors.append(d)
	# колесовідбійники-перешкоди для тих, хто ходить
	for i in 7:
		_obst.append([HANGAR.x + HX, HANGAR.z - HZ + i * HZ * 2.0 / 6.0, 0.9, 4.0])
	for sgn in [-1.0, 1.0]:
		for i in 6:
			_obst.append([HANGAR.x - HX + i * HX * 2.0 / 5.0, HANGAR.z + sgn * HZ, 0.9, 4.0])
	houses.append([HANGAR.x, HANGAR.z])
	# злітна смуга: темна доріжка, біла пунктирна осьова, «зебра» на початку й у кінці
	var strip := Node3D.new()
	strip.name = "runway"
	add_child(strip)
	var ra := RUNWAY_A + Vector3(4.0, 0, 0)
	var rb := RUNWAY_B - Vector3(3.0, 0, 0)
	var len := ra.distance_to(rb)
	var c := (ra + rb) / 2.0
	var asphalt := Util.mat(Color(0.36, 0.37, 0.38), 0.95)
	var white := Util.mat(Color(0.95, 0.95, 0.92), 0.8)
	strip.add_child(Util.box(Vector3(len, 0.04, 8.0), asphalt, Vector3(c.x, 0.02, c.z)))
	strip.add_child(Util.box(Vector3(5.0, 0.04, 4.0), asphalt, Vector3(HANGAR.x - 7.0, 0.02, HANGAR.z)))
	var x := ra.x - 10.0
	while x > rb.x + 10.0:
		strip.add_child(Util.box(Vector3(3.0, 0.045, 0.25), white, Vector3(x, 0.025, c.z)))
		x -= 6.0
	for end in [ra.x - 3.0, rb.x + 3.0]:
		for k in 6:
			strip.add_child(Util.box(Vector3(3.5, 0.045, 0.4), white, Vector3(end, 0.025, c.z - 2.8 + k * 1.12)))
	for e in strip.get_children():
		(e as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# вітровказ (смугастий конус на щоглі)
	var ws := Node3D.new()
	ws.position = RUNWAY_A + Vector3(-6.0, 0, -7.5)
	add_child(ws)
	ws.add_child(Util.cyl(0.05, 0.07, 4.2, Util.mat(Color(0.9, 0.9, 0.9), 0.6), Vector3(0, 2.1, 0)))
	for k in 3:
		var cone := Util.cyl(0.32 - k * 0.07, 0.25 - k * 0.07, 0.5, Util.mat(Color(0.95, 0.45, 0.1) if k % 2 == 0 else Color(0.95, 0.95, 0.95), 0.7), Vector3(0.3 + k * 0.5, 4.0, 0))
		cone.rotation.z = PI / 2.0
		ws.add_child(cone)
	_obst.append([ws.position.x, ws.position.z, 0.3, 4.0])


func set_hangar_door(open: bool) -> void:
	if hangar_open == open and _hangar_tw == null:
		return
	hangar_open = open
	if _hangar_tw:
		_hangar_tw.kill()
	_hangar_tw = create_tween().set_parallel(true).set_trans(Tween.TRANS_SINE)
	for d in hangar_doors:
		_hangar_tw.tween_property(d, "position:z", float(d.get_meta("open_z" if open else "closed_z")), 2.2)
	_hangar_tw.chain().tween_callback(func(): _hangar_tw = null)
	var au = get_node_or_null("/root/Main/Audio")
	if au and au.has_method("play_at") and hangar_doors.size() > 0:
		au.play_at("door_open", hangar_doors[0], -4.0, 0.6)


func is_blocked(p: Vector3, r: float) -> bool:
	## Чи заважає щось сісти літаку в точці p (дерева, хати, вода, подвір'я, поле, пагорб вітряка).
	if p.x > -27.0 and p.x < 23.0 and p.z > -35.0 and p.z < 10.0:
		return true
	if Vector2(p.x - VILLAGE.x, p.z - VILLAGE.z).length() < 34.0:
		return true
	if p.x > WHEAT.position.x - 2 and p.x < WHEAT.end.x + 2 and p.z > WHEAT.position.y - 2 and p.z < WHEAT.end.y + 2:
		return true
	if Vector2(p.x - MILL_HILL.x, p.z - MILL_HILL.z).length() < MILL_HILL_R + 3.0:
		return true
	for o in _obst:
		if Vector2(p.x - o[0], p.z - o[1]).length() < float(o[2]) + r:
			return true
	return false


# ------------------------------------------------------------------ ларки на базарі
const STALLS := [
	["bread", "Хліб", Vector3(-8.0, 0, -9.5), Color(0.85, 0.35, 0.25), "Паляниці, калачі й бублики — ще теплі!"],
	["meat", "М'ясо", Vector3(8.0, 0, -9.5), Color(0.75, 0.2, 0.25), "Ковбаски, сало й шинка — до борщу!"],
	["veg", "Овочі", Vector3(-9.5, 0, 8.5), Color(0.3, 0.6, 0.3), "Морква, буряк, капуста, гарбузи й яблучка."],
	["honey", "Мед", Vector3(4.5, 0, -11.5), Color(0.95, 0.65, 0.15), "Липовий і гречаний мед — солодкий-пресолодкий."],
	["pots", "Глечики", Vector3(11.0, 0, 5.0), Color(0.3, 0.45, 0.8), "Глиняні глечики, макітри й мисочки."],
]


func _make_stalls() -> void:
	var wood := Util.mat(Color(0.55, 0.38, 0.22), 0.9)
	var dark := Util.mat(Color(0.4, 0.27, 0.16), 0.9)
	var white := Util.mat(Color(0.96, 0.94, 0.88), 0.9)
	var font: Font = load("res://assets/fonts/DejaVuSans-Bold.ttf")
	for st in STALLS:
		var n := Node3D.new()
		n.name = "stall_" + String(st[0])
		n.position = VILLAGE + (st[2] as Vector3)
		var to: Vector3 = VILLAGE - n.position
		n.rotation.y = atan2(to.x, to.z)          # прилавком до фонтану
		add_child(n)
		var col: Color = st[3]
		var stripe := Util.mat(col, 0.85)
		# прилавок і стовпчики
		n.add_child(Util.box(Vector3(2.4, 0.9, 0.9), wood, Vector3(0, 0.45, 0.35)))
		n.add_child(Util.box(Vector3(2.5, 0.06, 1.0), dark, Vector3(0, 0.93, 0.35)))
		for sx in [-1.15, 1.15]:
			for sz in [-0.15, 0.85]:
				n.add_child(Util.box(Vector3(0.08, 2.3, 0.08), dark, Vector3(sx, 1.15, sz)))
		# смугастий навіс
		for k in 8:
			var a := Util.box(Vector3(0.32, 0.04, 1.5), stripe if k % 2 == 0 else white, Vector3(-1.12 + k * 0.32, 2.35, 0.4))
			a.rotation.x = 0.28
			n.add_child(a)
		for k in 8:
			var fr := Util.box(Vector3(0.32, 0.18, 0.03), stripe if k % 2 == 0 else white, Vector3(-1.12 + k * 0.32, 2.07, 1.12))
			n.add_child(fr)
		# вивіска
		var lb := Label3D.new()
		lb.text = st[1]
		lb.font = font
		lb.font_size = 72
		lb.pixel_size = 0.005
		lb.modulate = Color(0.25, 0.15, 0.08)
		lb.outline_size = 10
		lb.outline_modulate = Color(1, 0.97, 0.85)
		lb.position = Vector3(0, 2.62, 0.55)
		n.add_child(lb)
		_stall_goods(n, String(st[0]))
		n.set_meta("stall", [st[1], st[4]])
		n.add_child(Util.pick_area("stall", Vector3(2.6, 2.6, 1.6), Vector3(0, 1.3, 0.4)))
		_obst.append([n.position.x, n.position.z, 1.4, 2.5])


func _stall_goods(n: Node3D, kind: String) -> void:
	var y := 0.96
	var rng := RandomNumberGenerator.new()
	rng.seed = kind.hash()
	match kind:
		"bread":
			var crust := Util.mat(Color(0.78, 0.5, 0.22), 0.8)
			var light := Util.mat(Color(0.9, 0.68, 0.36), 0.8)
			for i in 6:
				n.add_child(Util.sphere(0.16, crust if i % 2 == 0 else light, Vector3(-0.9 + i * 0.36, y + 0.08, 0.35 + rng.randf_range(-0.15, 0.15)), Vector3(1.3, 0.6, 1.0)))
			for i in 3:
				var bub := Util.mesh(TorusMesh.new(), light, Vector3(-0.6 + i * 0.6, y + 0.35, 0.05), Vector3(90, 0, 0), Vector3(0.22, 0.22, 0.22))
				n.add_child(bub)
		"meat":
			var red := Util.mat(Color(0.75, 0.3, 0.3), 0.7)
			var pink := Util.mat(Color(0.95, 0.8, 0.75), 0.7)
			var saus := Util.mat(Color(0.55, 0.22, 0.15), 0.6)
			for i in 4:
				n.add_child(Util.box(Vector3(0.36, 0.14, 0.26), red if i % 2 == 0 else pink, Vector3(-0.8 + i * 0.52, y + 0.07, 0.4)))
			for i in 6:
				var c := Util.capsule(0.045, 0.45, saus, Vector3(-0.9 + i * 0.36, 1.75, 0.0))
				n.add_child(c)
		"veg":
			var crate := Util.mat(Color(0.6, 0.45, 0.28), 0.9)
			var cols := [Color(0.95, 0.5, 0.1), Color(0.55, 0.12, 0.25), Color(0.5, 0.75, 0.3), Color(0.85, 0.2, 0.15)]
			for i in 4:
				var cx := -0.85 + i * 0.57
				n.add_child(Util.box(Vector3(0.5, 0.16, 0.5), crate, Vector3(cx, y + 0.08, 0.35)))
				var m := Util.mat(cols[i], 0.7)
				for k in 5:
					n.add_child(Util.sphere(0.07, m, Vector3(cx + rng.randf_range(-0.16, 0.16), y + 0.2, 0.35 + rng.randf_range(-0.16, 0.16))))
			n.add_child(Util.sphere(0.32, Util.mat(Color(0.95, 0.55, 0.15), 0.7), Vector3(1.6, 0.28, 0.6), Vector3(1.0, 0.8, 1.0)))
		"honey":
			var jar := Util.mat(Color(0.95, 0.65, 0.12), 0.25)
			var lid := Util.mat(Color(0.85, 0.2, 0.15), 0.6)
			for i in 7:
				var x := -0.95 + i * 0.32
				var zz := 0.25 + (i % 2) * 0.25
				n.add_child(Util.cyl(0.09, 0.09, 0.22, jar, Vector3(x, y + 0.11, zz)))
				n.add_child(Util.cyl(0.095, 0.095, 0.04, lid, Vector3(x, y + 0.24, zz)))
		"pots":
			var clay := Util.mat(Color(0.72, 0.4, 0.25), 0.8)
			var blue := Util.mat(Color(0.3, 0.45, 0.75), 0.6)
			for i in 5:
				var x := -0.9 + i * 0.45
				var m2: Material = clay if i % 2 == 0 else blue
				n.add_child(Util.sphere(0.15, m2, Vector3(x, y + 0.15, 0.35), Vector3(1.0, 1.1, 1.0)))
				n.add_child(Util.cyl(0.05, 0.07, 0.14, m2, Vector3(x, y + 0.34, 0.35)))
			n.add_child(Util.sphere(0.3, clay, Vector3(-1.55, 0.3, 0.6), Vector3(1.0, 1.0, 1.0)))


# ------------------------------------------------------------------ пташки в небі
var sky_birds: Array = []          # [вузол, ліве крило, праве крило, зграя, фаза]
var _flocks: Array = []            # [центр, радіус, висота, швидкість, кут]


func _make_sky_birds() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var dark := Util.mat(Color(0.18, 0.16, 0.15), 0.9)
	var light := Util.mat(Color(0.95, 0.95, 0.95), 0.9)
	var flocks := [[Vector3(-10, 0, 20), 45.0, 30.0, 0.09, dark, 7], [Vector3(30, 0, 60), 35.0, 24.0, -0.12, light, 5],
		[Vector3(-60, 0, -30), 55.0, 38.0, 0.07, dark, 8], [Vector3(0, 0, -5), 22.0, 20.0, 0.15, dark, 3]]
	for fi in flocks.size():
		var f: Array = flocks[fi]
		_flocks.append([f[0], f[1], f[2], f[3], rng.randf() * TAU])
		for k in int(f[5]):
			var b := Node3D.new()
			add_child(b)
			b.scale = Vector3.ONE * 2.2
			b.add_child(Util.sphere(0.12, f[4], Vector3.ZERO, Vector3(0.8, 0.7, 1.8)))
			var wl := Node3D.new()
			var wr := Node3D.new()
			b.add_child(wl)
			b.add_child(wr)
			var bl := Util.box(Vector3(0.6, 0.03, 0.22), f[4], Vector3(-0.3, 0, 0))
			var br := Util.box(Vector3(0.6, 0.03, 0.22), f[4], Vector3(0.3, 0, 0))
			bl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			br.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			wl.add_child(bl)
			wr.add_child(br)
			var off := Vector3(rng.randf_range(-4, 4), rng.randf_range(-1.5, 1.5), rng.randf_range(-4, 4))
			sky_birds.append([b, wl, wr, fi, rng.randf() * TAU, off])


func _sky_birds_step(delta: float) -> void:
	var night := Game.is_night()
	for f in _flocks:
		f[4] = float(f[4]) + float(f[3]) * delta
	for it in sky_birds:
		var b: Node3D = it[0]
		b.visible = not night
		if night:
			continue
		var f: Array = _flocks[it[3]]
		var a: float = f[4]
		var c: Vector3 = f[0]
		var r: float = f[1]
		var off: Vector3 = it[5]
		var p := c + Vector3(cos(a) * r, float(f[2]) + sin(a * 3.0 + float(it[4])) * 1.2, sin(a) * r) + off
		var dir := Vector3(-sin(a), 0, cos(a)) * signf(float(f[3]))
		b.position = p
		b.rotation.y = atan2(dir.x, dir.z)
		var ph: float = _t * 9.0 + float(it[4])
		var flap := sin(ph) * 0.6 if fmod(_t + float(it[4]), 6.0) < 3.5 else 0.12      # махає й ковзає
		(it[1] as Node3D).rotation.z = flap
		(it[2] as Node3D).rotation.z = -flap

extends Node3D
## Світ: небо-панорама (день/ніч), сонце й місяць, земля з травою, пагорби на обрії,
## подвір'я (хата, тин, дерева, соняшники, будка, криниця, лавка) і кімната з тераріумом.
## Усе, чого ще немає моделлю з Meshy, будується простими формами.

const ROOM := Vector3(0, 0, 200)            # кімната стоїть окремо, далеко від двору
const YARD := Rect2(-9.0, -12.0, 18.0, 17.0) # x, z — межі двору всередині тину
const HOUSE_POS := Vector3(0, 0, -9.6)

var env: Environment
var sky_mat: ShaderMaterial
var sun: DirectionalLight3D
var moon: DirectionalLight3D
var room_light: OmniLight3D
var window_lights: Array = []       # теплі вогники у вікнах хати
var window_mats: Array = []
var window_quads: Array = []
var fireflies: CPUParticles3D
var grass: MultiMeshInstance3D
var house: Node3D
var spots := {}                     # іменовані точки: миска, будка, лавка, двері…
var room_root: Node3D
var yard_root: Node3D
var _t := 0.0


func _ready() -> void:
	_make_environment()
	yard_root = Node3D.new()
	add_child(yard_root)
	room_root = Node3D.new()
	room_root.position = ROOM
	add_child(room_root)
	_make_ground()
	_make_horizon()
	_make_yard()
	_make_room()
	_make_fireflies()
	update_time(true)


# ------------------------------------------------------------------ небо, світло
func _make_environment() -> void:
	var sh := Shader.new()
	sh.code = """
shader_type sky;
uniform sampler2D day_tex : source_color, filter_linear, repeat_enable;
uniform sampler2D night_tex : source_color, filter_linear, repeat_enable;
uniform float night = 0.0;
uniform vec3 tint = vec3(1.0);
uniform float spin = 0.0;
void sky() {
	vec3 d = normalize(EYEDIR);
	float u = atan(d.x, -d.z) / 6.2831853 + 0.5 + spin;
	// горизонт картинки трохи нижче середини (≈0.47) — підганяємо під лінію землі
	float v = acos(clamp(d.y, -1.0, 1.0)) / 3.14159265;
	v = v < 0.5 ? v * 0.94 : 0.47 + (v - 0.5) * 1.06;
	vec2 uv = vec2(fract(u), clamp(v, 0.002, 0.998));
	vec3 c = mix(texture(day_tex, uv).rgb, texture(night_tex, uv).rgb, night);
	COLOR = c * tint;
}
"""
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = sh
	sky_mat.set_shader_parameter("day_tex", load("res://assets/sky/day.jpg"))
	sky_mat.set_shader_parameter("night_tex", load("res://assets/sky/night.jpg"))
	var sky := Sky.new()
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_32
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 0.84
	env.fog_enabled = true
	env.fog_density = 0.0028
	env.fog_sky_affect = 0.0
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 40.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.shadow_blur = 1.5
	add_child(sun)
	moon = DirectionalLight3D.new()
	moon.light_color = Color(0.55, 0.65, 1.0)
	moon.rotation_degrees = Vector3(-50, 30, 0)
	add_child(moon)


func update_time(_force := false) -> void:
	## Сонце, місяць, кольори неба й туману, вогники — за часом доби з Game.
	var h := Game.hour()
	var n := Game.night_amount()
	# сонце: сходить о 6 на сході, о 13 найвище, сідає о 20 на заході
	var k := clampf((h - 6.0) / 14.0, 0.0, 1.0)
	var elev := sin(k * PI) * 58.0 + 4.0
	sun.rotation_degrees = Vector3(-elev, lerpf(-100.0, 100.0, k), 0)
	# тепле світло зранку й увечері, біле вдень
	var warm := 1.0 - clampf(abs(h - 13.0) / 6.0, 0.0, 1.0)
	var sun_col := Color(1.0, 0.72, 0.5).lerp(Color(1.0, 0.96, 0.9), warm)
	sun.light_color = sun_col
	var indoor: bool = Game.state["location"] == "room"
	sun.light_energy = 0.95 * (1.0 - n) * (0.35 if indoor else 1.0)
	sun.visible = n < 0.97
	moon.light_energy = 0.32 * n
	moon.visible = n > 0.03
	var amb_day := Color(0.78, 0.8, 0.86)
	var amb_night := Color(0.22, 0.27, 0.45)
	env.ambient_light_color = amb_day.lerp(amb_night, n)
	env.ambient_light_energy = lerpf(0.5, 0.55, n) * (0.55 if indoor else 1.0)
	var dusk := clampf(1.0 - abs(n - 0.5) * 2.0, 0.0, 1.0)     # найбільше на межі дня й ночі
	var tint := Color(0.86, 0.86, 0.88).lerp(Color(0.95, 0.78, 0.72), dusk * 0.8)
	sky_mat.set_shader_parameter("night", n)
	sky_mat.set_shader_parameter("tint", Vector3(tint.r, tint.g, tint.b))
	env.fog_light_color = Color(0.7, 0.78, 0.82).lerp(Color(0.16, 0.2, 0.36), n).lerp(Color(0.95, 0.75, 0.62), dusk * 0.5)
	# вогники: вікна хати, кімнати, світлячки
	for l in window_lights:
		(l as OmniLight3D).light_energy = 1.4 * smoothstep(0.3, 0.8, n)
	for q in window_quads:
		(q as Node3D).visible = n > 0.25
	for m in window_mats:
		(m as StandardMaterial3D).emission_energy_multiplier = 2.2 * smoothstep(0.3, 0.8, n)
		(m as StandardMaterial3D).albedo_color = Color(0.35, 0.3, 0.25).lerp(Color(1.0, 0.8, 0.45), smoothstep(0.3, 0.8, n))
	if fireflies:
		fireflies.emitting = n > 0.6 and Game.state["location"] == "yard"
	if room_light:
		room_light.light_energy = lerpf(1.1, 1.5, n)


func _process(delta: float) -> void:
	_t += delta
	update_time()


# ------------------------------------------------------------------ земля, трава, обрій
func _make_ground() -> void:
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
render_mode diffuse_lambert, specular_disabled;
uniform vec3 grass_a : source_color = vec3(0.26, 0.45, 0.15);
uniform vec3 grass_b : source_color = vec3(0.4, 0.56, 0.21);
uniform vec3 dirt : source_color = vec3(0.58, 0.45, 0.3);
uniform vec3 far_col : source_color = vec3(0.42, 0.54, 0.3);
varying vec3 wp;
float h(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float nz(vec2 p) {
	vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(h(i), h(i + vec2(1, 0)), f.x), mix(h(i + vec2(0, 1)), h(i + vec2(1, 1)), f.x), f.y);
}
float seg(vec2 p, vec2 a, vec2 b) {
	vec2 pa = p - a; vec2 ba = b - a;
	float t = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
	return length(pa - ba * t);
}
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	vec2 p = wp.xz;
	float n = nz(p * 0.18) * 0.55 + nz(p * 0.7) * 0.3 + nz(p * 3.0) * 0.15;
	vec3 g = mix(grass_a, grass_b, n);
	// стежки: від воріт до хати, до криниці, до будки; витоптане місце біля ґанку
	float d = seg(p, vec2(0.0, 6.0), vec2(0.0, -7.3));
	d = min(d, seg(p, vec2(0.0, -2.5), vec2(5.8, -4.2)));
	d = min(d, seg(p, vec2(0.0, -3.5), vec2(-4.6, -5.0)));
	d = min(d, length(p - vec2(0.0, -6.6)) - 1.6);
	float w = 0.75 + nz(p * 1.3) * 0.35;
	float path = 1.0 - smoothstep(w - 0.25, w + 0.15, d);
	vec3 c = mix(g, dirt * (0.9 + nz(p * 4.0) * 0.2), path);
	float far = smoothstep(25.0, 70.0, length(p - vec2(0.0, -3.0)));
	ALBEDO = mix(c, far_col, far * 0.7);
	ROUGHNESS = 1.0;
}
"""
	var m := ShaderMaterial.new()
	m.shader = sh
	var pm := PlaneMesh.new()
	pm.size = Vector2(320, 320)
	pm.subdivide_width = 8
	pm.subdivide_depth = 8
	var g := MeshInstance3D.new()
	g.mesh = pm
	g.material_override = m
	yard_root.add_child(g)
	_make_grass()


func _grass_mesh() -> ArrayMesh:
	## Пучок трави з п'яти травинок; колір від темного низу до світлого верху.
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in 5:
		var a := float(i) / 5.0 * TAU + randf() * 0.6
		var off := Vector3(cos(a), 0, sin(a)) * 0.05
		var lean := Vector3(cos(a), 0, sin(a)) * randf_range(0.04, 0.1)
		var side := Vector3(-sin(a), 0, cos(a)) * 0.025
		var hgt := randf_range(0.22, 0.38)
		st.set_color(Color(0.16, 0.32, 0.09))
		st.add_vertex(off - side)
		st.add_vertex(off + side)
		st.set_color(Color(0.46, 0.64, 0.24))
		st.add_vertex(off + lean + Vector3(0, hgt, 0))
	st.generate_normals()
	return st.commit()


func _make_grass() -> void:
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
render_mode cull_disabled, diffuse_lambert, specular_disabled;
uniform float t = 0.0;
void vertex() {
	vec3 w = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float k = VERTEX.y * 2.5;
	VERTEX.x += sin(TIME * 1.7 + w.x * 0.6 + w.z * 0.4) * 0.05 * k;
	VERTEX.z += cos(TIME * 1.3 + w.x * 0.3) * 0.03 * k;
}
void fragment() { ALBEDO = COLOR.rgb; ROUGHNESS = 1.0; }
"""
	var mat := ShaderMaterial.new()
	mat.shader = sh
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = false
	mm.mesh = _grass_mesh()
	var pts: Array = []
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	while pts.size() < 2600:
		var p := Vector3(rng.randf_range(-16, 16), 0, rng.randf_range(-16, 10))
		if _on_path(Vector2(p.x, p.z)) or _in_house(p):
			continue
		pts.append(p)
	mm.instance_count = pts.size()
	for i in pts.size():
		var b := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.7, 1.4))
		mm.set_instance_transform(i, Transform3D(b, pts[i]))
	grass = MultiMeshInstance3D.new()
	grass.multimesh = mm
	grass.material_override = mat
	grass.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	yard_root.add_child(grass)
	# квіточки серед трави
	var fm := MultiMesh.new()
	fm.transform_format = MultiMesh.TRANSFORM_3D
	fm.use_colors = true
	var sm := SphereMesh.new()
	sm.radius = 0.035
	sm.height = 0.05
	sm.radial_segments = 6
	sm.rings = 3
	fm.mesh = sm
	var cols := [Color(1, 1, 1), Color(1, 0.85, 0.2), Color(0.75, 0.55, 1), Color(1, 0.55, 0.6), Color(0.5, 0.7, 1)]
	var fl: Array = []
	while fl.size() < 360:
		var p := Vector3(rng.randf_range(-15, 15), rng.randf_range(0.12, 0.28), rng.randf_range(-15, 9))
		if _on_path(Vector2(p.x, p.z)) or _in_house(p):
			continue
		fl.append(p)
	fm.instance_count = fl.size()
	for i in fl.size():
		fm.set_instance_transform(i, Transform3D(Basis(), fl[i]))
		fm.set_instance_color(i, cols[rng.randi() % cols.size()])
	var fmat := StandardMaterial3D.new()
	fmat.vertex_color_use_as_albedo = true
	fmat.roughness = 0.8
	var fmi := MultiMeshInstance3D.new()
	fmi.multimesh = fm
	fmi.material_override = fmat
	fmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	yard_root.add_child(fmi)


func _on_path(p: Vector2) -> bool:
	var d := _seg(p, Vector2(0, 6), Vector2(0, -7.3))
	d = minf(d, _seg(p, Vector2(0, -2.5), Vector2(5.8, -4.2)))
	d = minf(d, _seg(p, Vector2(0, -3.5), Vector2(-4.6, -5.0)))
	d = minf(d, p.distance_to(Vector2(0, -6.6)) - 1.6)
	return d < 0.95


func _seg(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ba := b - a
	var t := clampf((p - a).dot(ba) / ba.dot(ba), 0.0, 1.0)
	return p.distance_to(a + ba * t)


func _in_house(p: Vector3) -> bool:
	return abs(p.x - HOUSE_POS.x) < 3.4 and abs(p.z - HOUSE_POS.z) < 2.8


func _make_horizon() -> void:
	## Кільце м'яких пагорбів і дерев довкола — ховає край землі й зливається з панорамою.
	var rng := RandomNumberGenerator.new()
	rng.seed = 3
	var hill := Util.mat(Color(0.42, 0.56, 0.27), 1.0)
	var hill2 := Util.mat(Color(0.5, 0.62, 0.3), 1.0)
	for i in 34:
		var a := float(i) / 34.0 * TAU + rng.randf() * 0.1
		var r := rng.randf_range(48, 62)
		var p := Vector3(sin(a) * r, -rng.randf_range(2.5, 4.0), cos(a) * r - 3.0)
		var s := Vector3(rng.randf_range(10, 16), rng.randf_range(3.5, 6.0), rng.randf_range(7, 10))
		var hm := Util.sphere(1.0, hill if i % 2 == 0 else hill2, p, s)
		hm.rotation.y = a
		hm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		yard_root.add_child(hm)
	# дерева за тином: берізки й округлі крони
	for i in 46:
		var a := rng.randf() * TAU
		var r := rng.randf_range(17, 32)
		var p := Vector3(sin(a) * r, 0, cos(a) * r - 3.0)
		if p.z > 14.0 and abs(p.x) < 6.0:
			continue     # не заступати вид на камеру з боку воріт
		yard_root.add_child(_tree(p, rng.randf_range(0.8, 1.5), rng.randi() % 3 == 0, rng))


func _crown(t: Node3D, base: Vector3, s: float, rng: RandomNumberGenerator, dark: Color, light: Color, n: int) -> void:
	## Пишна крона: великі темні кулі всередині, менші світлі — зверху й з боків.
	for i in n:
		var k := float(i) / n
		var a := rng.randf() * TAU
		var r := rng.randf_range(0.2, 0.95) * s
		var o := base + Vector3(cos(a) * r, rng.randf_range(-0.35, 0.65) * s + k * 0.5 * s, sin(a) * r)
		var c := dark.lerp(light, clampf(k * 0.8 + rng.randf() * 0.35, 0.0, 1.0))
		var sz := rng.randf_range(0.45, 0.8) * s * (1.25 - k * 0.5)
		var sp := Util.sphere(sz, Util.mat(c, 0.95), o, Vector3(1, rng.randf_range(0.75, 0.95), 1))
		t.add_child(sp)


func _tree(p: Vector3, s: float, birch: bool, rng: RandomNumberGenerator) -> Node3D:
	var t := Node3D.new()
	t.position = p
	t.rotation.y = rng.randf() * TAU
	var bark := Util.mat(Color(0.9, 0.89, 0.85) if birch else Color(0.38, 0.27, 0.17), 0.9)
	var hgt := (3.4 if birch else 2.4) * s
	t.add_child(Util.cyl(0.08 * s, 0.17 * s, hgt, bark, Vector3(0, hgt / 2.0, 0), Vector3(0, 0, rng.randf_range(-4, 4))))
	if birch:
		for i in 5:
			t.add_child(Util.box(Vector3(0.13, 0.03, 0.13) * s, Util.mat(Color(0.15, 0.15, 0.15)), Vector3(0, rng.randf_range(0.4, hgt * 0.8), 0)))
		_crown(t, Vector3(0, hgt * 0.95, 0), 1.0 * s, rng, Color(0.36, 0.52, 0.2), Color(0.66, 0.78, 0.36), 9)
	else:
		for i in 2:
			var br := Util.cyl(0.04 * s, 0.07 * s, 1.1 * s, bark, Vector3(0, hgt * 0.75, 0), Vector3(0, i * 120.0, 45.0 if i == 0 else -40.0))
			t.add_child(br)
		_crown(t, Vector3(0, hgt + 0.5 * s, 0), 1.35 * s, rng, Color(0.2, 0.38, 0.14), Color(0.5, 0.66, 0.26), 11)
	return t


# ------------------------------------------------------------------ подвір'я
func _make_yard() -> void:
	# хата
	house = Models.spawn(yard_root, "hata", 4.4)
	if house == null:
		house = Node3D.new()
		yard_root.add_child(house)
		house.add_child(Util.box(Vector3(6, 2.6, 4.2), Util.mat(Color(0.97, 0.96, 0.92)), Vector3(0, 1.3, 0)))
		house.add_child(Util.mesh(PrismMesh.new(), Util.mat(Color(0.8, 0.62, 0.3)), Vector3(0, 3.4, 0), Vector3.ZERO, Vector3(6.6, 1.8, 4.8)))
	house.position = HOUSE_POS
	house.add_child(Util.pick_area("house", Vector3(5.6, 4.0, 4.6), Vector3(0, 2.0, 0)))
	spots["door"] = HOUSE_POS + Vector3(-0.1, 0, 2.6)
	# вікна: теплі вогники вночі (у моделі хати вікна по боках дверей)
	for wx in [-1.22, 1.3]:
		var wm := StandardMaterial3D.new()
		wm.emission_enabled = true
		wm.emission = Color(1.0, 0.75, 0.4)
		wm.albedo_color = Color(0.35, 0.3, 0.25)
		window_mats.append(wm)
		var q := Util.box(Vector3(0.5, 0.55, 0.02), wm, HOUSE_POS + Vector3(wx, 1.6, 2.12))
		window_quads.append(q)
		q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		yard_root.add_child(q)
		var l := OmniLight3D.new()
		l.light_color = Color(1.0, 0.72, 0.4)
		l.omni_range = 4.0
		l.position = HOUSE_POS + Vector3(wx, 1.5, 2.6)
		yard_root.add_child(l)
		window_lights.append(l)
	_make_fence()
	# будка Біма, миска, криниця, лавка, яблуні, соняшники
	spots["doghouse"] = Vector3(-5.2, 0, -5.6)
	yard_root.add_child(_doghouse(spots["doghouse"]))
	spots["bowl"] = Vector3(-3.6, 0, -4.2)
	spots["well"] = Vector3(6.2, 0, -4.6)
	_well(spots["well"])
	spots["bench"] = Vector3(3.6, 0, -6.6)
	yard_root.add_child(_bench(spots["bench"]))
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	for tp in [Vector3(-7.4, 0, -9.8), Vector3(7.6, 0, -10.4), Vector3(-7.8, 0, 2.6), Vector3(7.8, 0, 1.8)]:
		var tr := _apple_tree(tp, rng.randf_range(0.9, 1.15), rng)
		yard_root.add_child(tr)
	for i in 9:
		yard_root.add_child(_sunflower(Vector3(-8.4 + (i % 2) * 0.5, 0, -6.6 + i * 0.85), rng))
	# точки, куди можуть ходити персонажі
	spots["porch"] = HOUSE_POS + Vector3(-0.1, 0, 3.4)
	spots["garden"] = Vector3(-6.8, 0, -2.0)
	spots["gate"] = Vector3(0, 0, 4.2)


func _make_fence() -> void:
	## Плетений тин довкола двору з воротами спереду.
	var post := Util.mat(Color(0.42, 0.3, 0.2), 0.9)
	var weave := Util.mat(Color(0.6, 0.45, 0.28), 0.95)
	var x0 := YARD.position.x - 0.5
	var x1 := YARD.end.x + 0.5
	var z0 := YARD.position.y - 0.5
	var z1 := YARD.end.y + 0.5
	var gap := 2.05 if Models.exists("gate") else 1.4
	var sides := [[Vector2(x0, z1), Vector2(-gap, z1)], [Vector2(gap, z1), Vector2(x1, z1)],
		[Vector2(x1, z1), Vector2(x1, z0)], [Vector2(x0, z0), Vector2(x1, z0)], [Vector2(x0, z0), Vector2(x0, z1)]]
	for s in sides:
		var a: Vector2 = s[0]
		var b: Vector2 = s[1]
		var n := int(ceil(a.distance_to(b) / 1.2))
		for i in n + 1:
			var p := a.lerp(b, float(i) / n)
			var pm := Util.cyl(0.04, 0.05, 1.25, post, Vector3(p.x, 0.62, p.y))
			yard_root.add_child(pm)
			if i % 3 == 1:
				# глечик на кілку
				yard_root.add_child(Util.sphere(0.12, Util.mat(Color(0.7, 0.38, 0.22), 0.6), Vector3(p.x, 1.32, p.y), Vector3(1, 1.1, 1)))
		var mid := (a + b) / 2.0
		var ln := a.distance_to(b)
		var ang := atan2(b.x - a.x, b.y - a.y)
		for k in 6:
			var bar := Util.box(Vector3(0.07, 0.11, ln), weave, Vector3(mid.x, 0.22 + k * 0.17, mid.y))
			bar.rotation.y = ang
			yard_root.add_child(bar)
	# ворота
	var gm := Models.spawn(yard_root, "gate", 1.85)
	if gm:
		gm.position = Vector3(0, 0, z1)
		gm.rotation.y = PI       # лицем до двору
		return
	for gx in [-1.4, 1.4]:
		yard_root.add_child(Util.cyl(0.08, 0.09, 1.7, post, Vector3(gx, 0.85, z1)))
	var gate := Util.box(Vector3(2.6, 0.1, 0.06), weave, Vector3(0, 1.62, z1))
	yard_root.add_child(gate)


func _doghouse(p: Vector3) -> Node3D:
	var n := Models.spawn(yard_root, "doghouse", 1.1)
	if n:
		n.position = p
		n.rotation.y = deg_to_rad(35)
		return Node3D.new()
	n = Node3D.new()
	n.position = p
	n.rotation.y = deg_to_rad(35)
	var wood := Util.mat(Color(0.72, 0.52, 0.32), 0.85)
	var roof := Util.mat(Color(0.78, 0.25, 0.2), 0.6)
	n.add_child(Util.box(Vector3(0.95, 0.7, 1.1), wood, Vector3(0, 0.35, 0)))
	var r := Util.mesh(PrismMesh.new(), roof, Vector3(0, 0.95, 0), Vector3.ZERO, Vector3(1.15, 0.5, 1.25))
	n.add_child(r)
	n.add_child(Util.cyl(0.22, 0.22, 0.02, Util.mat(Color(0.12, 0.08, 0.06)), Vector3(0, 0.32, 0.56), Vector3(90, 0, 0)))
	return n


func _well(p: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = p
	yard_root.add_child(n)
	var wm := Models.spawn(n, "well", 2.5)
	if wm:
		wm.rotation.y = deg_to_rad(-35)
		n.add_child(Util.pick_area("well", Vector3(1.4, 2.4, 1.4), Vector3(0, 1.2, 0)))
		return n
	var stone := Util.mat(Color(0.72, 0.7, 0.66), 0.9)
	var wood := Util.mat(Color(0.5, 0.36, 0.22), 0.9)
	n.add_child(Util.cyl(0.62, 0.66, 0.8, stone, Vector3(0, 0.4, 0)))
	n.add_child(Util.cyl(0.48, 0.48, 0.02, Util.mat(Color(0.12, 0.2, 0.3), 0.1), Vector3(0, 0.79, 0)))
	for sx in [-0.6, 0.6]:
		n.add_child(Util.box(Vector3(0.08, 1.6, 0.08), wood, Vector3(sx, 1.3, 0)))
	n.add_child(Util.cyl(0.08, 0.08, 1.3, wood, Vector3(0, 1.75, 0), Vector3(0, 0, 90)))
	var rf := Util.mesh(PrismMesh.new(), Util.mat(Color(0.55, 0.38, 0.24), 0.8), Vector3(0, 2.3, 0), Vector3.ZERO, Vector3(1.6, 0.6, 1.1))
	n.add_child(rf)
	n.add_child(Util.cyl(0.13, 0.11, 0.2, wood, Vector3(0.25, 1.15, 0)))
	n.add_child(Util.pick_area("well", Vector3(1.4, 2.4, 1.4), Vector3(0, 1.2, 0)))
	return n


func _bench(p: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = p
	n.rotation.y = deg_to_rad(-20)
	var wood := Util.mat(Color(0.6, 0.42, 0.26), 0.85)
	n.add_child(Util.box(Vector3(1.6, 0.08, 0.42), wood, Vector3(0, 0.45, 0)))
	n.add_child(Util.box(Vector3(1.6, 0.36, 0.06), wood, Vector3(0, 0.72, -0.2)))
	for sx in [-0.7, 0.7]:
		n.add_child(Util.box(Vector3(0.08, 0.45, 0.36), wood, Vector3(sx, 0.22, 0)))
	return n


func _apple_tree(p: Vector3, s: float, rng: RandomNumberGenerator) -> Node3D:
	var t := Node3D.new()
	t.position = p
	t.rotation.y = rng.randf() * TAU
	var bark := Util.mat(Color(0.4, 0.29, 0.2), 0.9)
	t.add_child(Util.cyl(0.12 * s, 0.22 * s, 1.7 * s, bark, Vector3(0, 0.85 * s, 0), Vector3(0, 0, 5)))
	for i in 3:
		t.add_child(Util.cyl(0.05 * s, 0.09 * s, 1.0 * s, bark, Vector3(0, 1.75 * s, 0), Vector3(0, i * 120.0, 38.0)))
	_crown(t, Vector3(0, 2.5 * s, 0), 1.25 * s, rng, Color(0.22, 0.42, 0.15), Color(0.48, 0.66, 0.27), 13)
	var apple := Util.mat(Color(0.82, 0.16, 0.13), 0.4)
	for i in 14:
		var a := rng.randf() * TAU
		var o := Vector3(cos(a) * 1.15, rng.randf_range(1.9, 3.0), sin(a) * 1.15) * s
		t.add_child(Util.sphere(0.08 * s, apple, o))
	return t


func _sunflower(p: Vector3, rng: RandomNumberGenerator) -> Node3D:
	var n := Node3D.new()
	n.position = p
	var hgt := rng.randf_range(1.5, 2.0)
	var green := Util.mat(Color(0.35, 0.55, 0.2), 0.9)
	n.add_child(Util.cyl(0.025, 0.035, hgt, green, Vector3(0, hgt / 2.0, 0)))
	for k in 2:
		n.add_child(Util.sphere(0.16, green, Vector3(0.12 * (1 - 2 * k), hgt * (0.45 + 0.2 * k), 0), Vector3(1.2, 0.2, 0.7)))
	var head := Node3D.new()
	head.position = Vector3(0, hgt, 0.04)
	head.rotation_degrees = Vector3(-60, rng.randf_range(-30, 30), 0)
	n.add_child(head)
	head.add_child(Util.cyl(0.24, 0.24, 0.04, Util.mat(Color(1.0, 0.78, 0.12), 0.7), Vector3.ZERO, Vector3(90, 0, 0)))
	head.add_child(Util.cyl(0.13, 0.13, 0.06, Util.mat(Color(0.32, 0.2, 0.1), 0.9), Vector3(0, 0, 0.01), Vector3(90, 0, 0)))
	return n


# ------------------------------------------------------------------ кімната
func _make_room() -> void:
	var W := 7.0
	var D := 5.5
	var H := 3.0
	var floor_sh := Shader.new()
	floor_sh.code = """
shader_type spatial;
render_mode diffuse_lambert;
varying vec3 lp;
void vertex() { lp = VERTEX; }
void fragment() {
	float plank = floor(lp.x * 3.2);
	float r = fract(sin(plank * 12.9898) * 43758.5453);
	float edge = smoothstep(0.0, 0.04, fract(lp.x * 3.2)) * smoothstep(1.0, 0.96, fract(lp.x * 3.2));
	vec3 c = mix(vec3(0.55, 0.36, 0.22), vec3(0.68, 0.47, 0.3), r);
	ALBEDO = c * mix(0.7, 1.0, edge);
	ROUGHNESS = 0.7;
}
"""
	var fm := ShaderMaterial.new()
	fm.shader = floor_sh
	room_root.add_child(Util.box(Vector3(W, 0.1, D), fm, Vector3(0, -0.05, 0)))
	var wall := Util.mat(Color(0.86, 0.83, 0.76), 0.95)
	var band := Util.mat(Color(0.22, 0.36, 0.7), 0.8)
	var red := Util.mat(Color(0.78, 0.2, 0.2), 0.8)
	# задня й бічні стіни (передньої немає — «ляльковий будиночок»)
	room_root.add_child(Util.box(Vector3(W, H, 0.12), wall, Vector3(0, H / 2.0, -D / 2.0)))
	room_root.add_child(Util.box(Vector3(0.12, H, D), wall, Vector3(-W / 2.0, H / 2.0, 0)))
	room_root.add_child(Util.box(Vector3(0.12, H, D), wall, Vector3(W / 2.0, H / 2.0, 0)))
	# синьо-червоний розпис-смужка під стелею, як у хаті
	room_root.add_child(Util.box(Vector3(W, 0.08, 0.02), band, Vector3(0, H - 0.35, -D / 2.0 + 0.07)))
	for i in 18:
		room_root.add_child(Util.sphere(0.06, red if i % 2 == 0 else band, Vector3(-W / 2.0 + 0.3 + i * 0.38, H - 0.22, -D / 2.0 + 0.07), Vector3(1, 1, 0.3)))
	# вікно з видом на поля (шматок денної панорами)
	var win := StandardMaterial3D.new()
	win.albedo_texture = load("res://assets/sky/day.jpg")
	win.uv1_scale = Vector3(0.25, 0.45, 1)
	win.uv1_offset = Vector3(0.36, 0.28, 0)
	win.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	room_root.add_child(Util.box(Vector3(1.6, 1.1, 0.02), win, Vector3(1.2, 1.7, -D / 2.0 + 0.08)))
	var frame := Util.mat(Color(0.25, 0.42, 0.75), 0.6)
	room_root.add_child(Util.box(Vector3(1.75, 0.08, 0.06), frame, Vector3(1.2, 2.27, -D / 2.0 + 0.1)))
	room_root.add_child(Util.box(Vector3(1.75, 0.08, 0.06), frame, Vector3(1.2, 1.13, -D / 2.0 + 0.1)))
	for fx in [0.4, 1.2, 2.0]:
		room_root.add_child(Util.box(Vector3(0.06, 1.2, 0.06), frame, Vector3(fx, 1.7, -D / 2.0 + 0.1)))
	# килим, піч, лавка-диван, столик
	room_root.add_child(Util.cyl(1.4, 1.4, 0.02, Util.mat(Color(0.78, 0.28, 0.25), 0.95), Vector3(0.6, 0.01, 0.3), Vector3.ZERO))
	room_root.add_child(Util.cyl(1.0, 1.0, 0.025, Util.mat(Color(0.95, 0.85, 0.55), 0.95), Vector3(0.6, 0.012, 0.3)))
	var stove := Util.mat(Color(0.88, 0.85, 0.79), 0.95)
	room_root.add_child(Util.box(Vector3(1.6, 1.6, 1.5), stove, Vector3(W / 2.0 - 0.9, 0.8, -D / 2.0 + 0.85)))
	room_root.add_child(Util.box(Vector3(0.7, 0.9, 0.7), stove, Vector3(W / 2.0 - 0.5, 2.05, -D / 2.0 + 0.5)))
	room_root.add_child(Util.cyl(0.25, 0.25, 0.05, Util.mat(Color(0.15, 0.1, 0.08)), Vector3(W / 2.0 - 0.9, 0.55, -D / 2.0 + 1.61), Vector3(90, 0, 0)))
	for i in 5:
		room_root.add_child(Util.sphere(0.07, band if i % 2 == 0 else red, Vector3(W / 2.0 - 1.5 + i * 0.3, 1.25, -D / 2.0 + 1.61), Vector3(1, 1, 0.3)))
	var sofa := Util.mat(Color(0.86, 0.78, 0.62), 0.9)
	room_root.add_child(Util.box(Vector3(2.0, 0.45, 0.8), sofa, Vector3(1.5, 0.22, 1.7)))
	room_root.add_child(Util.box(Vector3(2.0, 0.55, 0.2), sofa, Vector3(1.5, 0.6, 2.05)))
	room_root.add_child(Util.box(Vector3(0.9, 0.06, 0.6), Util.mat(Color(0.55, 0.37, 0.22), 0.7), Vector3(0.6, 0.48, 0.5)))
	room_root.add_child(Util.box(Vector3(0.7, 0.45, 0.4), Util.mat(Color(0.5, 0.33, 0.2), 0.8), Vector3(0.6, 0.22, 0.5)))
	room_root.add_child(Util.pick_area("room_exit", Vector3(1.2, 2.2, 0.4), Vector3(-W / 2.0 + 0.2, 1.1, 1.8)))
	var lawn := Util.box(Vector3(60, 0.02, 60), Util.mat(Color(0.28, 0.45, 0.17), 1.0), Vector3(0, -0.12, 0))
	room_root.add_child(lawn)
	room_light = OmniLight3D.new()
	room_light.light_color = Color(1.0, 0.86, 0.68)
	room_light.omni_range = 9.0
	room_light.position = Vector3(0.4, 2.6, 0.6)
	room_light.shadow_enabled = false
	room_root.add_child(room_light)
	spots["terrarium"] = ROOM + Vector3(-2.0, 0, -1.6)
	spots["room_center"] = ROOM + Vector3(0, 0, 0.6)


func _make_fireflies() -> void:
	fireflies = CPUParticles3D.new()
	fireflies.amount = 50
	fireflies.lifetime = 6.0
	fireflies.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	fireflies.emission_box_extents = Vector3(9, 0.8, 8)
	fireflies.position = Vector3(0, 1.0, -3)
	fireflies.direction = Vector3(0, 1, 0)
	fireflies.spread = 180.0
	fireflies.gravity = Vector3.ZERO
	fireflies.initial_velocity_min = 0.05
	fireflies.initial_velocity_max = 0.25
	var sm := SphereMesh.new()
	sm.radius = 0.035
	sm.height = 0.07
	sm.radial_segments = 6
	sm.rings = 3
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1.0, 0.95, 0.5)
	m.emission_enabled = true
	m.emission = Color(1.0, 0.9, 0.35)
	m.emission_energy_multiplier = 3.0
	sm.material = m
	fireflies.mesh = sm
	fireflies.emitting = false
	yard_root.add_child(fireflies)

extends Node3D
## Віз, який тягне кінь. Стоїть біля стайні. Коли кінь запряжений, віз їде за ним (оглобля до коня).
## На возі сидить дідусь (grandpa.gd: on_tractor = цей вузол), а гравець кермує конем джойстиком.
## Модель (tripo) має оглобельний кінець у бік −Z; SHAFT_YAW повертає модель оглоблею до +Z вузла.
## Якщо віз стоїть оглоблями від коня — змініть SHAFT_YAW на 0.0.

const LENGTH := 3.05                     # довжина воза разом з оглоблями
const BEHIND := 1.9                      # від центру коня до центру воза
const SEAT := Vector3(0, 0.78, 0.35)     # де сидить водій (стегна), у системі воза
const SHAFT_YAW := PI

var model: Node3D
var area: Area3D
var horse: Node3D
var hitched := false
var speed := 0.0
var park_pos := Vector3.ZERO
var park_yaw := PI
var _heading := 0.0
var _bob := 0.0


func setup(at: Vector3, yaw: float) -> void:
	park_pos = at
	park_yaw = yaw
	position = at
	rotation.y = yaw
	model = Models.spawn(self, "cart", LENGTH, "z")
	if model == null:
		return
	model.rotation.y = SHAFT_YAW
	area = Util.pick_area("cart", Vector3(1.8, 1.4, 3.2), Vector3(0, 0.7, 0))
	add_child(area)


func seat_global() -> Vector3:
	return to_global(SEAT)


func hitch_pos() -> Vector3:
	## Де стоїть кінь, коли віз запаркований.
	return park_pos + Vector3(sin(park_yaw), 0, cos(park_yaw)) * BEHIND


func _process(delta: float) -> void:
	if model == null:
		return
	if hitched and horse and is_instance_valid(horse):
		_follow(delta)
	# легке підскакування на ходу
	_bob += delta * 7.0 * clampf(absf(speed), 0.0, 3.0)
	model.position.y = absf(sin(_bob)) * 0.012 * clampf(absf(speed) / 2.0, 0.0, 1.0)


func _follow(dt: float) -> void:
	## Віз тягнеться за конем: оглобля дивиться на коня, центр воза — на відстані BEHIND.
	var hp: Vector3 = horse.global_position
	var to := hp - global_position
	to.y = 0.0
	if to.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(to.x, to.z), 1.0 - exp(-dt * 5.0))
	var p := hp - Vector3(sin(rotation.y), 0, cos(rotation.y)) * BEHIND
	p.y = 0.0
	global_position = p


func bring_horse(h: Node3D) -> void:
	## Кінь іде до воза (обходить його збоку) і стає в оглобли.
	horse = h
	h.hitch_begin()
	var hp := hitch_pos()
	var side := Vector3(cos(park_yaw), 0, -sin(park_yaw)) * 3.0      # збоку від воза (із заходу), щоб не пройти крізь нього
	var way: Array = [park_pos + side + Vector3(sin(park_yaw), 0, cos(park_yaw)) * -3.0,
		park_pos + side + Vector3(sin(park_yaw), 0, cos(park_yaw)) * 2.2, hp]
	for wp in way:
		await _horse_to(wp, 1.5, 0.35, false)
	_heading = park_yaw
	h.hitch_move(park_yaw, 0.0, 0.0)
	hitched = true


func _horse_to(p: Vector3, v: float, reach: float, steer_around := true) -> void:
	## Кінь (із возом, якщо запряжений) іде до точки; обходить перешкоди.
	var t := 0.0
	var h: Node3D = horse
	while t < 70.0 and is_instance_valid(h):
		var dt := get_process_delta_time()
		t += dt
		var hp: Vector3 = h.global_position
		var tgt := Obstacles.steer(hp, p, 1.4, 0.0, Obstacles.all) if steer_around else p
		var to := tgt - hp
		to.y = 0.0
		var d := to.length()
		if (p - hp).length() < reach:
			break
		var hd := lerp_angle(h.rotation.y, atan2(to.x, to.z), 1.0 - exp(-dt * 3.5))
		var sp := minf(v, maxf(0.5, d * 1.2))
		speed = move_toward(speed, sp, dt * 1.5)
		h.hitch_move(hd, speed, dt)
		await get_tree().process_frame
	speed = 0.0


func start_manual() -> void:
	_heading = horse.rotation.y if horse else 0.0
	speed = 0.0


func manual_step(j: Vector2, dt: float) -> void:
	## Щокадру: j.y — вперед (газу назад кінь із возом не має), j.x — поворот.
	if horse == null:
		return
	var vmax := 3.0
	var want := maxf(j.y, 0.0) * vmax
	speed = move_toward(speed, want, dt * 2.0)
	var turn := -j.x * 1.3
	_heading += turn * dt * (0.35 + 0.65 * clampf(speed / 1.5, 0.0, 1.0))
	horse.hitch_move(_heading, speed, dt)
	# обходимо хати, дерева, стайню: виштовхуємо точку посередині між конем і возом
	var hp: Vector3 = horse.global_position
	var mid := hp - Vector3(sin(_heading), 0, cos(_heading)) * 0.9
	var mid2 := Obstacles.push_out(mid, 1.5, 0.0, Obstacles.all)
	if mid2 != mid:
		horse.global_position += mid2 - mid
	var lim: float = 200.0
	horse.global_position.x = clampf(horse.global_position.x, -lim, lim)
	horse.global_position.z = clampf(horse.global_position.z, -lim, lim)


func drive_back() -> void:
	## Гравець віддав віжки: кінь сам везе віз додому до стайні.
	speed = 0.0
	var hp := hitch_pos()
	var south := Vector3(sin(park_yaw + PI), 0, cos(park_yaw + PI))      # звідки заїжджаємо (позаду воза)
	await _horse_to(hp + south * 9.0, 2.2, 1.0)
	await _horse_to(hp, 1.4, 0.4, false)
	horse.hitch_move(park_yaw, 0.0, 0.0)
	await get_tree().process_frame
	# точно ставимо на місце
	var t := 0.0
	while t < 0.8:
		t += get_process_delta_time()
		horse.global_position = horse.global_position.lerp(hp, 0.15)
		horse.rotation.y = lerp_angle(horse.rotation.y, park_yaw, 0.15)
		await get_tree().process_frame
	speed = 0.0


func unhitch() -> void:
	## Кінь відпряжений — до стайні чи на вигін; віз стоїть на своєму місці.
	hitched = false
	speed = 0.0
	position = park_pos
	rotation.y = park_yaw
	if horse and is_instance_valid(horse):
		horse.hitch_release()
	horse = null

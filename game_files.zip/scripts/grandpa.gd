extends Walker
## Дідусь Петро (модель з Meshy, рухи Mixamo: стоїть, іде, біжить, махає, розмовляє,
## сідає/встає, п'є сидячи й стоячи, лягає).
## Порається на подвір'ї: сидить на лавці біля криниці, за столом п'є з глечика, п'є воду біля криниці,
## заходить у хату й сідає в крісло. Увечері сидить у кріслі, вночі спить на дивані.

const HEIGHT := 1.72
# де стегна (кістка Hips) уздовж «вперед» у різних рухах (сантиметри моделі) — щоб перехід
# з одного руху в інший не «стрибав»
const HIPS_IDLE := 5.0
const HIPS_SITANIM_STAND := -24.5     # кінець руху «встає»
const HIPS_SITANIM_SIT := -66.0       # початок руху «встає» (ще сидить)
const HIPS_SIT := 4.6                 # «сидить і п'є»

var busy := false
var idle_left := 4.0
var spots := {}
var world
var talking := false
var at_home := false
var seated := ""                      # на чому сидить ("" — стоїть)
var lying := false
var _act_left := 0.0
var _act_then: Callable
var _k := 0.01                        # метрів на одиницю скелета
var _seat_dy := 0.0

# де можна сісти: [точка (стегна над сидінням), куди дивиться (рад), у хаті?, глечик, підняти/опустити]
var seats := {}


func _ready() -> void:
	var ok := setup_model("grandpa", HEIGHT, {
		"idle": ["idle"], "walk": ["walk"], "run": ["run"], "wave": ["wave"], "talk": ["talk"],
		"sitdrink": ["sit_and_drink"], "stand_up": ["sit_to_stand_transition_m", "sit_to_stand"],
		"drink": ["stand_and_drink"], "lie": ["lie_down"],
	}, ["idle", "walk", "run", "talk", "lie"])
	if not ok:
		add_child(Util.capsule(0.25, 1.5, Util.mat(Color(0.95, 0.95, 0.92)), Vector3(0, 0.85, 0)))
		add_child(Util.sphere(0.17, Util.mat(Color(0.95, 0.78, 0.65)), Vector3(0, 1.62, 0)))
	else:
		setup_pose()
		var sks := model.find_children("*", "Skeleton3D", true, false)
		if sks.size() > 0:
			_k = (sks[0] as Skeleton3D).global_transform.basis.get_scale().x
	walk_speed = 1.0
	run_speed = 2.6
	setup_common("grandpa", Vector3(0.7, 1.8, 0.6), 2.15, 0.45)
	play("idle")


func setup_seats() -> void:
	var R: Vector3 = world.ROOM
	seats = {
		"bench": [Vector3(4.35, 0, -6.35), 0.0, false, null, -0.04],
		"table": [Vector3(5.0, 0, 1.12), 0.0, false, _jug("jug"), 0.07],
		"rocking": [Vector3(2.1, 0, -6.95), deg_to_rad(10.0), false, null, 0.0],
		"armchair": [R + Vector3(-1.37, 0, 0.79), deg_to_rad(130.0), true, _jug("room_jug"), 0.16],
	}
	_make_blanket()


func _jug(key: String) -> Node3D:
	var arr: Array = world.props.get(key, [])
	if arr.is_empty():
		return null
	var j: Node3D = arr[0]
	Walker.remember_home(j)
	return j


func _process(delta: float) -> void:
	_physics_step(delta)
	if _act_left > 0.0:
		_act_left -= delta
		if _act_left <= 0.0:
			busy = false
			var cb := _act_then
			_act_then = Callable()
			if cb.is_valid():
				cb.call()
	_update_book(delta)
	if seated != "" or lying:
		if doing == "" and not talking:
			idle_left -= delta
			if idle_left <= 0.0:
				idle_left = randf_range(3.0, 7.0)
				_daily_routine()
		return
	if moving:
		play("run" if running else "walk")
		return
	if talking:
		play("talk")
		return
	if busy or doing != "":
		return
	play("idle")
	idle_left -= delta
	if idle_left > 0.0:
		return
	idle_left = randf_range(3.0, 7.0)
	_daily_routine()


func sitting() -> bool:
	return seated != ""


# ------------------------------------------------------------------ розпорядок дня
func _daily_routine() -> void:
	var h := Game.hour()
	var bedtime := h >= 21.0 or h < 6.0 or bed_now
	if seated != "":
		if bedtime and seated == "armchair":
			sleep_job()
		elif not Game.is_night() or seated != "armchair":
			var id := begin_job("stand")
			await stand_up()
			end_job(id)
		return
	if bedtime or Game.is_night():
		if not at_home:
			go_home_and_sit()
		elif bedtime:
			sleep_job()
		else:
			sit_job("armchair", 30.0)
		return
	if at_home:
		if randf() < 0.3:
			sit_job("armchair", randf_range(15.0, 30.0))
		else:
			go_out()
		return
	if _wants_eggs():
		eggs_job()
		return
	var r := randf()
	if r < 0.16:
		inspect_job()
	elif r < 0.3:
		sit_job("bench", randf_range(15.0, 28.0))
	elif r < 0.42:
		sit_job("table", randf_range(15.0, 25.0))
	elif r < 0.5:
		sit_job("rocking", randf_range(12.0, 20.0))
	elif r < 0.58:
		go_home_and_sit()
	elif r < 0.68:
		well_drink_job()
	elif r < 0.76 and Game.hour() > 12.0 and Game.hour() < 17.0:
		nap_job()
	else:
		var choices := ["well", "garden", "porch", "coop", "gate"]
		walk_to(spots[choices[randi() % choices.size()]] + Vector3(randf_range(-0.6, 0.6), 0, 0.9))


func _enter_house() -> void:
	## Через двері — у кімнату (кімната стоїть окремо, тож переносимося до дверей зсередини).
	var R: Vector3 = world.ROOM
	at_home = true
	bounds = Rect2(R.x - 3.2, R.z - 2.4, 6.4, 5.6)
	position = spots["room_door"]
	rotation.y = PI
	_door_sound("door_close")


func _leave_house() -> void:
	at_home = false
	bounds = Rect2(-20.5, -14.5, 29.0, 19.0)
	position = spots["door"]
	rotation.y = 0.0
	_door_sound("door_open")


func _door_sound(id: String) -> void:
	var au = get_node_or_null("/root/Main/Audio")
	if au and Game.state["location"] == "yard":
		au.play_at(id, self, -8.0)


func _walk_in(id: int) -> bool:
	## Подвір'я → хата: двері відчиняються, заходить, двері зачиняються.
	var w = world
	await go(spots["door"])
	if id != job:
		return false
	_face_to = PI
	w.set_door("house", true)
	await wait(0.6)
	if id != job:
		w.set_door("house", false)
		return false
	await go(spots["door"] + Vector3(0.1, 0, -1.0), false, false)
	w.set_door("house", false, 0.4)
	_enter_house()
	position = spots["room_door"] + Vector3(0, 0, 0.9)
	w.set_door("room", true, 0.4)
	await wait(0.3)
	await go(spots["room_door"] + Vector3(0.3, 0, -0.5), false, false)
	w.set_door("room", false)
	return id == job


func _walk_out(id: int) -> bool:
	## Хата → подвір'я.
	var w = world
	await go(spots["room_door"] + Vector3(0, 0, -0.3))
	if id != job:
		return false
	_face_to = 0.0
	w.set_door("room", true)
	await wait(0.6)
	if id != job:
		w.set_door("room", false)
		return false
	await go(spots["room_door"] + Vector3(0, 0, 0.9), false, false)
	w.set_door("room", false, 0.4)
	_leave_house()
	position = spots["door"] + Vector3(0.1, 0, -1.0)
	rotation.y = 0.0
	w.set_door("house", true, 0.4)
	await wait(0.3)
	await go(spots["door"] + Vector3(0, 0, 0.4), false, false)
	w.set_door("house", false)
	return id == job


func go_home_and_sit() -> void:
	var id := begin_job("home")
	if not at_home:
		if not await _walk_in(id):
			return
	end_job(id)
	sit_job("armchair", 30.0 if Game.is_night() else randf_range(20.0, 40.0))


func go_out() -> void:
	var id := begin_job("out")
	if not await _walk_out(id):
		return
	await go(spots["porch"] + Vector3(randf_range(-0.8, 0.8), 0, 0.8))
	end_job(id)


func command_in() -> void:
	## Команда «Дідусю, ходи в хату».
	if at_home:
		say("Я вже в хаті!", 2.0)
		return
	say("Іду, іду!", 2.0)
	if seated != "":
		var id0 := begin_job("stand")
		await stand_up()
		end_job(id0)
	if lying:
		lying = false
		current = ""
		play("idle")
	go_home_and_sit()


func command_out() -> void:
	if not at_home:
		say("Я й так на подвір'ї!", 2.0)
		return
	say("Вже виходжу!", 2.0)
	if seated != "":
		var id0 := begin_job("stand")
		await stand_up()
		end_job(id0)
	if lying:
		lying = false
		model.position.y = _base_y
		current = ""
		play("idle")
	go_out()


# ------------------------------------------------------------------ обхід господарства
const INSPECT := [
	["coop", "Кури здорові, слава Богу.", "Курочки вже в курнику. Добре."],
	["well", "Вода в криниці чиста, холодна.", ""],
	["barn", "Сіна в сараї вистачить на всю зиму.", ""],
	["workshop", "Треба б граблі полагодити…", ""],
	["field_gate", "Ох, і гарні ж соняшники ростуть!", "Город просить води — хай дрон поллє."],
	["doghouse", "Будка ціла, Бімові тепло.", ""],
	["garden", "Гарбузики наливаються.", ""],
]


func inspect_job() -> void:
	## Дідусь обходить своє господарство: 3–4 місця, біля кожного зупиняється й щось каже.
	var id := begin_job("inspect")
	var list: Array = INSPECT.duplicate()
	list.shuffle()
	for i in mini(4, list.size()):
		var it: Array = list[i]
		var key: String = it[0]
		var p: Vector3
		match key:
			"field_gate":
				p = Vector3(8.0, 0, -4.5)
			"doghouse":
				p = spots["doghouse"] + Vector3(0.8, 0, 1.4)
			_:
				if not spots.has(key):
					continue
				p = spots[key]
		await go(p + Vector3(randf_range(-0.4, 0.4), 0, randf_range(-0.4, 0.4)))
		if id != job:
			return
		var txt: String = it[1]
		if key == "field_gate" and float(Game.state["field"]["water"]) < 30.0:
			txt = it[2]
		if key == "coop" and Game.is_night():
			txt = it[2]
		say(txt, 3.0)
		await wait(3.2)
		if id != job:
			return
	end_job(id)


# ------------------------------------------------------------------ яйця з ґанку — у хату
func _wants_eggs() -> bool:
	var g = world.get_node_or_null("/root/Main").get("gvintyk")
	return g != null and g.porch_basket != null and g.porch_basket.visible and g.doing == ""


func eggs_job() -> void:
	## Гвинтик приніс кошик яєць на ґанок — дідусь забирає й заносить у хату.
	var g = world.get_node("/root/Main").get("gvintyk")
	var b: Node3D = g.porch_basket
	var id := begin_job("eggs")
	say("О, Гвинтик яєць приніс!", 2.5)
	await go(b.global_position + Vector3(0.3, 0, 0.55))
	if id != job:
		return
	face(b.global_position)
	await wait(0.6)
	Walker.remember_home(b)
	hold_upright(b, 0.2, false, 0.08)
	if not await _walk_in(id):
		return
	await go(world.ROOM + Vector3(-2.6, 0, 1.5))
	if id != job:
		return
	# ставить кошик на скриню
	drop()
	world.room_root.add_child(b)
	b.position = Vector3(-3.0, 0.62, 2.0)
	b.rotation = Vector3.ZERO
	b.set_meta("home_parent", null)
	say("Будуть млинці!", 2.0)
	# порожній кошик для Гвинтика знову на ґанку (з'явиться завтра)
	g.porch_basket = g._basket(true)
	world.yard_root.add_child(g.porch_basket)
	g.porch_basket.position = spots["porch"] + Vector3(1.0, 0, -0.5)
	g.porch_basket.visible = false
	if is_instance_valid(_room_eggs):
		_room_eggs.queue_free()
	_room_eggs = b
	end_job(id)


var _room_eggs: Node3D


# ------------------------------------------------------------------ сісти / встати
func _fwd(yaw: float) -> Vector3:
	return Vector3(sin(yaw), 0, cos(yaw))


func sit_job(seat: String, secs := 25.0) -> void:
	## Підійти, сісти; за столом і в кріслі — попити з глечика; посидіти й устати.
	var s: Array = seats.get(seat, [])
	if s.is_empty() or (bool(s[2]) != at_home) or seated != "":
		return
	var id := begin_job("sit_" + seat)
	var seat_p: Vector3 = s[0]
	var yaw := float(s[1])
	# сідаючи, він відступає назад — тож стати треба трохи попереду сидіння
	var back := (HIPS_SIT + HIPS_SITANIM_STAND - HIPS_IDLE - HIPS_SITANIM_SIT) * _k
	var stand_p := seat_p + _fwd(yaw) * back
	# підходить збоку (щоб не йти крізь стіл чи лавку), останній крок — без обходу перешкод
	var side := Vector3(cos(yaw), 0, -sin(yaw))
	if (position - stand_p).dot(side) < 0.0:
		side = -side
	await go(stand_p + side * 0.75 + _fwd(yaw) * 0.15)
	if id != job:
		return
	await go(stand_p, false, false)
	if id != job:
		return
	_face_to = yaw
	await wait(0.7)
	if id != job:
		return
	rotation.y = yaw
	await _sit_down(seat, seat_p, float(s[4]))
	if id != job:
		return
	var jug: Node3D = s[3]
	var left := secs
	while left > 0.0:
		var chunk := minf(left, randf_range(5.0, 9.0))
		await wait(chunk)
		left -= chunk
		if id != job or seated == "":
			return
		if jug and randf() < 0.6 and is_instance_valid(jug) and jug.get_parent() == jug.get_meta("home_parent", null):
			await _drink_seated(jug, id)
			if id != job:
				return
	if Game.is_night() and seat == "armchair":
		end_job(id)
		return              # увечері лишається в кріслі (встане, коли час спати)
	await stand_up()
	end_job(id)


func _sit_down(seat: String, seat_p: Vector3, dy: float) -> void:
	## Рух «встає», програний навпаки = сідає. Модель зсунута так, щоб початок руху збігся з тим, як він стоїть.
	seated = seat
	if ap == null or anims.get("stand_up", "") == "":
		position = seat_p
		return
	var n: String = anims["stand_up"]
	model.position.z = (HIPS_IDLE - HIPS_SITANIM_STAND) * _k
	current = "stand_up"
	ap.play_backwards(n, 0.2)
	ap.speed_scale = 1.35
	var len := ap.get_animation(n).length / 1.35
	var t := 0.0
	while t < len:
		t += get_process_delta_time()
		model.position.y = _base_y + dy * clampf(t / len, 0.0, 1.0)
		await get_tree().process_frame
	# тепер сидить: переходимо на «сидить і п'є» (перший кадр) без змішування
	position = seat_p
	model.position = Vector3(0, _base_y + dy, 0)
	_seat_dy = dy
	_sit_still()


func _sit_still() -> void:
	var n: String = anims.get("sitdrink", "")
	if n == "":
		return
	current = "sitdrink"
	ap.speed_scale = 1.0
	ap.play(n, 0.0)
	ap.seek(0.0, true)
	ap.pause()


func stand_up() -> void:
	if seated == "":
		return
	put_back_held()
	var yaw := rotation.y
	var n: String = anims.get("stand_up", "")
	if n == "":
		seated = ""
		play("idle")
		return
	model.position.z = (HIPS_SIT - HIPS_SITANIM_SIT) * _k
	current = "stand_up"
	ap.play(n, 0.0)
	ap.speed_scale = 1.35
	var len := ap.get_animation(n).length / 1.35
	var t := 0.0
	while t < len - 0.05:
		t += get_process_delta_time()
		model.position.y = _base_y + _seat_dy * (1.0 - clampf(t / len, 0.0, 1.0))
		await get_tree().process_frame
	position += _fwd(yaw) * (HIPS_SIT - HIPS_SITANIM_SIT + HIPS_SITANIM_STAND - HIPS_IDLE) * _k
	model.position = Vector3(0, _base_y, 0)
	_seat_dy = 0.0
	seated = ""
	current = ""
	ap.speed_scale = 1.0
	play("idle")
	# якщо встав «у» стіл чи лавку — відступає вбік
	var out := Obstacles.push_out(position, me_r)
	if out.distance_to(position) > 0.02:
		var dir := (out - position).normalized()
		await go(out + dir * 0.15, false, false)


func _drink_seated(jug: Node3D, id: int) -> void:
	## «Сидить і п'є»: глечик переходить у праву руку, поки він п'є, а потім — на своє місце.
	var n: String = anims.get("sitdrink", "")
	if n == "" or hand == null:
		return
	current = "sitdrink"
	ap.play(n, 0.0)
	ap.seek(0.0, true)
	ap.speed_scale = 1.0
	var len := ap.get_animation(n).length
	var took := false
	var t := 0.0
	while t < len:
		t += get_process_delta_time()
		if id != job:
			break
		if not took and t > 2.4:
			took = true
			hold_upright(jug, 0.2)
		if took and held and t > 8.6:
			put_back_held()
		await get_tree().process_frame
	put_back_held()
	if id == job and seated != "":
		say("Ох, і смачний узвар!", 2.5)
		_sit_still()


func well_drink_job() -> void:
	## Біля криниці: набирає кухоль води й п'є стоячи.
	var id := begin_job("well_drink")
	await go(spots["well_front"] + Vector3(-0.2, 0, 0.2))
	if id != job:
		return
	face(spots["well"])
	await wait(0.5)
	if id != job:
		return
	await world.well_draw()
	if id != job:
		return
	var n: String = anims.get("drink", "")
	if n == "":
		end_job(id)
		return
	current = "drink"
	ap.play(n, 0.3)
	var mug: Node3D = Models.spawn(world.yard_root, "cup", 0.11) if Models.exists("cup") else null      # червона глиняна чашка
	if mug:
		world.yard_root.remove_child(mug)
	else:
		mug = Util.cyl(0.045, 0.04, 0.1, Util.mat(Color(0.75, 0.45, 0.25), 0.6))
	var len := ap.get_animation(n).length
	var t := 0.0
	var took := false
	while t < len:
		t += get_process_delta_time()
		if id != job:
			break
		if not took and t > 1.2:
			took = true
			world.yard_root.add_child(mug)
			hold_upright(mug, 0.06, true)
		await get_tree().process_frame
	var m := drop()
	if m:
		m.queue_free()
	elif not took:
		mug.queue_free()
	if id == job:
		say("Ох, і смачна в нас вода!", 2.5)
	current = ""
	play("idle")
	end_job(id)


# ------------------------------------------------------------------ сон і відпочинок
var blanket: Node3D


func _make_blanket() -> void:
	## Ряднина під старою грушею — дідусь іноді лягає на ній подрімати.
	blanket = Node3D.new()
	blanket.position = Vector3(-6.4, 0, -7.3)
	blanket.rotation.y = deg_to_rad(-35.0)
	world.yard_root.add_child(blanket)
	var a := Util.mat(Color(0.75, 0.2, 0.18), 0.95)
	var b := Util.mat(Color(0.95, 0.88, 0.7), 0.95)
	for k in 6:
		var stripe := Util.box(Vector3(0.95, 0.012, 0.32), a if k % 2 == 0 else b, Vector3(0, 0.008, -0.8 + k * 0.32))
		stripe.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		blanket.add_child(stripe)


var _plaid: Node3D


func cover(on: bool) -> void:
	## Плед на колінах (його вкриває Beep, коли дідусь дрімає в кріслі).
	if on and _plaid == null:
		_plaid = Node3D.new()
		add_child(_plaid)
		var red := Util.mat(Color(0.72, 0.18, 0.16), 0.95)
		var stripe := Util.mat(Color(0.95, 0.85, 0.55), 0.95)
		if lying:
			# лежить у ліжку — ковдра від грудей до ніг, краї звисають з боків
			var cy := _base_y + LIE_Y + 0.09
			_plaid.add_child(Util.box(Vector3(0.9, 0.05, 1.1), red, Vector3(0, cy, 0.3)))
			for k in [-0.05, 0.35, 0.75]:
				_plaid.add_child(Util.box(Vector3(0.91, 0.052, 0.06), stripe, Vector3(0, cy, k)))
			for sx in [-0.45, 0.45]:
				_plaid.add_child(Util.box(Vector3(0.04, 0.22, 1.1), red, Vector3(sx, cy - 0.1, 0.3)))
			_plaid.scale = Vector3(1.0, 0.1, 1.0)
			create_tween().tween_property(_plaid, "scale", Vector3.ONE, 0.7).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			return
		var p := Util.box(Vector3(0.62, 0.05, 0.62), red, Vector3(0, 0.66, 0.2))
		p.rotation.x = deg_to_rad(-12)
		_plaid.add_child(p)
		for k in [-0.18, 0.18]:
			var st := Util.box(Vector3(0.63, 0.052, 0.05), stripe, Vector3(0, 0.661, 0.2 + k))
			st.rotation.x = deg_to_rad(-12)
			_plaid.add_child(st)
		var hang := Util.box(Vector3(0.62, 0.42, 0.04), red, Vector3(0, 0.45, 0.5))
		_plaid.add_child(hang)
		_plaid.scale = Vector3(0.1, 0.1, 0.1)
		create_tween().tween_property(_plaid, "scale", Vector3.ONE, 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	elif not on and _plaid:
		_plaid.queue_free()
		_plaid = null


var LIE_YAW := 0.0    # (налаштування пози на ліжку: головою до подушки)
var LIE_OFF := Vector3(0, 0, -0.2)
var LIE_Y := 0.78


var _lie_t := -1.0
var book: Node3D
var _book_k := 0.0
var _page: Node3D
var _page_t := 0.0
var bed_now := false               # «лягай спати» за командою — спить до ранку


func _make_book() -> void:
	## Книжка: червона палітурка, розгорнута, дві сторінки; сторінки час від часу перегортаються.
	book = Node3D.new()
	world.room_root.add_child(book)
	var cover := Util.mat(Color(0.62, 0.16, 0.14), 0.7)
	var paper := Util.mat(Color(0.97, 0.94, 0.85), 0.9)
	var lines := Util.mat(Color(0.55, 0.5, 0.45), 0.9)
	for sx in [-1.0, 1.0]:
		var half := Node3D.new()
		half.rotation.z = sx * deg_to_rad(-14.0)
		book.add_child(half)
		half.add_child(Util.box(Vector3(0.13, 0.008, 0.18), cover, Vector3(sx * 0.066, 0, 0)))
		half.add_child(Util.box(Vector3(0.12, 0.016, 0.17), paper, Vector3(sx * 0.062, 0.012, 0)))
		for k in 6:
			half.add_child(Util.box(Vector3(0.085, 0.002, 0.006), lines, Vector3(sx * 0.064, 0.021, -0.055 + k * 0.022)))
	_page = Node3D.new()
	book.add_child(_page)
	var pg := Util.box(Vector3(0.12, 0.003, 0.17), paper, Vector3(0.062, 0.022, 0))
	_page.add_child(pg)
	_page.visible = false
	book.visible = false


func _update_book(delta: float) -> void:
	## Сидячи в кріслі вдома (і не спить) — читає книжку: тримає її на колінах перед собою.
	var reading := seated == "armchair" and doing != "sleep" and not lying and hand != null and hand_l != null
	_book_k = move_toward(_book_k, 1.0 if reading else 0.0, delta * 1.5)
	if _book_k <= 0.001:
		if book:
			book.visible = false
		return
	if book == null:
		_make_book()
	book.visible = true
	var f := Vector3(sin(rotation.y), 0, cos(rotation.y))
	var mid := (hand.global_position + hand_l.global_position) * 0.5 + f * 0.1 + Vector3(0, 0.13, 0)
	var x := Vector3(cos(rotation.y), 0, -sin(rotation.y))
	# сторінки нахилені до обличчя
	var tilt := Basis(x, deg_to_rad(-50.0))
	book.global_transform = Transform3D(tilt * Basis(Vector3.UP, rotation.y + PI), mid)
	book.scale = Vector3.ONE * (0.6 + 0.4 * _book_k)
	# перегортає сторінку
	_page_t -= delta
	if _page_t <= 0.0:
		_page_t = randf_range(6.0, 11.0)
		_page.visible = true
		_page.rotation.z = 0.0
		var tw := create_tween()
		tw.tween_property(_page, "rotation:z", PI, 0.7).set_trans(Tween.TRANS_SINE)
		tw.tween_callback(func(): _page.visible = false)


func command_bed() -> void:
	## Beep попросив: «Дідусю, лягай спати».
	if lying:
		say("Я вже сплю… z-z-z", 2.0)
		return
	if not at_home:
		say("Іду вже, іду спати!", 2.0)
	bed_now = true
	cancel_job()
	if not at_home:
		var id := begin_job("in")
		if not await _walk_in(id):
			return
		end_job(id)
	sleep_job()


func _lie_time() -> float:
	if _lie_t >= 0.0:
		return _lie_t
	var la: Animation = ap.get_animation(anims["lie"])
	_lie_t = la.length * 0.5
	var sks := model.find_children("*", "Skeleton3D", true, false)
	if sks.is_empty():
		return _lie_t
	var sk: Skeleton3D = sks[0]
	var hb: int = pose.find(sk, "Head") if pose else -1
	if hb < 0:
		return _lie_t
	var best := INF
	ap.play(anims["lie"], 0.0)
	for i in 40:
		var t := la.length * i / 40.0
		ap.seek(t, true)
		var y := sk.get_bone_global_pose(hb).origin.y
		if y < best - 0.0001:
			best = y
			_lie_t = t
	# трохи пізніше за найнижчу точку — коли вже спокійно лежить
	return _lie_t


func sleep_job() -> void:
	## Уночі спить у ліжку (якщо ліжка немає — дрімає в кріслі).
	var bed = world.spots.get("bed", null)
	if bed == null or anims.get("lie", "") == "":
		if seated != "armchair":
			sit_job("armchair", 1e9)
			return
		var id0 := begin_job("sleep")
		while id0 == job and (Game.hour() >= 21.0 or Game.hour() < 6.5):
			say("Хр-р-р… z-z-z", 2.5)
			await wait(6.0)
		if id0 != job:
			return
		cover(false)
		await stand_up()
		say("Доброго ранку!", 2.5)
		end_job(id0)
		return
	var id := begin_job("sleep")
	if seated != "":
		await stand_up()
		if id != job:
			return
	var bp: Vector3 = bed
	var side := bp + Vector3(-0.95, 0, 0.15)
	say("Пора спати…", 2.0)
	await go(side, false, false)
	if id != job:
		return
	face(bp)
	await wait(0.5)
	if id != job:
		return
	lying = true
	current = "lie"
	position = bp + LIE_OFF
	rotation.y = LIE_YAW
	_face_to = LIE_YAW
	model.position.y = _base_y + LIE_Y
	# одразу поза «лежить» (момент анімації, де голова найнижче) і тримаємо її
	var lt := _lie_time()
	ap.play(anims["lie"], 0.2)
	ap.seek(lt, true)
	ap.speed_scale = 0.0
	while id == job and (bed_now or Game.hour() >= 21.0 or Game.hour() < 6.5):
		if randf() < 0.6:
			say("Хр-р-р… z-z-z", 2.5)
		await wait(6.0)
	lying = false
	bed_now = false
	ap.speed_scale = 1.0
	model.position.y = _base_y
	if id != job:
		cover(false)
		return
	cover(false)
	position = side
	current = ""
	play("idle")
	say("Доброго ранку!", 2.5)
	end_job(id)


func nap_job() -> void:
	## Удень: лягає на ряднину під деревом і дрімає.
	if blanket == null or anims.get("lie", "") == "":
		return
	var id := begin_job("nap")
	var yaw := blanket.rotation.y + PI
	var f := _fwd(yaw)
	var spot := blanket.position - f * 0.22       # голова — до дерева
	await go(spot + f * 1.4)
	if id != job:
		return
	await go(spot + f * 0.5)
	if id != job:
		return
	_face_to = yaw
	await wait(0.6)
	lying = true
	position = spot
	rotation.y = yaw
	current = "lie"
	ap.play(anims["lie"], 1.0)
	say("Подрімаю трішки…", 2.5)
	var t := randf_range(20.0, 35.0)
	while t > 0.0 and id == job:
		await wait(5.0)
		t -= 5.0
		if randf() < 0.6:
			say("z-z-z", 2.0)
	lying = false
	if id != job:
		return
	position = spot + f * 0.5
	current = ""
	ap.play(anims["idle"], 1.0)
	end_job(id)


# ------------------------------------------------------------------ з гравцем
func wave_at(p: Vector3) -> void:
	if seated != "" or lying:
		say("Привіт, Beep!", 2.0)
		return
	stop()
	face(p)
	busy = true
	play("wave")
	_act_left = anim_length("wave")
	_act_then = Callable()


func start_talk(p: Vector3) -> void:
	if seated == "" and not lying:
		cancel_job()
		face(p)
		talking = true
	busy = false


func end_talk() -> void:
	talking = false
	idle_left = randf_range(3.0, 6.0)


func test(what: String) -> void:
	## Для перевірки в demo: call:grandpa:test:drink|bench|armchair|sleep|well
	match what:
		"drink":
			await sit_job("table", 0.1)
		"bench":
			sit_job("bench", 60.0)
		"armchair":
			_enter_house()
			sit_job("armchair", 60.0)
		"nap":
			nap_job()
		"sleep":
			_enter_house()
			sleep_job()
		"lie":
			# перевірка пози на ліжку без ходьби
			_enter_house()
			var bp: Vector3 = world.spots["bed"]
			lying = true
			current = "lie"
			ap.play(anims["lie"], 0.0)
			position = bp + LIE_OFF
			rotation.y = LIE_YAW
			model.position.y = _base_y + LIE_Y
		"well":
			well_drink_job()
		"sitdrink":
			var id := begin_job("t")
			var s: Array = seats["table"]
			position = s[0]
			rotation.y = 0.0
			seated = "table"
			model.position = Vector3(0, _base_y - 0.02, 0)
			await _drink_seated(s[3], id)

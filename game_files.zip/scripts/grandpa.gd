extends Walker
## Дідусь Петро (модель з Meshy: стоїть, іде, біжить, махає рукою, розмовляє).
## Порається на подвір'ї, вітається, розповідає завдання; увечері йде в хату, зранку виходить.

const HEIGHT := 1.72

var busy := false
var idle_left := 4.0
var spots := {}
var talking := false
var at_home := false
var _act_left := 0.0
var _act_then: Callable


func _ready() -> void:
	var ok := setup_model("grandpa", HEIGHT, {
		"idle": ["idle"], "walk": ["walk"], "run": ["run"], "wave": ["wave"], "talk": ["talk"],
	}, ["idle", "walk", "run", "talk"])
	if not ok:
		add_child(Util.capsule(0.25, 1.5, Util.mat(Color(0.95, 0.95, 0.92)), Vector3(0, 0.85, 0)))
		add_child(Util.sphere(0.17, Util.mat(Color(0.95, 0.78, 0.65)), Vector3(0, 1.62, 0)))
	walk_speed = 1.0
	run_speed = 2.6
	setup_common("grandpa", Vector3(0.7, 1.8, 0.6), 2.15, 0.45)
	play("idle")


func _process(delta: float) -> void:
	_physics_step(delta)
	if _act_left > 0.0:
		_act_left -= delta
		if _act_left <= 0.0:
			busy = false
			var cb := _act_then
			_act_then = Callable()
			if cb.is_valid():
				cb.call()
	if moving:
		play("run" if running else "walk")
		return
	if talking:
		play("talk")
		return
	if busy:
		return
	play("idle")
	idle_left -= delta
	if idle_left > 0.0:
		return
	idle_left = randf_range(6.0, 12.0)
	_daily_routine()


func _daily_routine() -> void:
	if Game.is_night():
		if not at_home:
			walk_to(spots["door"], false, func():
				at_home = true
				visible = false
				area.input_ray_pickable = false)
		return
	if at_home:
		at_home = false
		visible = true
		area.input_ray_pickable = true
		position = spots["door"]
	var choices := ["bench", "well", "garden", "porch"]
	walk_to(spots[choices[randi() % choices.size()]] + Vector3(randf_range(-0.6, 0.6), 0, 0.9))


func wave_at(p: Vector3) -> void:
	stop()
	face(p)
	busy = true
	play("wave")
	_act_left = anim_length("wave")
	_act_then = Callable()


func start_talk(p: Vector3) -> void:
	stop()
	busy = false
	face(p)
	talking = true


func end_talk() -> void:
	talking = false
	idle_left = randf_range(3.0, 6.0)

extends Walker
## Дідусь Петро (модель з Meshy, рухи Mixamo: стоїть, іде, біжить, махає, розмовляє,
## сідає/встає, п'є сидячи й стоячи, лягає).
## Порається на подвір'ї: сидить на лавці біля криниці, за столом п'є з глечика, п'є воду біля криниці,
## заходить у хату й сідає в крісло. Увечері сидить у кріслі, вночі спить на дивані.

const HEIGHT := 1.72
# де стегна (кістка Hips) уздовж «вперед» у різних рухах (сантиметри моделі) — щоб перехід
# з одного руху в інший не «стрибав»
const HIPS_IDLE := 5.0
const HIPS_SITANIM_STAND := -24.5     # кінець руху «встає»
const HIPS_SITANIM_SIT := -66.0       # початок руху «встає» (ще сидить)
const HIPS_SIT := 4.6                 # «сидить і п'є»

var busy := false
var idle_left := 4.0
var spots := {}
var world
var talking := false
var at_home := false
var seated := ""                      # на чому сидить ("" — стоїть)
var lying := false
var _act_left := 0.0
var _act_then: Callable
var _k := 0.01                        # метрів на одиницю скелета
var _seat_dy := 0.0

# де можна сісти: [точка (стегна над сидінням), куди дивиться (рад), у хаті?, глечик, підняти/опустити]
var seats := {}


func _ready() -> void:
	var ok := setup_model("grandpa", HEIGHT, {
		"idle": ["idle"], "walk": ["walk"], "run": ["run"], "wave": ["wave"], "talk": ["talk"],
		"sitdrink": ["sit_and_drink"], "stand_up": ["sit_to_stand_transition_m", "sit_to_stand"],
		"drink": ["stand_and_drink"], "lie": ["lie_down"],
	}, ["idle", "walk", "run", "talk", "lie"])
	if not ok:
		add_child(Util.capsule(0.25, 1.5, Util.mat(Color(0.95, 0.95, 0.92)), Vector3(0, 0.85, 0)))
		add_child(Util.sphere(0.17, Util.mat(Color(0.95, 0.78, 0.65)), Vector3(0, 1.62, 0)))
	else:
		setup_pose()
		var sks := model.find_children("*", "Skeleton3D", true, false)
		if sks.size() > 0:
			_k = (sks[0] as Skeleton3D).global_transform.basis.get_scale().x
	walk_speed = 1.0
	run_speed = 2.6
	setup_common("grandpa", Vector3(0.7, 1.8, 0.6), 2.15, 0.45)
	play("idle")


func setup_seats() -> void:
	var R: Vector3 = world.ROOM
	seats = {
		"bench": [Vector3(4.35, 0, -6.35), 0.0, false, null, -0.04],
		"table": [Vector3(5.0, 0, 1.45), 0.0, false, _jug("jug"), -0.02],
		"rocking": [Vector3(2.1, 0, -6.95), deg_to_rad(10.0), false, null, 0.0],
		"armchair": [R + Vector3(-1.37, 0, 0.79), deg_to_rad(130.0), true, _jug("room_jug"), 0.16],
	}
	_make_blanket()


func _jug(key: String) -> Node3D:
	var arr: Array = world.props.get(key, [])
	if arr.is_empty():
		return null
	var j: Node3D = arr[0]
	Walker.remember_home(j)
	return j


func _process(delta: float) -> void:
	_physics_step(delta)
	if _act_left > 0.0:
		_act_left -= delta
		if _act_left <= 0.0:
			busy = false
			var cb := _act_then
			_act_then = Callable()
			if cb.is_valid():
				cb.call()
	if seated != "" or lying:
		return
	if moving:
		play("run" if running else "walk")
		return
	if talking:
		play("talk")
		return
	if busy or doing != "":
		return
	play("idle")
	idle_left -= delta
	if idle_left > 0.0:
		return
	idle_left = randf_range(3.0, 7.0)
	_daily_routine()


func sitting() -> bool:
	return seated != ""


# ------------------------------------------------------------------ розпорядок дня
func _daily_routine() -> void:
	var h := Game.hour()
	var bedtime := h >= 21.0 or h < 6.0
	if seated != "":
		if bedtime or not Game.is_night():
			var id := begin_job("stand")
			await stand_up()
			end_job(id)
		return
	if bedtime or Game.is_night():
		if not at_home:
			go_home_and_sit()
		elif bedtime:
			sleep_job()
		else:
			sit_job("armchair", 30.0)
		return
	if at_home:
		if randf() < 0.3:
			sit_job("armchair", randf_range(15.0, 30.0))
		else:
			go_out()
		return
	var r := randf()
	if r < 0.2:
		sit_job("bench", randf_range(15.0, 28.0))
	elif r < 0.4:
		sit_job("table", randf_range(15.0, 25.0))
	elif r < 0.48:
		sit_job("rocking", randf_range(12.0, 20.0))
	elif r < 0.58:
		go_home_and_sit()
	elif r < 0.68:
		well_drink_job()
	elif r < 0.75 and Game.hour() > 12.0 and Game.hour() < 17.0:
		nap_job()
	else:
		var choices := ["well", "garden", "porch", "coop", "gate"]
		walk_to(spots[choices[randi() % choices.size()]] + Vector3(randf_range(-0.6, 0.6), 0, 0.9))


func _enter_house() -> void:
	## Через двері — у кімнату (кімната стоїть окремо, тож переносимося до дверей зсередини).
	var R: Vector3 = world.ROOM
	at_home = true
	bounds = Rect2(R.x - 3.2, R.z - 2.4, 6.4, 4.8)
	position = spots["room_door"]
	rotation.y = PI
	_door_sound("door_close")


func _leave_house() -> void:
	at_home = false
	bounds = Rect2(-8.5, -11.5, 17.0, 16.0)
	position = spots["door"]
	rotation.y = 0.0
	_door_sound("door_open")


func _door_sound(id: String) -> void:
	var au = get_node_or_null("/root/Main/Audio")
	if au and Game.state["location"] == "yard":
		au.play_at(id, self, -8.0)


func go_home_and_sit() -> void:
	var id := begin_job("home")
	if not at_home:
		await go(spots["door"])
		if id != job:
			return
		_enter_house()
	end_job(id)
	sit_job("armchair", 30.0 if Game.is_night() else randf_range(20.0, 40.0))


func go_out() -> void:
	var id := begin_job("out")
	await go(spots["room_door"])
	if id != job:
		return
	_leave_house()
	await go(spots["porch"] + Vector3(randf_range(-0.8, 0.8), 0, 0.8))
	end_job(id)


# ------------------------------------------------------------------ сісти / встати
func _fwd(yaw: float) -> Vector3:
	return Vector3(sin(yaw), 0, cos(yaw))


func sit_job(seat: String, secs := 25.0) -> void:
	## Підійти, сісти; за столом і в кріслі — попити з глечика; посидіти й устати.
	var s: Array = seats.get(seat, [])
	if s.is_empty() or (bool(s[2]) != at_home) or seated != "":
		return
	var id := begin_job("sit_" + seat)
	var seat_p: Vector3 = s[0]
	var yaw := float(s[1])
	# сідаючи, він відступає назад — тож стати треба трохи попереду сидіння
	var back := (HIPS_SIT + HIPS_SITANIM_STAND - HIPS_IDLE - HIPS_SITANIM_SIT) * _k
	var stand_p := seat_p + _fwd(yaw) * back
	# підходить збоку (щоб не йти крізь стіл чи лавку), останній крок — без обходу перешкод
	var side := Vector3(cos(yaw), 0, -sin(yaw))
	if (position - stand_p).dot(side) < 0.0:
		side = -side
	await go(stand_p + side * 0.75 + _fwd(yaw) * 0.15)
	if id != job:
		return
	await go(stand_p, false, false)
	if id != job:
		return
	_face_to = yaw
	await wait(0.7)
	if id != job:
		return
	rotation.y = yaw
	await _sit_down(seat, seat_p, float(s[4]))
	if id != job:
		return
	var jug: Node3D = s[3]
	var left := secs
	while left > 0.0:
		var chunk := minf(left, randf_range(5.0, 9.0))
		await wait(chunk)
		left -= chunk
		if id != job or seated == "":
			return
		if jug and randf() < 0.6 and is_instance_valid(jug) and jug.get_parent() == jug.get_meta("home_parent", null):
			await _drink_seated(jug, id)
			if id != job:
				return
	if Game.is_night() and seat == "armchair":
		end_job(id)
		return              # увечері лишається в кріслі (встане, коли час спати)
	await stand_up()
	end_job(id)


func _sit_down(seat: String, seat_p: Vector3, dy: float) -> void:
	## Рух «встає», програний навпаки = сідає. Модель зсунута так, щоб початок руху збігся з тим, як він стоїть.
	seated = seat
	if ap == null or anims.get("stand_up", "") == "":
		position = seat_p
		return
	var n: String = anims["stand_up"]
	model.position.z = (HIPS_IDLE - HIPS_SITANIM_STAND) * _k
	current = "stand_up"
	ap.play_backwards(n, 0.2)
	ap.speed_scale = 1.35
	var len := ap.get_animation(n).length / 1.35
	var t := 0.0
	while t < len:
		t += get_process_delta_time()
		model.position.y = _base_y + dy * clampf(t / len, 0.0, 1.0)
		await get_tree().process_frame
	# тепер сидить: переходимо на «сидить і п'є» (перший кадр) без змішування
	position = seat_p
	model.position = Vector3(0, _base_y + dy, 0)
	_seat_dy = dy
	_sit_still()


func _sit_still() -> void:
	var n: String = anims.get("sitdrink", "")
	if n == "":
		return
	current = "sitdrink"
	ap.speed_scale = 1.0
	ap.play(n, 0.0)
	ap.seek(0.0, true)
	ap.pause()


func stand_up() -> void:
	if seated == "":
		return
	put_back_held()
	var yaw := rotation.y
	var n: String = anims.get("stand_up", "")
	if n == "":
		seated = ""
		play("idle")
		return
	model.position.z = (HIPS_SIT - HIPS_SITANIM_SIT) * _k
	current = "stand_up"
	ap.play(n, 0.0)
	ap.speed_scale = 1.35
	var len := ap.get_animation(n).length / 1.35
	var t := 0.0
	while t < len - 0.05:
		t += get_process_delta_time()
		model.position.y = _base_y + _seat_dy * (1.0 - clampf(t / len, 0.0, 1.0))
		await get_tree().process_frame
	position += _fwd(yaw) * (HIPS_SIT - HIPS_SITANIM_SIT + HIPS_SITANIM_STAND - HIPS_IDLE) * _k
	model.position = Vector3(0, _base_y, 0)
	_seat_dy = 0.0
	seated = ""
	current = ""
	ap.speed_scale = 1.0
	play("idle")
	# якщо встав «у» стіл чи лавку — відступає вбік
	var out := Obstacles.push_out(position, me_r)
	if out.distance_to(position) > 0.02:
		var dir := (out - position).normalized()
		await go(out + dir * 0.15, false, false)


func _drink_seated(jug: Node3D, id: int) -> void:
	## «Сидить і п'є»: глечик переходить у праву руку, поки він п'є, а потім — на своє місце.
	var n: String = anims.get("sitdrink", "")
	if n == "" or hand == null:
		return
	current = "sitdrink"
	ap.play(n, 0.0)
	ap.seek(0.0, true)
	ap.speed_scale = 1.0
	var len := ap.get_animation(n).length
	var took := false
	var t := 0.0
	while t < len:
		t += get_process_delta_time()
		if id != job:
			break
		if not took and t > 2.4:
			took = true
			hold(jug, Vector3(0.0, 0.05, 0.07))
		if took and held and t > 8.6:
			put_back_held()
		await get_tree().process_frame
	put_back_held()
	if id == job and seated != "":
		say("Ох, і смачний узвар!", 2.5)
		_sit_still()


func well_drink_job() -> void:
	## Біля криниці: набирає кухоль води й п'є стоячи.
	var id := begin_job("well_drink")
	await go(spots["well_front"] + Vector3(-0.2, 0, 0.2))
	if id != job:
		return
	face(spots["well"])
	await wait(0.8)
	if id != job:
		return
	var n: String = anims.get("drink", "")
	if n == "":
		end_job(id)
		return
	current = "drink"
	ap.play(n, 0.3)
	var mug := Util.cyl(0.045, 0.04, 0.1, Util.mat(Color(0.75, 0.45, 0.25), 0.6))
	var len := ap.get_animation(n).length
	var t := 0.0
	var took := false
	while t < len:
		t += get_process_delta_time()
		if id != job:
			break
		if not took and t > 1.2:
			took = true
			hold(mug, Vector3(0, 0.06, 0.04), true)
		await get_tree().process_frame
	var m := drop()
	if m:
		m.queue_free()
	elif not took:
		mug.queue_free()
	if id == job:
		say("Ох, і смачна в нас вода!", 2.5)
	current = ""
	play("idle")
	end_job(id)


# ------------------------------------------------------------------ сон і відпочинок
var blanket: Node3D


func _make_blanket() -> void:
	## Ряднина під старою грушею — дідусь іноді лягає на ній подрімати.
	blanket = Node3D.new()
	blanket.position = Vector3(-6.4, 0, -7.3)
	blanket.rotation.y = deg_to_rad(-35.0)
	world.yard_root.add_child(blanket)
	var a := Util.mat(Color(0.75, 0.2, 0.18), 0.95)
	var b := Util.mat(Color(0.95, 0.88, 0.7), 0.95)
	for k in 6:
		var stripe := Util.box(Vector3(0.95, 0.012, 0.32), a if k % 2 == 0 else b, Vector3(0, 0.008, -0.8 + k * 0.32))
		stripe.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		blanket.add_child(stripe)


func sleep_job() -> void:
	## Уночі дрімає в кріслі.
	if seated != "armchair":
		sit_job("armchair", 1e9)
		return
	var id := begin_job("sleep")
	while id == job and (Game.hour() >= 21.0 or Game.hour() < 6.5):
		say("Хр-р-р… z-z-z", 2.5)
		await wait(6.0)
	if id != job:
		return
	await stand_up()
	say("Доброго ранку!", 2.5)
	end_job(id)


func nap_job() -> void:
	## Удень: лягає на ряднину під деревом і дрімає.
	if blanket == null or anims.get("lie", "") == "":
		return
	var id := begin_job("nap")
	var yaw := blanket.rotation.y + PI
	var f := _fwd(yaw)
	var spot := blanket.position - f * 0.22       # голова — до дерева
	await go(spot + f * 1.4)
	if id != job:
		return
	await go(spot + f * 0.5)
	if id != job:
		return
	_face_to = yaw
	await wait(0.6)
	lying = true
	position = spot
	rotation.y = yaw
	current = "lie"
	ap.play(anims["lie"], 1.0)
	say("Подрімаю трішки…", 2.5)
	var t := randf_range(20.0, 35.0)
	while t > 0.0 and id == job:
		await wait(5.0)
		t -= 5.0
		if randf() < 0.6:
			say("z-z-z", 2.0)
	lying = false
	if id != job:
		return
	position = spot + f * 0.5
	current = ""
	ap.play(anims["idle"], 1.0)
	end_job(id)


# ------------------------------------------------------------------ з гравцем
func wave_at(p: Vector3) -> void:
	if seated != "" or lying:
		say("Привіт, Beep!", 2.0)
		return
	stop()
	face(p)
	busy = true
	play("wave")
	_act_left = anim_length("wave")
	_act_then = Callable()


func start_talk(p: Vector3) -> void:
	if seated == "" and not lying:
		cancel_job()
		face(p)
		talking = true
	busy = false


func end_talk() -> void:
	talking = false
	idle_left = randf_range(3.0, 6.0)


func test(what: String) -> void:
	## Для перевірки в demo: call:grandpa:test:drink|bench|armchair|sleep|well
	match what:
		"drink":
			await sit_job("table", 0.1)
		"bench":
			sit_job("bench", 60.0)
		"armchair":
			_enter_house()
			sit_job("armchair", 60.0)
		"nap":
			nap_job()
		"well":
			well_drink_job()
		"sitdrink":
			var id := begin_job("t")
			var s: Array = seats["table"]
			position = s[0]
			rotation.y = 0.0
			seated = "table"
			model.position = Vector3(0, _base_y - 0.02, 0)
			await _drink_seated(s[3], id)

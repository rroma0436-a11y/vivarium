extends RefCounted
class_name Models
## Завантаження 3D-моделей з Meshy (assets/models/*.glb): підгонка розміру, постановка на землю,
## пошук анімацій. Якщо файлу ще немає — повертає null, і персонаж будує просту заміну сам.

const DIR := "res://assets/models/%s.glb"


static func exists(id: String) -> bool:
	return ResourceLoader.exists(DIR % id)


static func spawn(parent: Node3D, id: String, size: float, axis := "y") -> Node3D:
	## Додає модель у parent, масштабує так, щоб її висота (axis="y") або довжина ("z") дорівнювала size,
	## і ставить низом на y=0, по центру. Повертає вузол-обгортку (його можна повертати й рухати).
	if not exists(id):
		return null
	var holder := Node3D.new()
	holder.name = id
	parent.add_child(holder)
	var m: Node3D = load(DIR % id).instantiate()
	holder.add_child(m)
	var b := measure(m)
	var span: float = b.size.y if axis == "y" else b.size.z
	var s := size / maxf(span, 0.0001)
	m.scale = Vector3.ONE * s
	var c := b.get_center()
	m.position = -Vector3(c.x, b.position.y, c.z) * s
	for mi in m.find_children("*", "MeshInstance3D", true, false):
		(mi as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	holder.set_meta("model", m)
	return holder


static func measure(m: Node3D) -> AABB:
	## Межі моделі в її власних координатах. Для моделей зі скелетом рахуємо по кістках
	## (сітка зі скінінгом має «сирі» межі, що не збігаються з видимим тілом).
	var inv := m.global_transform.affine_inverse()
	var sks := m.find_children("*", "Skeleton3D", true, false)
	if sks.size() > 0:
		var sk: Skeleton3D = sks[0]
		var lo := Vector3.INF
		var hi := -Vector3.INF
		for b in sk.get_bone_count():
			var p := inv * (sk.global_transform * sk.get_bone_global_pose(b)).origin
			lo = lo.min(p)
			hi = hi.max(p)
		var sz := hi - lo
		# кістки не доходять до краю тіла: голова, вуха, кінчик хвоста трохи далі
		lo -= Vector3(sz.x * 0.06, 0.0, sz.z * 0.06)
		hi += Vector3(sz.x * 0.06, sz.y * 0.08, sz.z * 0.06)
		return AABB(lo, hi - lo)
	var out := AABB()
	var first := true
	for mi in m.find_children("*", "MeshInstance3D", true, false):
		var ab: AABB = inv * (mi as MeshInstance3D).global_transform * (mi as MeshInstance3D).get_aabb()
		out = ab if first else out.merge(ab)
		first = false
	return out


static func anim_player(holder: Node) -> AnimationPlayer:
	if holder == null:
		return null
	return holder.find_child("AnimationPlayer", true, false) as AnimationPlayer


static func find_anim(ap: AnimationPlayer, keys: Array) -> String:
	## Перша анімація, назва якої містить один із ключів (без урахування регістру).
	if ap == null:
		return ""
	for k in keys:
		for n in ap.get_animation_list():
			if String(k) in String(n).to_lower():
				return n
	return ""


static func set_loop(ap: AnimationPlayer, names: Array) -> void:
	for n in names:
		if n != "" and ap.has_animation(n):
			ap.get_animation(n).loop_mode = Animation.LOOP_LINEAR


static func glow(holder: Node, energy := 0.0) -> void:
	## Легке власне світіння моделі (щоб уночі не була зовсім темна, а очі Beep сяяли).
	for mi in holder.find_children("*", "MeshInstance3D", true, false):
		var m3 := mi as MeshInstance3D
		for si in m3.get_surface_override_material_count():
			var mat := m3.get_active_material(si)
			if mat is StandardMaterial3D:
				var d: StandardMaterial3D = mat.duplicate()
				d.emission_enabled = energy > 0.0
				d.emission_texture = d.albedo_texture
				d.emission = Color(1, 1, 1)
				d.emission_energy_multiplier = energy
				m3.set_surface_override_material(si, d)

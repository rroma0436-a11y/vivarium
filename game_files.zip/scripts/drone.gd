extends Node3D
## Дрон-помічник: облітає город по колу, зависає над грядкою й «поливає» її краплями.

var center := Vector3.ZERO
var radius := 2.2
var height := 2.6
var model: Node3D
var drops: CPUParticles3D
var _t := 0.0
var _hover := 0.0


func setup(at: Vector3) -> void:
	center = at
	position = at + Vector3(radius, height, 0)
	model = Models.spawn(self, "drone", 0.6)
	if model:
		model.position.y -= 0.3
	add_child(Util.pick_area("drone", Vector3(0.8, 0.6, 0.8), Vector3.ZERO))
	drops = CPUParticles3D.new()
	drops.amount = 40
	drops.lifetime = 0.9
	drops.direction = Vector3(0, -1, 0)
	drops.spread = 12.0
	drops.initial_velocity_min = 1.0
	drops.initial_velocity_max = 1.6
	drops.gravity = Vector3(0, -6, 0)
	drops.emitting = false
	var sm := SphereMesh.new()
	sm.radius = 0.015
	sm.height = 0.04
	sm.radial_segments = 4
	sm.rings = 2
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.55, 0.8, 1.0, 0.8)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = m
	drops.mesh = sm
	drops.position = Vector3(0, -0.35, 0)
	add_child(drops)


func _process(delta: float) -> void:
	_t += delta
	if Game.is_night():
		# уночі сідає відпочити біля курника
		position = position.lerp(center + Vector3(0, 0.35, -2.4), 1.0 - exp(-delta * 0.8))
		drops.emitting = false
		return
	if _hover > 0.0:
		_hover -= delta
		drops.emitting = true
	else:
		drops.emitting = false
		var a := _t * 0.35
		var want := center + Vector3(cos(a) * radius, height + sin(_t * 1.7) * 0.12, sin(a) * radius)
		position = position.lerp(want, 1.0 - exp(-delta * 2.0))
		rotation.y = lerp_angle(rotation.y, -a, 1.0 - exp(-delta * 3.0))
		if fmod(_t, 14.0) < delta:
			_hover = 3.0       # зависає й поливає
	rotation.z = sin(_t * 1.3) * 0.05


func poke() -> void:
	_hover = 3.0

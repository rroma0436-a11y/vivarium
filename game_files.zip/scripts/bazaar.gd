extends Node3D
## Базар за річкою (зроблено в Blender, файл Базар.blend): два ряди ларьків із продавцями й товаром,
## дві вулиці хат із меблями, дерев'яна церква в кінці проходу, криниці, лавки, ліхтарі.
## Усе стоїть так само, як у Blender; головний прохід — продовження дороги від мосту (x = 0).
## Двері хат, ларьків, церкви й ворота дворів відчиняються, коли поруч Ніка.
## Стіни, ларьки й паркани тверді для Ніки (шар WALLS), підлога хат і ганки — шар FLOOR.

const DIR := "res://assets/models/bazaar/%s.glb"
# точка Blender (0, 0) у світі гри; вісь X Blender (прохід між ларьками) дивиться на північ, до мосту
const ORIGIN := Vector3(-3.06, 0, 197.0)
const AREA := Rect2(-74.0, 106.0, 141.0, 134.0)          # x, z — уся територія базару
const WALLS := 1 << 17
const FLOOR := 1 << 16

var root: Node3D
var walls: StaticBody3D
var floors: StaticBody3D
var buildings: Array = []        # {node, box (AABB у системі вузла), roofs: [MeshInstance3D], kind}
var doors: Array = []            # {node, base, open_to, angle, open, pos}
var sellers: Array = []          # [вузол, AnimationPlayer]
var map_houses: Array = []       # [x, z] для мапи
var map_road_pts: Array = []     # точки доріг базару для мапи [x, z]
var inside = null                # будівля, в якій зараз Ніка (або null)
var _acc := 0.0

# продавці: файл, позиція в Blender (x, y), поворот (рад, навколо Z Blender), слова
const SELLERS := [
	["bz_seller_bread", Vector2(5.0, -0.2), "Ковбаска домашня, сальце — пробуй!"],
	["bz_seller_m1", Vector2(9.5, -0.2), "Сокири, молотки, граблі — на все господарство!"],
	["bz_seller_w2", Vector2(14.0, -0.2), "Льодяники, пряники, цукерочки!"],
	["bz_seller_bread", Vector2(18.5, -0.2), "Свіжий хліб, тільки з печі!"],
	["bz_seller_girl", Vector2(9.5, -6.12), "Яблучка, груші, сливи — солоденькі!"],
]
const SELLER_FILE_POS := {"bz_seller_bread": Vector2(18.5, -0.2), "bz_seller_m1": Vector2(9.5, -0.2),
	"bz_seller_w2": Vector2(14.0, -0.2), "bz_seller_girl": Vector2(9.5, -6.12)}


static func to_world(bx: float, by: float) -> Vector3:
	## Точка з Blender (x, y) → світ гри.
	return ORIGIN + Vector3(-by, 0, -bx)


static func in_area(p: Vector3) -> bool:
	return AREA.has_point(Vector2(p.x, p.z))


func build() -> void:
	root = Node3D.new()
	root.name = "BazaarRoot"
	root.position = ORIGIN
	root.rotation.y = PI / 2.0
	add_child(root)
	walls = _body("BazaarWalls", WALLS)
	floors = _body("BazaarFloors", FLOOR)
	for f in ["bz_misc", "bz_fence", "bz_stalls", "bz_houses"]:
		if not ResourceLoader.exists(DIR % f):
			continue
		var n: Node3D = load(DIR % f).instantiate()
		n.name = f
		root.add_child(n)
	for s in SELLERS:
		_add_seller(s[0], s[1], s[2])
	_setup_meshes()
	_setup_buildings()
	_collect_roads()


func _collect_roads() -> void:
	var rd := root.find_child("Дороги", true, false) as MeshInstance3D
	if rd == null or rd.mesh == null:
		return
	var seen := {}
	for f in rd.mesh.get_faces():
		var w: Vector3 = rd.global_transform * f
		var key := Vector2i(int(w.x / 2.0), int(w.z / 2.0))
		if not seen.has(key):
			seen[key] = true
			map_road_pts.append([w.x, w.z])


func _body(nm: String, layer: int) -> StaticBody3D:
	var b := StaticBody3D.new()
	b.name = nm
	b.collision_layer = layer
	b.collision_mask = 0
	add_child(b)
	return b


func _add_seller(file: String, at: Vector2, words: String) -> void:
	if not ResourceLoader.exists(DIR % file):
		return
	var holder := Node3D.new()
	holder.name = "Seller_%d" % sellers.size()
	root.add_child(holder)
	var m: Node3D = load(DIR % file).instantiate()
	holder.add_child(m)
	# файл уже стоїть на своєму місці з Blender — зсуваємо, якщо цей продавець в іншому ларьку
	var fp: Vector2 = SELLER_FILE_POS[file]
	holder.position = Vector3(at.x - fp.x, 0, -(at.y - fp.y))
	var ap := Models.anim_player(m)
	if ap and ap.get_animation_list().size() > 0:
		var an: String = ap.get_animation_list()[0]
		ap.get_animation(an).loop_mode = Animation.LOOP_LINEAR
		ap.play(an)
		ap.seek(randf() * ap.get_animation(an).length, true)
	for mi in m.find_children("*", "MeshInstance3D", true, false):
		(mi as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var pos := to_world(at.x, at.y)
	var pick := Util.pick_area("bz_seller", Vector3(0.9, 1.8, 0.9), Vector3(0, 0.9, 0))
	pick.set_meta("words", words)
	holder.add_child(pick)
	var lb := Label3D.new()
	lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lb.font_size = 44
	lb.outline_size = 10
	lb.modulate = Color(1, 0.98, 0.9)
	lb.outline_modulate = Color(0.25, 0.12, 0.3)
	lb.width = 520.0
	lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lb.pixel_size = 0.004
	lb.position = Vector3(0, 2.15, 0)
	lb.visible = false
	lb.no_depth_test = true
	holder.add_child(lb)
	var cyl := CollisionShape3D.new()
	var cs := CylinderShape3D.new()
	cs.radius = 0.22
	cs.height = 1.6
	cyl.shape = cs
	walls.add_child(cyl)
	cyl.global_position = pos + Vector3(0, 0.8, 0)
	sellers.append({"node": holder, "ap": ap, "model": m, "pos": pos, "label": lb, "left": 0.0, "words": words})


func seller_say(holder: Node, text := "") -> void:
	for s in sellers:
		if s["node"] == holder:
			var lb: Label3D = s["label"]
			lb.text = text if text != "" else String(s["words"])
			lb.visible = true
			s["left"] = 3.5


# ------------------------------------------------------------------ сітки: видимість, тіні
const INTERIOR := ["Інтер'єр", "Піч", "Стіл", "Стілець", "Лава", "Ліжко", "Постіль", "Табурет"]
const ROOF := ["_Дах", "Димар", "Мансарда", "Дахи", "Бані"]


func _setup_meshes() -> void:
	for n in root.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		var nm := String(mi.name)
		var file := _file_of(mi)
		var far := 150.0
		var shadow := true
		if file == "bz_stalls" and not nm.begins_with("Ларьок") and nm != "Продавець_Риба":
			far = 45.0                   # товар на прилавках
			shadow = false
		elif file == "bz_fence":
			far = 90.0
			shadow = false
		elif _has_any(nm, INTERIOR):
			far = 28.0
			shadow = false
		elif nm.begins_with("Лавка") or nm.begins_with("Ліхтар") or nm.begins_with("Криниця") or nm.contains("Калітка") or nm.contains("Ворота"):
			far = 70.0
			shadow = false
		elif nm == "Дороги":
			far = 0.0
			shadow = false
		elif file == "bz_houses":
			# дрібніші частини хат — лише зблизька (телефону легше)
			if nm.ends_with("Розпис"):
				far = 35.0
				shadow = false
			elif nm.ends_with("Двері"):
				far = 50.0
				shadow = false
			elif nm.ends_with("Вікна") or nm.ends_with("Ганок") and not nm.ends_with("Дах_Ганок"):
				far = 70.0
				shadow = false
			elif nm.ends_with("Димар") or nm.ends_with("Дах_Ганок") or nm.ends_with("Мансарда"):
				far = 95.0
				shadow = false
		elif file == "bz_misc" and nm.begins_with("Церква") and not (nm.ends_with("Дахи") or nm.ends_with("Колоди") or nm.ends_with("Бані")):
			far = 80.0
			shadow = false
		mi.visibility_range_end = far
		mi.visibility_range_end_margin = 8.0 if far > 0.0 else 0.0
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _file_of(n: Node) -> String:
	var p := n
	while p != null and p.get_parent() != root:
		p = p.get_parent()
	return String(p.name) if p else ""


static func _has_any(s: String, keys: Array) -> bool:
	for k in keys:
		if s.contains(k):
			return true
	return false


# ------------------------------------------------------------------ будівлі, двері, тверді стіни
func _setup_buildings() -> void:
	var hs: Node = root.get_node_or_null("bz_houses")
	if hs:
		for h in hs.get_children():
			if not (h is Node3D) or h is MeshInstance3D:
				continue
			_add_building(h, "house")
	var misc: Node = root.get_node_or_null("bz_misc")
	if misc:
		var ch: Node = misc.get_node_or_null("Церква")
		if ch:
			_add_building(ch, "church")
		for n in misc.get_children():
			var nm := String(n.name)
			if nm.begins_with("Криниця"):
				_solid(n as MeshInstance3D, true)
			elif nm.begins_with("Дерево"):
				var tr := n.find_child("*Стовбур", false, false) as MeshInstance3D
				if tr:
					_solid(tr, true)
	var st: Node = root.get_node_or_null("bz_stalls")
	if st:
		for n in st.get_children():
			var nm := String(n.name)
			if nm.begins_with("Ларьок") and not nm.contains("_Двері") and not nm.contains("Табурет"):
				_add_stall(n as MeshInstance3D)
	var fc: Node = root.get_node_or_null("bz_fence")
	if fc:
		for n in fc.get_children():
			_solid(n as MeshInstance3D, false)


func _add_building(h: Node3D, kind: String) -> void:
	var nm := String(h.name)
	var b := {"node": h, "kind": kind, "roofs": [], "box": AABB(), "name": nm}
	var wall_box := AABB()
	var first := true
	for c in h.get_children():
		if not (c is MeshInstance3D):
			continue
		var mi := c as MeshInstance3D
		var cn := String(mi.name).trim_prefix(nm)
		if _has_any(cn, ROOF):
			b["roofs"].append(mi)
		elif cn.ends_with("Стіни"):
			_solid(mi, false)
			var ab: AABB = mi.transform * mi.get_aabb()
			wall_box = ab if first else wall_box.merge(ab)
			first = false
		elif cn.ends_with("Інтер'єр") or cn.ends_with("Ганок") or cn.ends_with("Фундамент"):
			_floor(mi)
			if cn.ends_with("Інтер'єр"):
				var ceil := _split_ceiling(mi)
				if ceil:
					b["roofs"].append(ceil)
		elif cn.ends_with("Піч") or cn.ends_with("Стіл") or cn.ends_with("Ліжко"):
			_solid(mi, true)
		if kind == "church" and (cn.ends_with("Колоди") or cn.ends_with("Стіни") or cn.ends_with("Вікна")):
			# церква висока: коли Ніка всередині, стіни вище 3 м ховаємо (видно згори)
			var up := _split_ceiling(mi, 3.2, false)
			if up:
				b["roofs"].append(up)
		if cn.contains("Двері") or cn.contains("Калітка") or cn.contains("Ворота"):
			_add_door(mi, h, cn.contains("Калітка") or cn.contains("Ворота"))
	b["box"] = wall_box
	buildings.append(b)
	var c3 := h.global_position
	map_houses.append([c3.x, c3.z])


func _add_stall(mi: MeshInstance3D) -> void:
	if mi == null:
		return
	_solid(mi, false)
	_floor(mi)
	var box := mi.get_aabb()
	var b := {"node": mi, "kind": "stall", "roofs": [], "box": box, "name": String(mi.name)}
	var top := _split_ceiling(mi, 2.1, false)            # дах ларька — окремо, щоб ховати
	if top:
		b["roofs"].append(top)
	for sign_name in ["Вивіска_ковбаса", "Вивіска_льодяник"]:
		var sg := mi.get_parent().get_node_or_null(sign_name) as Node3D
		if sg and sg.global_position.distance_to(mi.global_position) < 2.0:
			b["roofs"].append(sg)
	buildings.append(b)
	var d := mi.get_parent().get_node_or_null(String(mi.name) + "_Двері") as MeshInstance3D
	if d:
		_add_door(d, mi, false)
	map_houses.append([mi.global_position.x, mi.global_position.z])


var _ceil_cache := {}            # спільна сітка інтер'єру → [без стелі, стеля]


func _split_ceiling(mi: MeshInstance3D, min_y := 2.0, flat_only := true) -> MeshInstance3D:
	## Стеля входить у сітку інтер'єру разом із підлогою. Розрізаємо: стелю (горизонтальні
	## трикутники вище 2 м) — в окрему сітку, щоб ховати її разом із дахом, коли Ніка в хаті.
	var src: Mesh = mi.mesh
	if not _ceil_cache.has(src):
		var rest := ArrayMesh.new()
		var top := ArrayMesh.new()
		for si in src.get_surface_count():
			var arr := src.surface_get_arrays(si)
			var verts: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
			var idx: PackedInt32Array = arr[Mesh.ARRAY_INDEX] if arr[Mesh.ARRAY_INDEX] != null else PackedInt32Array()
			if idx.is_empty():
				for i in verts.size():
					idx.append(i)
			var keep := PackedInt32Array()
			var up := PackedInt32Array()
			for t in range(0, idx.size() - 2, 3):
				var a := verts[idx[t]]
				var b2 := verts[idx[t + 1]]
				var c := verts[idx[t + 2]]
				var n := (b2 - a).cross(c - a)
				var flat := not flat_only or (n.length() > 0.0 and absf(n.normalized().y) > 0.9)
				var hy := minf(a.y, minf(b2.y, c.y)) if flat_only else (a.y + b2.y + c.y) / 3.0
				if flat and hy > min_y:
					up.append_array([idx[t], idx[t + 1], idx[t + 2]])
				else:
					keep.append_array([idx[t], idx[t + 1], idx[t + 2]])
			var mat := src.surface_get_material(si)
			for pair in [[rest, keep], [top, up]]:
				if (pair[1] as PackedInt32Array).is_empty():
					continue
				var a2 := arr.duplicate()
				a2[Mesh.ARRAY_INDEX] = pair[1]
				var m2: ArrayMesh = pair[0]
				m2.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a2)
				m2.surface_set_material(m2.get_surface_count() - 1, mat)
		_ceil_cache[src] = [rest, top if top.get_surface_count() > 0 else null]
	var pair2: Array = _ceil_cache[src]
	if pair2[1] == null:
		return null
	mi.mesh = pair2[0]
	var cm := MeshInstance3D.new()
	cm.name = String(mi.name) + "_Верх"
	cm.mesh = pair2[1]
	cm.transform = mi.transform
	cm.visibility_range_end = 150.0
	cm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.get_parent().add_child(cm)
	return cm


func _solid(mi: MeshInstance3D, convex: bool) -> void:
	if mi == null or mi.mesh == null:
		return
	var cs := CollisionShape3D.new()
	cs.shape = mi.mesh.create_convex_shape(true, true) if convex else mi.mesh.create_trimesh_shape()
	walls.add_child(cs)
	cs.global_transform = mi.global_transform


func _floor(mi: MeshInstance3D) -> void:
	if mi == null or mi.mesh == null:
		return
	var cs := CollisionShape3D.new()
	cs.shape = mi.mesh.create_trimesh_shape()
	floors.add_child(cs)
	cs.global_transform = mi.global_transform


func _add_door(d: MeshInstance3D, owner_node: Node3D, inward: bool) -> void:
	## Двері обертаються навколо свого початку координат (завіси). Відчиняються назовні,
	## ворота дворів — у двір.
	var center := owner_node.global_position
	var base := d.rotation.y
	var best := 0.0
	var best_d := -INF
	var ab := d.get_aabb()
	var mid := ab.get_center()
	for sgn in [-1.0, 1.0]:
		var t := d.global_transform
		var rot := Basis(Vector3.UP, deg_to_rad(95.0) * sgn)
		var pworld: Vector3 = t.origin + rot * (t.basis * mid)
		var dist := Vector2(pworld.x - center.x, pworld.z - center.z).length()
		var score := -dist if inward else dist
		if score > best_d:
			best_d = score
			best = sgn
	# «відкрито» в системі батька: той самий поворот навколо вертикалі світу
	var up_local: Vector3 = (d.get_parent() as Node3D).global_transform.basis.inverse() * Vector3.UP
	doors.append({"node": d, "base": d.transform, "axis": up_local.normalized(), "sign": best, "k": 0.0, "want": 0.0,
		"pos": d.global_transform * mid})


# ------------------------------------------------------------------ щокадру
func step(delta: float, who: Array, cam: Vector3) -> void:
	## who — хто ходить (позиції); cam — де камера.
	_acc += delta
	if _acc > 0.2:
		_acc = 0.0
		for d in doors:
			var p: Vector3 = d["pos"]
			var near := false
			for q in who:
				var v: Vector3 = q
				if absf(v.x - p.x) < 2.2 and absf(v.z - p.z) < 2.2:
					near = true
					break
			d["want"] = 1.0 if near else 0.0
		for s in sellers:
			var far: bool = (s["pos"] as Vector3).distance_to(cam) > 60.0
			(s["model"] as Node3D).visible = not far
			if s["ap"]:
				(s["ap"] as AnimationPlayer).active = not far
	for d in doors:
		var k: float = d["k"]
		var w: float = d["want"]
		if absf(k - w) < 0.001:
			continue
		k = move_toward(k, w, delta * 1.8)
		d["k"] = k
		var e := k * k * (3.0 - 2.0 * k)
		var tr: Transform3D = d["base"]
		var r := Basis(d["axis"], deg_to_rad(95.0) * float(d["sign"]) * e)
		(d["node"] as Node3D).transform = Transform3D(r * tr.basis, tr.origin)
	for s in sellers:
		if s["left"] > 0.0:
			s["left"] = float(s["left"]) - delta
			if s["left"] <= 0.0:
				(s["label"] as Label3D).visible = false


func building_at(p: Vector3):
	## Будівля, всередині якої точка p (або null).
	if not in_area(p):
		return null
	for b in buildings:
		var n: Node3D = b["node"]
		var box: AABB = b["box"]
		if box.size == Vector3.ZERO:
			continue
		var q: Vector3 = (n.global_transform.affine_inverse() * (p + Vector3(0, 0.5, 0)))
		if box.grow(-0.05).has_point(q):
			return b
	return null


func set_inside(b) -> void:
	## Ніка зайшла в будівлю — ховаємо дах, щоб її було видно згори.
	if b == inside:
		return
	if inside:
		for r in inside["roofs"]:
			(r as Node3D).visible = true
	inside = b
	if inside:
		for r in inside["roofs"]:
			(r as Node3D).visible = false


func floor_y(p: Vector3, cur_y: float) -> float:
	## Висота підлоги під ногами (хата, ганок, ларьок), інакше — земля.
	if not in_area(p):
		return 0.0
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(Vector3(p.x, cur_y + 0.55, p.z), Vector3(p.x, -0.5, p.z), FLOOR)
	q.collide_with_areas = false
	var hit := space.intersect_ray(q)
	if hit.is_empty():
		return 0.0
	return maxf(0.0, float((hit["position"] as Vector3).y))

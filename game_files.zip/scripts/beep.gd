extends Node3D
## Робот-помічник Beep: літає, блимає очима-екраном, підказує й допомагає (насипає корм).
## Поки що зібраний із простих форм; згодом можна замінити на модель .glb.

const SPEED := 1.4

var body: Node3D
var eyes: Array = []
var glow: MeshInstance3D
var bubble: Label3D
var area: Area3D
var shadow: MeshInstance3D
var target := Vector3.ZERO
var moving := false
var hover_t := 0.0
var blink_left := 2.0
var bubble_left := 0.0
var _then: Callable
var _eye_mat: StandardMaterial3D


func _ready() -> void:
	body = Node3D.new()
	add_child(body)
	var white := Util.mat(Color(0.95, 0.96, 0.98), 0.35, 0.1)
	var mint := Util.mat(Color(0.35, 0.82, 0.72), 0.4, 0.2)
	var dark := Util.mat(Color(0.12, 0.14, 0.2), 0.25, 0.3)
	_eye_mat = Util.mat(Color(0.5, 0.95, 1.0), 0.2, 0.0, Color(0.45, 0.95, 1.0), 2.2)
	# тулуб-яйце, екран-обличчя, «вушка», антена з вогником, кільце-турбіна знизу
	body.add_child(Util.sphere(0.13, white, Vector3(0, 0, 0), Vector3(1.0, 0.92, 0.9)))
	body.add_child(Util.sphere(0.095, dark, Vector3(0, 0.02, 0.07), Vector3(1.0, 0.72, 0.55)))
	for sx in [-1.0, 1.0]:
		var e := Util.capsule(0.016, 0.05, _eye_mat, Vector3(0.035 * sx, 0.025, 0.118))
		body.add_child(e)
		eyes.append(e)
		body.add_child(Util.cyl(0.035, 0.035, 0.03, mint, Vector3(0.135 * sx, 0.0, 0), Vector3(0, 0, 90)))
	body.add_child(Util.cyl(0.006, 0.006, 0.09, dark, Vector3(0, 0.15, 0)))
	body.add_child(Util.sphere(0.02, Util.mat(Color(1, 0.45, 0.35), 0.3, 0.0, Color(1, 0.4, 0.3), 2.5), Vector3(0, 0.2, 0)))
	var ring := TorusMesh.new()
	ring.inner_radius = 0.07
	ring.outer_radius = 0.1
	body.add_child(Util.mesh(ring, mint, Vector3(0, -0.11, 0)))
	glow = Util.sphere(0.06, Util.mat(Color(0.5, 1, 0.95, 0.35), 0.5, 0.0, Color(0.4, 1, 0.9), 1.5), Vector3(0, -0.14, 0), Vector3(1, 0.3, 1))
	body.add_child(glow)
	shadow = Util.blob_shadow(0.14, 0.25)
	add_child(shadow)
	area = Util.pick_area("beep", Vector3(0.36, 0.4, 0.3), Vector3(0, 0.36, 0))
	add_child(area)
	bubble = Util.bubble(load("res://assets/fonts/DejaVuSans-Bold.ttf"), 40)
	bubble.position = Vector3(0, 0.68, 0)
	add_child(bubble)


func _process(delta: float) -> void:
	hover_t += delta
	body.position = Vector3(0, 0.36 + sin(hover_t * 2.2) * 0.03, 0)
	body.rotation_degrees.z = sin(hover_t * 1.3) * 4.0
	shadow.scale = Vector3.ONE * (1.0 - sin(hover_t * 2.2) * 0.08)
	blink_left -= delta
	var closing := blink_left < 0.12
	for e in eyes:
		e.scale = Vector3(1, 0.15 if closing else 1.0, 1)
	if blink_left < 0.0:
		blink_left = randf_range(2.0, 4.5)
	if bubble_left > 0.0:
		bubble_left -= delta
		if bubble_left <= 0.0:
			bubble.visible = false
	if moving:
		var to := target - position
		var d := to.length()
		var v := SPEED * delta
		body.rotation_degrees.y = lerpf(body.rotation_degrees.y, clampf(to.x * 40.0, -35.0, 35.0), 0.1)
		if d <= v:
			position = target
			moving = false
			body.rotation_degrees.y = 0.0
			if _then.is_valid():
				var cb := _then
				_then = Callable()
				cb.call()
		else:
			position += to / d * v


func fly_to(p: Vector3, then := Callable()) -> void:
	target = p
	moving = true
	_then = then


func say(text: String, secs := 3.0) -> void:
	bubble.text = text
	bubble.visible = true
	bubble_left = secs


func happy() -> void:
	## Підстрибує й крутиться від радості.
	var tw := create_tween()
	tw.tween_property(body, "rotation_degrees:y", 360.0, 0.6).from(0.0)
	tw.tween_callback(func(): body.rotation_degrees.y = 0.0)

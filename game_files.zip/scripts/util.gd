extends RefCounted
class_name Util
## Дрібні помічники для побудови сцени кодом.


static func blob_shadow(radius: float, alpha := 0.35) -> MeshInstance3D:
	var g := Gradient.new()
	g.set_color(0, Color(0.1, 0.07, 0.12, alpha))
	g.set_color(1, Color(0.1, 0.07, 0.12, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 64
	gt.height = 64
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = gt
	m.render_priority = -1
	var q := PlaneMesh.new()
	q.size = Vector2(radius * 2.0, radius * 1.0)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = m
	mi.position.y = 0.003
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi


static func mat(color: Color, rough := 0.6, metal := 0.0, emit := Color(0, 0, 0), emit_e := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	if emit_e > 0.0:
		m.emission_enabled = true
		m.emission = emit
		m.emission_energy_multiplier = emit_e
	if color.a < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m


static func mesh(m: Mesh, material: Material, pos := Vector3.ZERO, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = material
	mi.position = pos
	mi.rotation_degrees = rot
	mi.scale = scl
	return mi


static func sphere(r: float, material: Material, pos := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 24
	s.rings = 12
	return mesh(s, material, pos, Vector3.ZERO, scl)


static func box(size: Vector3, material: Material, pos := Vector3.ZERO, rot := Vector3.ZERO) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	return mesh(b, material, pos, rot)


static func cyl(r_top: float, r_bot: float, h: float, material: Material, pos := Vector3.ZERO, rot := Vector3.ZERO) -> MeshInstance3D:
	var c := CylinderMesh.new()
	c.top_radius = r_top
	c.bottom_radius = r_bot
	c.height = h
	c.radial_segments = 20
	return mesh(c, material, pos, rot)


static func capsule(r: float, h: float, material: Material, pos := Vector3.ZERO, rot := Vector3.ZERO) -> MeshInstance3D:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = h
	c.radial_segments = 16
	c.rings = 6
	return mesh(c, material, pos, rot)


static func pick_area(kind: String, size: Vector3, center: Vector3) -> Area3D:
	## Невидима «зона торкання» для об'єкта.
	var a := Area3D.new()
	a.set_meta("kind", kind)
	a.input_ray_pickable = true
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	cs.position = center
	a.add_child(cs)
	return a


static func bubble(font: Font, size := 48) -> Label3D:
	var l := Label3D.new()
	l.font = font
	l.font_size = size
	l.outline_size = 14
	l.modulate = Color(0.16, 0.12, 0.3)
	l.outline_modulate = Color(1, 1, 1, 0.95)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.pixel_size = 0.0022
	l.width = 520.0
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.render_priority = 10
	l.outline_render_priority = 9
	l.visible = false
	return l


# ------------------------------------------------------------------ кошик для грибів, ягід і яблук
static func basket() -> Node3D:
	## Плетений кошик із дужкою. У вузол «fill» складаються зібрані плоди (див. basket_add).
	var n := Node3D.new()
	var wick := mat(Color(0.72, 0.52, 0.28), 0.95)
	n.add_child(cyl(0.17, 0.13, 0.15, wick, Vector3(0, 0.075, 0)))
	var handle := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.14
	tm.outer_radius = 0.16
	tm.rings = 14
	tm.ring_segments = 4
	handle.mesh = tm
	handle.material_override = wick
	handle.rotation_degrees = Vector3(90, 0, 0)
	handle.position = Vector3(0, 0.15, 0)
	n.add_child(handle)
	var fill := Node3D.new()
	fill.name = "fill"
	n.add_child(fill)
	return n


static func basket_add(b, color: Color, r := 0.04) -> void:
	## Кладе ще один плід у кошик (до 16 штук — далі кошик просто «повний»).
	## b без типу: кошик могли вже прибрати (справу скасували).
	if b == null or not is_instance_valid(b):
		return
	var fill: Node3D = b.get_node_or_null("fill")
	if fill == null or fill.get_child_count() >= 16:
		return
	var i := fill.get_child_count()
	var a := float(i) * 2.4
	var ring := 0.02 + 0.09 * fmod(float(i) * 0.37, 1.0)
	var layer := floorf(float(i) / 8.0)
	fill.add_child(sphere(r, mat(color, 0.5), Vector3(cos(a) * ring, 0.15 + layer * 0.04, sin(a) * ring)))

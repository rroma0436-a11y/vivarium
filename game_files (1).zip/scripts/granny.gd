extends "res://scripts/farmhand.gd"
## Бабуся: живе з дідусем у хаті. Годує курей, порається на городі, п'є воду біля криниці,
## а подекуди заходить у хату — прибирати й готувати.

var spots := {}
var _cooked_day := -1


func setup_granny(sp: Dictionary) -> void:
	spots = sp
	setup("granny", 1.6, {"idle": ["short_breathe"], "walk": ["walking"], "run": ["running"], "talk": ["talk_with_hands"],
			"pick": ["female_stand_pick_fruit"], "pocket": ["female_walk_pick"], "bend": ["male_bend_over"],
			"wave": ["wave_one_hand"], "drink": ["stand_and_drink"]},
		["idle", "walk", "run", "pick", "bend"],
		["Я — бабуся Галя. Усе господарство на мені!", "Курочки сьогодні несуться, як навіжені.",
		 "Борщ уже варю, а ти вже їла?", "Дідусь знову в майстерні? Кличте обідати!", "Онучку, візьми пиріжка!"],
		[], "npc")
	bounds = YARD_BOUNDS
	setup_pose()
	start_life(spots["door"] + Vector3(0.1, 0, 0.5), [], 6.6, 20.8)


func appear() -> void:
	var w = main.world
	position = spots["door"] + Vector3(0.1, 0, -0.9)
	_show(true)
	w.set_door("house", true, 0.4)
	await wait(0.4)
	await go(spots["door"] + Vector3(0.1, 0, 0.9), false, false)
	w.set_door("house", false, 0.4)


func vanish() -> void:
	var w = main.world
	await _goto(spots["door"] + Vector3(0.1, 0, 0.5), 1.0)
	face(spots["door"] + Vector3(0, 0, -2))
	w.set_door("house", true, 0.4)
	await wait(0.5)
	await go(spots["door"] + Vector3(0.1, 0, -0.9), false, false)
	_show(false)
	w.set_door("house", false, 0.4)


func on_arrived() -> void:
	say("Доброго ранку, любі!", 2.5)


func work_step() -> void:
	var id := begin_job("chores")
	var r := randi() % 4
	match r:
		0:
			await _feed_hens(id)
		1:
			await _garden(id)
		2:
			await _well(id)
		3:
			await _house_chores(id)
	end_job(id)


func _feed_hens(id: int) -> void:
	var g: Vector3 = spots["grain"]
	await _goto(g + Vector3(0.4, 0, 0.9))
	if id != job:
		return
	face(g)
	say("Цип-цип-цип, курочки!", 2.5)
	for b in main.birds:
		b.go_eat(g)
	await act("pick", 5.0)
	await wait(5.0)
	for b in main.birds:
		if b.mode == "grain":
			b.roam()


func _garden(id: int) -> void:
	var g: Vector3 = spots["garden"]
	await _goto(g + Vector3(0.6, 0, 1.0))
	if id != job:
		return
	face(g)
	say("Бур'яни геть, гарбузи — ростіть!", 2.5)
	await act("bend", 6.0)


func _well(id: int) -> void:
	await _goto(spots["well_front"] + Vector3(0.2, 0, 0.6))
	if id != job:
		return
	face(spots["well"])
	await act("drink", 6.0)


func _house_chores(id: int) -> void:
	## Прибирає й готує — заходить до хати, виходить із пирогом на ґанок.
	var d := int(Game.state["day"])
	say("Піду приберу в хаті й зготую обід.", 2.5)
	await vanish()
	if id != job:
		return
	await wait(randf_range(25.0, 40.0))
	await appear()
	if _cooked_day != d:
		_cooked_day = d
		say("Борщ готовий! Ідіть їсти!", 3.0)
	await act("wave", 3.0)

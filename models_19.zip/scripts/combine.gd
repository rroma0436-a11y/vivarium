extends Node3D
## Комбайн (Комбайн.blend → combine.glb), на ньому їздить Ніка. Вперед — вісь +z (жатка спереду),
## кабіна над передніми колесами, двері кабіни й драбинка — з правого боку (вісь −x).
## Передні колеса ведучі, задні — керовані (повертають у протилежний бік), мотовило крутиться.
## Де Ніка злізла — там комбайн і стоїть.

const R_FRONT := 0.81
const R_REAR := 0.51
# точки для Ніки (у системі комбайна)
const CLIMB_FROM := Vector3(-2.05, 0.0, 1.35)       # де стати на землі біля драбинки
const LADDER := [Vector3(-1.55, 0.45, 1.35), Vector3(-1.45, 1.2, 1.35), Vector3(-1.35, 1.95, 1.35)]
const SILL := Vector3(-1.05, 2.6, 1.35)             # поріг кабіни
const SEAT_HIPS := Vector3(0.0, 3.02, 1.05)         # стегна Ніки на сидінні
const FEET := [Vector3(0.13, 2.66, 1.55), Vector3(-0.13, 2.66, 1.55)]
const WHEEL_C := Vector3(0.0, 3.3, 1.62)            # кермо

var model: Node3D
var body: StaticBody3D
var area: Area3D
var reel: Node3D
var door: Node3D
var wheels_f: Array = []
var wheels_r: Array = []
var pivots_r: Array = []
var _base := {}
var _spin_f := 0.0
var _spin_r := 0.0
var _steer := 0.0
var _door_k := 0.0
var _door_want := 0.0
var speed := 0.0


func setup() -> bool:
	if not ResourceLoader.exists("res://assets/models/combine.glb"):
		return false
	model = load("res://assets/models/combine.glb").instantiate()
	add_child(model)
	reel = model.find_child("Мотовило", true, false)
	door = model.find_child("Двері", true, false)
	for nm in ["Колесо_ПЛ", "Колесо_ПП"]:
		var w := model.find_child(nm, true, false)
		if w:
			wheels_f.append(w)
	for nm in ["Колесо_ЗЛ", "Колесо_ЗП"]:
		var w := model.find_child(nm, true, false)
		if w:
			wheels_r.append(w)
	for nm in ["Поворот_ЗЛ", "Поворот_ЗП"]:
		var w := model.find_child(nm, true, false)
		if w:
			pivots_r.append(w)
	for n in wheels_f + wheels_r + pivots_r + [door, reel]:
		if n:
			_base[n] = (n as Node3D).transform
	for mi in model.find_children("*", "MeshInstance3D", true, false):
		(mi as MeshInstance3D).visibility_range_end = 170.0
	# тверде тіло — Ніка не проходить крізь комбайн (шар стін базару, 1 << 17)
	body = StaticBody3D.new()
	body.collision_layer = 1 << 17
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	var bx := BoxShape3D.new()
	bx.size = Vector3(3.2, 3.2, 8.6)
	cs.shape = bx
	cs.position = Vector3(0, 1.6, -0.9)
	body.add_child(cs)
	add_child(body)
	area = Util.pick_area("combine", Vector3(4.4, 4.4, 9.6), Vector3(0, 2.2, -0.6))
	add_child(area)
	add_child(Util.blob_shadow(3.2, 0.3))
	return true


func solid(on: bool) -> void:
	## Поки Ніка в кабіні, комбайн сам себе не штовхає.
	if body:
		body.collision_layer = (1 << 17) if on else 0


func grip_global(left: bool) -> Vector3:
	## Кисті на ободі керма (кермо крутиться разом із колесами).
	var a := -_steer * 2.2
	var off := Vector3(0.17 if left else -0.17, 0.0, 0.0).rotated(Vector3(0, 0.6, -0.8).normalized(), a)
	return to_global(WHEEL_C + off)


func cab_points() -> Dictionary:
	return {"climb": CLIMB_FROM, "steps": LADDER, "sill": SILL, "seat": SEAT_HIPS, "feet": FEET, "side": -1.0}


func open_door(on: bool) -> void:
	_door_want = 1.0 if on else 0.0


func ride_anim(v: float, steer_to: float, dt: float) -> void:
	## v — швидкість (м/с), steer_to — куди повернуто (рад; задні колеса — навпаки).
	speed = v
	_spin_f = wrapf(_spin_f + v / R_FRONT * dt, 0.0, TAU)
	_spin_r = wrapf(_spin_r + v / R_REAR * dt, 0.0, TAU)
	_steer = lerpf(_steer, steer_to, 1.0 - exp(-dt * 4.0))
	for w in wheels_f:
		var b: Transform3D = _base[w]
		(w as Node3D).transform = Transform3D(b.basis * Basis(Vector3.RIGHT, _spin_f), b.origin)
	for w in wheels_r:
		var b2: Transform3D = _base[w]
		(w as Node3D).transform = Transform3D(Basis(Vector3.UP, -_steer * 0.8) * b2.basis * Basis(Vector3.RIGHT, _spin_r), b2.origin)
	for p in pivots_r:
		var b3: Transform3D = _base[p]
		(p as Node3D).transform = Transform3D(Basis(Vector3.UP, -_steer * 0.8) * b3.basis, b3.origin)


func _process(delta: float) -> void:
	if reel:
		# мотовило крутиться, коли комбайн їде (і поволі — коли стоїть із заведеним мотором)
		reel.rotate_object_local(Vector3.RIGHT, delta * (0.5 + absf(speed) * 0.6))
	if door and absf(_door_k - _door_want) > 0.001:
		_door_k = move_toward(_door_k, _door_want, delta * 1.6)
		var e := _door_k * _door_k * (3.0 - 2.0 * _door_k)
		var bd: Transform3D = _base[door]
		door.transform = Transform3D(Basis(Vector3.UP, deg_to_rad(100.0) * e) * bd.basis, bd.origin)

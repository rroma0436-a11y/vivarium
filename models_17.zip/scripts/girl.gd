extends "res://scripts/npc.gd"
## Ніка — живе в селі, у хаті на заході площі. Зранку гуляє біля хати й фонтану,
## перед обідом ходить на базар, по обіді — у гості до дідуся Петра (через ворота ферми),
## увечері повертається додому й до ранку її не видно (спить).

var riding := false                    # (сумісність: на літаку не літає)
var _met := false
var _visit_day := -1
var _market_day := -1
var plane: Node3D

const OUT := Rect2(-62.0, -70.0, 110.0, 160.0)
const FAR := Rect2(-62.0, -135.0, 110.0, 225.0)      # з дорогою до грибного лісу
const HOME_YARD := Vector3(-20.2, 0, 47.5)      # подвір'ячко перед хатою в селі
const HOME_GATE := Vector3(-17.6, 0, 47.0)      # хвіртка в тину
const ROAD_IN := Vector3(-5.0, 0, 46.0)          # з хвіртки — на дорогу
const MARKET := [Vector3(-6.6, 0, 52.4), Vector3(6.6, 0, 52.4), Vector3(-8.0, 0, 66.8), Vector3(3.9, 0, 50.6), Vector3(9.4, 0, 64.4), Vector3(-9.2, 0, 59.0)]
# базар за річкою (bazaar.gd): дорога через міст і місця біля ларьків (уздовж проходу, x = 0)
const BAZAAR_WAY := [Vector3(-5.0, 0, 70.0), Vector3(-5.0, 0, 90.0), Vector3(0.0, 0, 96.5), Vector3(0.0, 0, 110.0), Vector3(0.0, 0, 160.0)]
const BAZAAR_SPOTS := [Vector3(-0.9, 0, 191.5), Vector3(0.9, 0, 187.0), Vector3(-0.9, 0, 182.5), Vector3(0.9, 0, 178.0), Vector3(-0.9, 0, 173.5)]
const SQUARE := [Vector3(-4.5, 0, 55.5), Vector3(4.5, 0, 55.0), Vector3(-5.0, 0, 64.5), Vector3(4.0, 0, 65.0)]


func setup_girl(_unused = null) -> void:
	setup("girl", 1.0, {"idle": ["idle_15", "idle"], "walk": ["walking"], "run": ["running"], "skip": ["skip"],
			"talk": ["talk"], "jump": ["happy_jump", "jump"], "sit": ["sit_cross"], "stand": ["sit_to_stand"],
			"pick": ["female_bend_over_pick_up", "pick_up"], "crouch_pick": ["crouch_pick"], "tree_pick": ["stand_pick_fruit"],
			"pocket": ["put_in_pocket"], "wag": ["finger_wag"], "drink": ["stand_and_drink"], "turn": ["idle_turn"],
			"sleep": ["toss_and_turn"]},
		["idle", "walk", "run", "skip", "sit"],
		["Привіт! Я — Ніка. Живу в селі, у білій хатці біля площі!",
		 "Зранку я ходжу на базар — там пахне хлібом і медом!",
		 "А по обіді біжу в гості до дідуся Петра.",
		 "За фермою є аеродром, а в ангарі — жовтий літак! Beep уміє ним керувати.",
		 "У небі світяться золоті насінинки. Збери їх на літаку!"],
		[], "girl")
	bounds = OUT
	extra_obs = Obstacles.outer
	walk_speed = 0.95
	run_speed = 2.2
	_make_idle()
	setup_pose()


func _make_idle() -> void:
	## Якщо окремої анімації «стоїть» у моделі немає — беремо спокійний початок розмови й гойдаємо туди-сюди.
	if ap == null or anims.get("talk", "") == "" or (anims.get("idle", "") != "" and anims["idle"] != anims["talk"]):
		return
	var lib := ap.get_animation_library("")
	var src: Animation = ap.get_animation(anims["talk"])
	var a: Animation = src.duplicate(true)
	a.length = minf(1.1, src.length)
	a.loop_mode = Animation.LOOP_PINGPONG
	if lib:
		lib.add_animation("girl_idle", a)
		anims["idle"] = "girl_idle"


func in_yard() -> bool:
	return position.z < 5.0 and position.x > -21.0 and position.x < 9.0


var on_plane: Node3D = null
const PLANE_SEAT := Vector3(0, 1.32, 0.12)


func board_plane(p: Node3D) -> void:
	## Підбігає до літака й залазить у кабіну.
	cancel_job()
	busy = false
	var side: Vector3 = p.to_global(Vector3(-2.6, 0, 0.4))
	var id := begin_job("plane")
	await go(side, true)
	var from := global_position
	var k := 0.0
	play("sit")
	while k < 1.0:
		k = minf(1.0, k + get_process_delta_time() / 0.9)
		var to: Vector3 = p.to_global(PLANE_SEAT)
		var q := from.lerp(to, k)
		q.y += sin(k * PI) * 0.6
		global_position = q
		rotation.y = lerp_angle(rotation.y, p.rotation.y, k)
		await get_tree().process_frame
	on_plane = p
	p.pilot = self
	p.pilot_seat = PLANE_SEAT
	end_job(id)


func leave_plane(p: Node3D) -> void:
	on_plane = null
	p.pilot = null
	p.pilot_seat = Vector3.ZERO
	var from := global_position
	var to: Vector3 = p.to_global(Vector3(-2.6, 0, 0.4))
	to.y = 0.0
	var k := 0.0
	while k < 1.0:
		k = minf(1.0, k + get_process_delta_time() / 0.8)
		var q := from.lerp(to, k)
		q.y = lerpf(from.y, 0.0, k) + sin(k * PI) * 0.5
		global_position = q
		await get_tree().process_frame
	global_position = to
	rotation = Vector3(0, rotation.y, 0)
	current = ""
	play("idle")
	idle_left = 4.0


# ------------------------------------------------------------------ гравець сам керує Нікою
var player := false                    # джойстиком (або торканням землі) керує гравець
var _pl_body: CharacterBody3D          # невидима «капсула» — щоб не проходити крізь стіни базару
var _pl_y := 0.0
const PL_WALK := 1.55
const PL_RUN := 3.6
const YARD_R := Rect2(-21.0, -15.0, 30.0, 20.0)


func player_begin() -> void:
	cancel_job()
	busy = false
	moving = false
	_esc_left = 0.0
	player = true
	at_home = false
	visible = true
	bounds = Rect2(-250.0, -250.0, 500.0, 500.0)
	if pose:
		pose.sit = 0.0
	if held:
		drop()
	if _pl_body == null:
		_pl_body = CharacterBody3D.new()
		_pl_body.name = "NikaBody"
		_pl_body.collision_layer = 0
		_pl_body.collision_mask = 1 << 17           # стіни, ларьки, паркани базару (bazaar.gd: WALLS)
		_pl_body.motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
		_pl_body.wall_min_slide_angle = 0.0
		var cs := CollisionShape3D.new()
		var cap := CapsuleShape3D.new()
		cap.radius = 0.2
		cap.height = 1.1
		cs.shape = cap
		cs.position = Vector3(0, 1.0, 0)               # низ капсули на 0.45 м — сходинки й поріг не заважають
		_pl_body.add_child(cs)
		get_parent().add_child(_pl_body)
	_pl_body.global_position = Vector3(global_position.x, 0, global_position.z)
	_pl_y = global_position.y
	current = ""
	play("idle")


# ------------------------------------------------------------------ у хаті: сісти, попити, лягти (керує гравець)
var acting := ""                       # sit / drink / lie (поки гравець не рушить джойстиком)
var _act_back := Vector3.ZERO           # куди стати, коли встане
var _act_cup: Node3D


func act_begin(act: String, at: Vector3, face_dir: Vector3, back: Vector3) -> void:
	acting = act
	_act_back = back
	moving = false
	global_position = at
	_pl_y = at.y
	if face_dir.length() > 0.01:
		rotation.y = atan2(face_dir.x, face_dir.z)
	if pose:
		pose.life = 0.0
	match act:
		"sit":
			play("idle")
			sit_down(true, 2.2)
			say(["Посиджу трошки.", "Як тут затишно!", "Ох, і добре!"][randi() % 3], 2.0)
		"lie":
			var n: String = anims.get("sleep", "")
			if n != "" and ap.has_animation(n):
				ap.get_animation(n).loop_mode = Animation.LOOP_LINEAR
			play("sleep")
			say("Трошки полежу… z-z-z", 2.5)
		"drink":
			play("idle")
			if Models.exists("cup"):
				_act_cup = Models.spawn(get_parent(), "cup", 0.11)
			if _act_cup == null:
				_act_cup = Util.cyl(0.045, 0.04, 0.1, Util.mat(Color(0.75, 0.45, 0.25), 0.6))
				get_parent().add_child(_act_cup)
			hold_upright(_act_cup, 0.06, false)
			say("Ммм, смачний узвар!", 2.5)


func act_step(delta: float) -> void:
	_physics_step(delta)
	if acting == "drink" and pose:
		pose.drink = lerpf(pose.drink, 1.0, 1.0 - exp(-delta * 2.5))


func act_end(instant := false) -> void:
	if acting == "":
		return
	var was := acting
	acting = ""
	if pose:
		pose.drink = 0.0
	if was == "drink":
		var m := drop()
		if m:
			m.queue_free()
		elif _act_cup and is_instance_valid(_act_cup):
			_act_cup.queue_free()
		_act_cup = null
	if was == "sit" and pose:
		if instant:
			pose.sit = 0.0
		else:
			await sit_down(false, 2.6)
	global_position = _act_back
	_pl_y = _act_back.y
	if _pl_body:
		_pl_body.global_position = Vector3(_act_back.x, _pl_y, _act_back.z)
	play("idle")


func player_end() -> void:
	if acting != "":
		act_end(true)
	player = false
	var bz0 = main.world.outer.bazaar if main else null
	if bz0 == null or bz0.building_at(global_position) == null:
		global_position.y = 0.0
	moving = false
	idle_left = 3.0
	bounds = OUT if not (main and main.world.outer.bazaar and main.world.outer.bazaar.in_area(global_position)) else FAR_ALL
	play("idle")


const FAR_ALL := Rect2(-80.0, -135.0, 150.0, 380.0)


func player_step(mv: Vector3, run: bool, delta: float) -> float:
	## mv — куди йти (довжина 0…1). Повертає, скільки пройшла (для перевірки, чи не застрягла).
	_physics_step(delta)
	var amt := clampf(mv.length(), 0.0, 1.0)
	var old := global_position
	var bz = main.world.outer.bazaar if main else null
	if amt > 0.08:
		var dir := mv / mv.length()
		var spd := (PL_RUN if run else PL_WALK) * (amt if not run else 1.0)
		_pl_body.global_position = Vector3(old.x, _pl_y, old.z)
		_pl_body.velocity = dir * spd
		_pl_body.move_and_slide()
		var p := _pl_body.global_position
		# у відкритому світі — ті самі перешкоди, що й для всіх (хати, дерева, криниця…)
		if bz == null or not bz.in_area(p):
			p = Obstacles.push_out(p, me_r, 0.0, _obs())
		# річка: перейти можна лише мостом
		var rz: float = main.world.outer.RIVER_Z
		if absf(p.z - rz) < 5.0 and absf(p.x) > 2.0:
			p.z = old.z if absf(old.z - rz) >= 5.0 else p.z
			p.x = clampf(p.x, -2.0, 2.0) if absf(old.z - rz) < 5.0 else p.x
		# тин подвір'я: у двір і з двору — тільки через ворота
		var was_in := YARD_R.has_point(Vector2(old.x, old.z))
		var now_in := YARD_R.has_point(Vector2(p.x, p.z))
		if was_in != now_in and absf(p.x) > 1.3:
			p = Vector3(old.x, p.y, old.z)
		var lim: float = main.world.outer.LIMIT
		p.x = clampf(p.x, -lim, lim)
		p.z = clampf(p.z, -lim, lim)
		global_position = Vector3(p.x, global_position.y, p.z)
		var want := atan2(dir.x, dir.z)
		rotation.y = lerp_angle(rotation.y, want, 1.0 - exp(-delta * 12.0))
		if run:
			play("run", 1.05)
		else:
			play("walk", clampf(spd / 1.05, 0.7, 1.7))
	else:
		play("idle")
	# підлога: ганок, хата, ларьок — трохи вище за землю
	var fy := 0.0
	if bz and bz.in_area(global_position):
		fy = bz.floor_y(global_position, _pl_y)
	_pl_y = lerpf(_pl_y, fy, 1.0 - exp(-delta * 14.0)) if absf(_pl_y - fy) < 0.6 else fy
	global_position.y = _pl_y
	if pose:
		pose.life = lerpf(pose.life, 0.0 if amt > 0.08 else 1.0, 1.0 - exp(-delta * 3.0))
	var moved := Vector2(global_position.x - old.x, global_position.z - old.z).length()
	return moved


func _process(delta: float) -> void:
	if player:
		return                                # керує гравець (main.gd → player_step)
	if on_plane:
		if current != "sit":
			play("sit")
		return
	if not visible:
		# спить удома — зранку виходить
		var hh := Game.hour()
		if hh >= 7.3 and hh < 20.0:
			visible = true
			position = HOME_YARD
			at_home = false
			say("Доброго ранку!", 2.0)
		return
	_physics_step(delta)
	if pose:
		pose.life = lerpf(pose.life, 0.0 if moving or busy else 1.0, 1.0 - exp(-delta * 3.0))
	if moving:
		play("run" if running else "walk", 1.0)
		return
	if doing != "" or busy:
		if busy:
			_act_left -= delta
			if _act_left <= 0.0:
				busy = false
		return
	if current == "sit":
		busy = true
		play("stand")
		_act_left = clampf(anim_length("stand"), 1.0, 4.0)
		return
	play("idle")
	idle_left -= delta
	if idle_left > 0.0:
		return
	idle_left = randf_range(4.0, 9.0)
	_choose()


func _choose() -> void:
	var h := Game.hour()
	var d := int(Game.state["day"])
	if position.z > 95.0:
		from_bazaar()                         # опинилася за річкою — повертається мостом у село
		return
	if h >= 20.0 or h < 7.0:
		go_home_village()
		return
	if in_yard():
		if h >= 15.0 or randf() < 0.12:
			back_to_village()
			return
		_wander_yard()
		return
	if h >= 12.0 and h < 15.0 and _visit_day != d:
		_visit_day = d
		visit_grandpa()
		return
	if _market_day != d and h >= 9.0 and h < 12.0:
		_market_day = d
		market_job()
		return
	var r := randf()
	if r < 0.15:
		busy = true
		play("jump")
		_act_left = minf(anim_length("jump"), 4.0)
	elif r < 0.22 and anims.get("drink", "") != "":
		busy = true
		play("drink")
		_act_left = minf(anim_length("drink"), 8.0)
	elif r < 0.27 and anims.get("pocket", "") != "":
		busy = true
		play("pocket")
		say(["О, яка гарна квіточка!", "Знайшла камінчик!", "Це я сховаю в кишеньку."][randi() % 3], 2.5)
		_act_left = minf(anim_length("pocket"), 8.0)
	elif r < 0.55:
		var q: Vector3 = SQUARE[randi() % SQUARE.size()]
		walk_to(q + Vector3(randf_range(-0.8, 0.8), 0, randf_range(-0.8, 0.8)), randf() < 0.2)
	else:
		walk_to(HOME_YARD + Vector3(randf_range(-1.5, 1.0), 0, randf_range(-2.0, 2.0)))


func _wander_yard() -> void:
	var gp: Node3D = main.grandpa if main else null
	if gp and gp.visible and gp.global_position.z < 4.0 and randf() < 0.6:
		var p: Vector3 = gp.global_position
		var dir := (global_position - p)
		dir.y = 0.0
		if dir.length() < 0.1:
			dir = Vector3(1, 0, 0)
		walk_to(p + dir.normalized() * 1.4)
		if randf() < 0.5:
			say(["Дідусю, а розкажи казку!", "Я принесла пиріжків!", "Дідусю, а що ти робиш?"][randi() % 3], 2.5)
		return
	walk_to(Vector3(randf_range(-10.0, 4.0), 0, randf_range(-4.0, 2.5)))


func market_job() -> void:
	## Зранку — на базар за річку: через міст, уздовж ларьків, купує щось і вертається додому.
	var id := begin_job("market")
	say("Піду на базар за річку!", 2.5)
	bounds = FAR_ALL
	if position.distance_to(HOME_YARD) < 6.0:
		await go(HOME_GATE)
		if id != job:
			return
	await go(ROAD_IN)
	if id != job:
		return
	for wp in BAZAAR_WAY:
		await go(wp)
		if id != job:
			return
	var spots: Array = BAZAAR_SPOTS.duplicate()
	spots.shuffle()
	for k in 2:
		var sp: Vector3 = spots[k]
		await go(sp + Vector3(0, 0, randf_range(-0.4, 0.4)))
		if id != job:
			return
		face(sp + Vector3(-3.0 if sp.x < 0.0 else 3.0, 0, 0))
		say(["Мені хлібину, будь ласка!", "Скільки коштують яблучка?", "Ой, які льодяники!", "Мені кільце ковбаски!"][randi() % 4], 2.5)
		await wait(3.5)
		if id != job:
			return
	say("Усе купила! Тепер додому.", 2.0)
	await _bazaar_to_village(id)
	if id != job:
		return
	await go(HOME_GATE)
	if id != job:
		return
	bounds = OUT
	end_job(id)
	idle_left = 1.0


func from_bazaar() -> void:
	var id := begin_job("from_bazaar")
	bounds = FAR_ALL
	await _bazaar_to_village(id)
	if id != job:
		return
	bounds = OUT
	end_job(id)
	idle_left = 1.0


func _bazaar_to_village(id: int) -> void:
	## З базару — назад мостом через річку до села.
	if position.z > 112.0 and absf(position.x) > 3.0:
		await go(Vector3(0.0, 0, clampf(position.z, 112.0, 200.0)))
		if id != job:
			return
	for k in range(BAZAAR_WAY.size() - 1, -1, -1):
		if (BAZAAR_WAY[k] as Vector3).z > position.z + 1.0:
			continue
		await go(BAZAAR_WAY[k])
		if id != job:
			return
	await go(ROAD_IN)


func visit_grandpa() -> void:
	## Із села — дорогою до ферми, через ворота — на подвір'я.
	var id := begin_job("visit")
	say("Піду до дідуся Петра!", 2.5)
	bounds = OUT
	if position.distance_to(HOME_YARD) < 6.0:
		await go(HOME_GATE)
		if id != job:
			return
	await go(ROAD_IN)
	if id != job:
		return
	await go(Vector3(0.6, 0, 20.0))
	if id != job:
		return
	await go(main.world.spots["outside_gate"] + Vector3(0.4, 0, 0))
	if id != job:
		return
	await main.world.pass_gate(self, false)
	bounds = OUT
	if id != job:
		return
	await go(Vector3(-2.0, 0, 0.5))
	if id != job:
		return
	say("Добридень, дідусю!", 2.5)
	end_job(id)
	idle_left = 2.0


func back_to_village() -> void:
	var id := begin_job("back")
	say("Па-па! Піду додому.", 2.0)
	await go(main.world.spots["inside_gate"] + Vector3(-0.3, 0, 0))
	if id != job:
		return
	await main.world.pass_gate(self, true)
	bounds = OUT
	if id != job:
		return
	await go(Vector3(0.6, 0, 20.0))
	if id != job:
		return
	await go(ROAD_IN)
	if id != job:
		return
	await go(HOME_GATE)
	if id != job:
		return
	end_job(id)
	idle_left = 1.0


func forest_job() -> void:
	## Іде дорогою в грибний ліс із кошиком, збирає гриби й ягоди й повертається додому в село.
	var forest = main.forest if main else null
	if forest == null:
		return
	var id := begin_job("forest")
	say("Піду в ліс по гриби та ягоди!", 2.5)
	bounds = OUT
	if in_yard():
		await go(main.world.spots["inside_gate"] + Vector3(-0.3, 0, 0))
		if id != job:
			return
		await main.world.pass_gate(self, true)
	elif position.distance_to(HOME_YARD) < 6.0:
		await go(HOME_GATE)
		if id != job:
			return
		await go(ROAD_IN)
		if id != job:
			return
		await go(Vector3(0.6, 0, 20.0), true)
		if id != job:
			return
	bounds = FAR
	var basket := take_basket()
	await go(main.world.spots["outside_gate"] + Vector3(0.4, 0, 1.2), true)
	if id != job:
		return
	for wp in FOREST_WAY:
		await go(wp, true)
		if id != job:
			return
	var got := 0
	for it in forest.nearest_goods(FOREST_WAY[FOREST_WAY.size() - 1], 4):
		await go(forest.goods_pos(it) + Vector3(0.5, 0, 0.5))
		if id != job:
			return
		face(forest.goods_pos(it))
		var pk := "crouch_pick" if anims.get("crouch_pick", "") != "" and randf() < 0.5 else "pick"
		if anims.get(pk, "") != "":
			busy = true
			play(pk)
			await wait(minf(anim_length(pk), 4.5))
			busy = false
			play("idle")
		else:
			await wait(1.0)
		if id != job:
			return
		var col: Color = forest.kind_color(it)
		var n: int = forest.take(it)
		got += n
		if n > 0:
			Util.basket_add(basket, col, 0.05)
	say("Повний кошик — %d! Бабуся зрадіє." % got if got > 0 else "Сьогодні тут уже все зібрали…", 3.0)
	if got > 0:
		Game.emit_event("forest")
	await wait(1.2)
	if id != job:
		return
	for k in range(FOREST_WAY.size() - 1, -1, -1):
		await go(FOREST_WAY[k], true)
		if id != job:
			return
	await go(Vector3(0.6, 0, 20.0), true)
	if id != job:
		return
	await go(ROAD_IN, true)
	if id != job:
		return
	bounds = OUT
	await go(HOME_GATE)
	if id != job:
		return
	drop_basket()
	end_job(id)
	idle_left = 1.0


func go_home_village() -> void:
	## Увечері — додому: заходить у хвіртку, підходить до хати й зникає до ранку.
	if in_yard():
		await back_to_village()
	if position.z > 95.0:
		await from_bazaar()
	var id := begin_job("home")
	if position.distance_to(HOME_YARD) > 5.0:
		await go(HOME_GATE)
		if id != job:
			return
	await go(HOME_YARD + Vector3(-1.2, 0, 0))
	if id != job:
		return
	say("На добраніч!", 1.5)
	await wait(1.2)
	if id != job:
		return
	at_home = true
	visible = false
	end_job(id)


func talk(from: Vector3) -> void:
	super.talk(from)


func can_ride() -> bool:
	return false
